"""
All database models for the Music Recommender system.

Tables:
  users, songs, artists, genres, albums,
  song_features, user_preferences, recommendations,
  play_history, playlists, playlist_songs

Bug fix: Playlist.is_public column was missing — caused runtime crash
on playlist creation (library route does INSERT ... is_public).
"""
from datetime import datetime, timezone
from sqlalchemy import (
    Column, Integer, String, Float, Boolean,
    DateTime, ForeignKey, Text, Index, UniqueConstraint,
)
from sqlalchemy.orm import relationship
from app.database import Base


def _utcnow():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id              = Column(Integer, primary_key=True, index=True)
    username        = Column(String(50),  unique=True, nullable=False, index=True)
    email           = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    is_active       = Column(Boolean, default=True)
    created_at      = Column(DateTime(timezone=True), default=_utcnow)

    play_history    = relationship("PlayHistory",    back_populates="user")
    preferences     = relationship("UserPreference", back_populates="user", uselist=False)
    recommendations = relationship("Recommendation", back_populates="user")
    playlists       = relationship("Playlist",       back_populates="user")


class Artist(Base):
    __tablename__ = "artists"

    id         = Column(Integer, primary_key=True, index=True)
    name       = Column(String(255), nullable=False)
    mb_id      = Column(String(50), unique=True, nullable=True)
    created_at = Column(DateTime(timezone=True), default=_utcnow)

    songs = relationship("Song", back_populates="artist")


class Genre(Base):
    __tablename__ = "genres"

    id   = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)

    songs = relationship("Song", back_populates="genre")


class Album(Base):
    __tablename__ = "albums"

    id           = Column(Integer, primary_key=True, index=True)
    title        = Column(String(255), nullable=False)
    artist_id    = Column(Integer, ForeignKey("artists.id"))
    release_year = Column(Integer, nullable=True)
    created_at   = Column(DateTime(timezone=True), default=_utcnow)

    artist = relationship("Artist")
    songs  = relationship("Song", back_populates="album")


class Song(Base):
    __tablename__ = "songs"

    id         = Column(Integer, primary_key=True, index=True)
    title      = Column(String(255), nullable=False)
    artist_id  = Column(Integer, ForeignKey("artists.id"), nullable=False)
    album_id   = Column(Integer, ForeignKey("albums.id"),  nullable=True)
    genre_id   = Column(Integer, ForeignKey("genres.id"),  nullable=True)
    duration_s = Column(Integer, nullable=True)
    play_count = Column(Integer, default=0)
    mb_id      = Column(String(50), unique=True, nullable=True)
    track_id   = Column(String(50), unique=True, nullable=True)  # ← ADD THIS (MSD track ID)
    youtube_id = Column(String(20), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_utcnow)

    artist   = relationship("Artist", back_populates="songs")
    album    = relationship("Album",  back_populates="songs")
    genre    = relationship("Genre",  back_populates="songs")
    features = relationship("SongFeature", back_populates="song", uselist=False)

    __table_args__ = (
        Index("ix_songs_artist_id", "artist_id"),
        Index("ix_songs_genre_id",  "genre_id"),
    )



class SongFeature(Base):
    __tablename__ = "song_features"

    id           = Column(Integer, primary_key=True, index=True)
    song_id      = Column(Integer, ForeignKey("songs.id"), unique=True, nullable=False)

    tempo        = Column(Float, nullable=True)
    energy       = Column(Float, nullable=True)
    danceability = Column(Float, nullable=True)
    valence      = Column(Float, nullable=True)
    key          = Column(Integer, nullable=True)
    loudness     = Column(Float, nullable=True)

    mfcc_1 = Column(Float, nullable=True)
    mfcc_2 = Column(Float, nullable=True)
    mfcc_3 = Column(Float, nullable=True)
    mfcc_4 = Column(Float, nullable=True)
    mfcc_5 = Column(Float, nullable=True)

    # ── FCM cluster assignments (from MSD training) ──────────────
    fcm_cluster    = Column(Integer, nullable=True)   # hard cluster (0–9)
    fcm_confidence = Column(Float,   nullable=True)   # max membership value

    # Soft membership probabilities for K=10 clusters
    # Used by analytics_pipeline for fuzzy scoring
    cluster_prob_0 = Column(Float, nullable=True)
    cluster_prob_1 = Column(Float, nullable=True)
    cluster_prob_2 = Column(Float, nullable=True)
    cluster_prob_3 = Column(Float, nullable=True)
    cluster_prob_4 = Column(Float, nullable=True)
    cluster_prob_5 = Column(Float, nullable=True)
    cluster_prob_6 = Column(Float, nullable=True)
    cluster_prob_7 = Column(Float, nullable=True)
    cluster_prob_8 = Column(Float, nullable=True)
    cluster_prob_9 = Column(Float, nullable=True)

    song = relationship("Song", back_populates="features")


class UserPreference(Base):
    """
    Aggregated 9D user feature vector.
    Seeded by the Vibe Check onboarding quiz for new users.
    Updated in real-time when a user plays/skips/likes songs.
    """
    __tablename__ = "user_preferences"

    id      = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)

    avg_tempo        = Column(Float, default=0.0)
    avg_energy       = Column(Float, default=0.0)
    avg_danceability = Column(Float, default=0.0)
    avg_valence      = Column(Float, default=0.0)
    avg_mfcc_1       = Column(Float, default=0.0)
    avg_mfcc_2       = Column(Float, default=0.0)
    avg_mfcc_3       = Column(Float, default=0.0)
    avg_mfcc_4       = Column(Float, default=0.0)
    avg_mfcc_5       = Column(Float, default=0.0)

    preferred_genre_id = Column(Integer, ForeignKey("genres.id"), nullable=True)
    songs_played       = Column(Integer, default=0)
    updated_at         = Column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )

    user = relationship("User", back_populates="preferences")


class PlayHistory(Base):
    __tablename__ = "play_history"

    id        = Column(Integer, primary_key=True, index=True)
    user_id   = Column(Integer, ForeignKey("users.id"), nullable=False)
    song_id   = Column(Integer, ForeignKey("songs.id"), nullable=False)
    played_at = Column(DateTime(timezone=True), default=_utcnow)
    skipped   = Column(Boolean, default=False)
    liked     = Column(Boolean, default=False)
    replayed  = Column(Boolean, default=False)

    # Signal weights used in Analytics Mode:
    # skip: -0.4 | like: +0.5 | replay: +0.3 | play: +0.1
    play_duration_s = Column(Integer, nullable=True)

    user = relationship("User", back_populates="play_history")
    song = relationship("Song")

    __table_args__ = (
        Index("ix_play_history_user_id",   "user_id"),
        Index("ix_play_history_song_id",   "song_id"),
        Index("ix_play_history_user_song", "user_id", "song_id"),
        Index("ix_play_history_played_at", "played_at"),
        Index(
            "ix_play_history_skipped",
            "skipped",
            postgresql_where=Column("skipped"),
        ),
    )


class Recommendation(Base):
    __tablename__ = "recommendations"

    id          = Column(Integer, primary_key=True, index=True)
    user_id     = Column(Integer, ForeignKey("users.id"), nullable=False)
    song_id     = Column(Integer, ForeignKey("songs.id"), nullable=False)
    mode        = Column(String(20), nullable=False)   # analytics | genai | hybrid
    score       = Column(Float, nullable=True)
    explanation = Column(Text, nullable=True)
    created_at  = Column(DateTime(timezone=True), default=_utcnow)

    user = relationship("User", back_populates="recommendations")
    song = relationship("Song")

    __table_args__ = (
        Index("ix_recommendations_user_mode", "user_id", "mode"),
    )


class Playlist(Base):
    __tablename__ = "playlists"

    id         = Column(Integer, primary_key=True, index=True)
    user_id    = Column(Integer, ForeignKey("users.id"), nullable=False)
    name       = Column(String(255), nullable=False)
    # BUG FIX: is_public was missing — library.py inserts this column
    is_public  = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime(timezone=True), default=_utcnow)

    user  = relationship("User", back_populates="playlists")
    songs = relationship("PlaylistSong", back_populates="playlist")

    __table_args__ = (
        Index("ix_playlists_user_id", "user_id"),
    )


class PlaylistSong(Base):
    __tablename__ = "playlist_songs"

    id          = Column(Integer, primary_key=True, index=True)
    playlist_id = Column(Integer, ForeignKey("playlists.id"), nullable=False)
    song_id     = Column(Integer, ForeignKey("songs.id"),     nullable=False)
    position    = Column(Integer, nullable=False)
    added_at    = Column(DateTime(timezone=True), default=_utcnow)

    playlist = relationship("Playlist", back_populates="songs")
    song     = relationship("Song")

    __table_args__ = (
        UniqueConstraint("playlist_id", "song_id", name="uq_playlist_song"),
        UniqueConstraint("playlist_id", "position", name="uq_playlist_position"),
        Index("ix_playlist_songs_playlist_position", "playlist_id", "position"),
    )
