from contextlib import asynccontextmanager
import asyncio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import structlog

from app.config import settings
from app.database import engine, Base
from app.api.routes import recommendations
from app.api.routes import library as library_route
from app.api.routes import artist_album_routes
from app.api.routes import youtube as youtube_route, auth, health
from app.api.routes import onboarding

logger = structlog.get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events."""
    logger.info("Starting Music Recommender API", env=settings.ENVIRONMENT)

    if settings.ENVIRONMENT.lower() == "development":
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("Database tables ready (development auto-create)")
    else:
        logger.info("Skipping Base.metadata.create_all (use Alembic migrations)")

    from app.pipelines.genai_pipeline import get_embedding_model
    logger.info("Warming up embedding model...")
    await asyncio.get_event_loop().run_in_executor(None, get_embedding_model)
    logger.info("Embedding model ready — startup complete")

    yield

    logger.info("Shutting down")
    await engine.dispose()


app = FastAPI(
    title="Music Recommender — Multi-Mode API",
    description=(
        "Analytics + GenAI (Sentence Transformers) + Hybrid Fusion recommendation modes. "
        "New users go through the Vibe Check onboarding to seed their first recommendations."
    ),
    version="1.1.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── CORS ────────────────────────────────────────────────────────
# FIX: Read allowed origins from settings (populated from .env / docker-compose
# ALLOWED_ORIGINS env var) instead of being hardcoded. The old code always used
# ["http://localhost:3000", "http://127.0.0.1:3000"] regardless of .env, making
# the ALLOWED_ORIGINS env var in docker-compose a no-op.
allowed_origins = [o.strip() for o in settings.ALLOWED_ORIGINS.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ─────────────────────────────────────────────────────
app.include_router(auth.router,                prefix="/api/v1/auth",            tags=["Auth"])
app.include_router(onboarding.router,          prefix="/api/v1/onboarding",      tags=["Onboarding"])
app.include_router(youtube_route.router,       prefix="/api/v1")
app.include_router(recommendations.router,     prefix="/api/v1/recommendations",  tags=["Recommendations"])
app.include_router(artist_album_routes.router, prefix="/api/v1/library",          tags=["Artist/Album"])
app.include_router(library_route.router,       prefix="/api/v1/library",          tags=["Library"])
app.include_router(health.router,              prefix="/api/v1/health",           tags=["Health"])


@app.get("/")
async def root():
    return {
        "name": "Music Recommender API",
        "version": "1.1.0",
        "modes": ["analytics", "genai", "hybrid"],
        "onboarding": "/api/v1/onboarding/status",
        "docs": "/docs",
    }
