"""
YouTube Video ID Search + Cache
================================
Endpoint: GET /api/v1/youtube/{song_id}

1. Returns the cached YouTube video ID from the songs table if present.
2. Otherwise searches YouTube for the song, saves the result, and returns it.
"""
import re

import httpx
import structlog
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from app.database import get_db
from app.core.security import get_current_user
from app.models.db_models import User

router = APIRouter(prefix="/youtube", tags=["YouTube"])
logger = structlog.get_logger()


async def _search_youtube(query: str) -> str | None:
    """
    Search YouTube without an API key via the public results page.
    Returns the first video ID found, or None on failure.
    """
    try:
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0 Safari/537.36"
            )
        }
        async with httpx.AsyncClient(timeout=10, headers=headers, follow_redirects=True) as client:
            resp = await client.get(
                "https://www.youtube.com/results",
                params={"search_query": query},
            )
            resp.raise_for_status()
            video_ids = re.findall(r'"videoId":"([a-zA-Z0-9_-]{11})"', resp.text)
            if not video_ids:
                return None
            # Preserve first-seen order while removing duplicates.
            unique_ids = list(dict.fromkeys(video_ids))
            return unique_ids[0]
    except Exception as exc:
        logger.warning("youtube_search_failed", query=query, error=str(exc))
        return None


@router.get("/{song_id}")
async def get_youtube_id(
    song_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # 1. Fetch song + check cache in a single query
    result = await db.execute(
        text("""
            SELECT s.title, s.youtube_id, a.name AS artist
            FROM songs s
            JOIN artists a ON a.id = s.artist_id
            WHERE s.id = :id
        """),
        {"id": song_id},
    )
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Song not found")

    if row.youtube_id:
        return {"video_id": row.youtube_id, "cached": True}

    # 2. Search YouTube — try with "official audio" first, then plain
    video_id = await _search_youtube(f"{row.title} {row.artist} official audio")
    if not video_id:
        video_id = await _search_youtube(f"{row.title} {row.artist}")

    if not video_id:
        raise HTTPException(status_code=404, detail="No YouTube video found")

    # 3. Cache the result
    try:
        await db.execute(
            text("UPDATE songs SET youtube_id = :yt_id WHERE id = :song_id"),
            {"yt_id": video_id, "song_id": song_id},
        )
        await db.commit()
    except Exception:
        await db.rollback()

    return {"video_id": video_id, "cached": False}
