"""
Vibe Check Onboarding
=====================
3-step quiz that seeds a new user's 9D audio feature vector so that
the Analytics pipeline works on the very first recommendation request.

Endpoints:
  POST /api/v1/onboarding/vibe-check   — submit quiz answers
  GET  /api/v1/onboarding/status       — should the UI show the quiz?

How it works:
  1. Each genre maps to a known audio feature centroid (tempo, energy, etc.)
  2. Energy selection adjusts the energy + tempo dimensions
  3. Liked quiz songs provide the strongest signal (weight 1.5×)
  4. The weighted average is written to user_preferences
  5. Liked quiz songs are also seeded as play_history entries so
     collaborative filtering has something to work with immediately

The Analytics pipeline reads user_preferences as a fallback when
play_history is empty — so the vibe check makes Analytics work
immediately for new users.
"""
from datetime import datetime, timezone
from typing import Optional

import structlog
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import get_current_user
from app.database import get_db
from app.models.db_models import User

logger = structlog.get_logger()
router = APIRouter()


# ── Genre audio fingerprints ─────────────────────────────────────
# Each entry is the average audio feature vector for that genre
# derived from MSD genre clusters. Adjust these if your 10K training
# data shows different cluster centres.

GENRE_VECTORS: dict[str, dict] = {
    "pop":       dict(tempo=118, energy=0.72, danceability=0.74, valence=0.63,
                      mfcc_1=0.20, mfcc_2=0.10, mfcc_3=0.00, mfcc_4=0.10, mfcc_5=0.00),
    "hiphop":    dict(tempo=95,  energy=0.65, danceability=0.82, valence=0.44,
                      mfcc_1=0.30, mfcc_2=0.20, mfcc_3=0.10, mfcc_4=0.00, mfcc_5=0.10),
    "rock":      dict(tempo=130, energy=0.85, danceability=0.48, valence=0.42,
                      mfcc_1=0.40, mfcc_2=0.30, mfcc_3=0.20, mfcc_4=0.10, mfcc_5=0.00),
    "electronic":dict(tempo=128, energy=0.80, danceability=0.75, valence=0.53,
                      mfcc_1=0.10, mfcc_2=0.20, mfcc_3=0.30, mfcc_4=0.20, mfcc_5=0.10),
    "jazz":      dict(tempo=105, energy=0.35, danceability=0.52, valence=0.65,
                      mfcc_1=0.00, mfcc_2=0.10, mfcc_3=0.20, mfcc_4=0.30, mfcc_5=0.40),
    "classical": dict(tempo=90,  energy=0.22, danceability=0.28, valence=0.58,
                      mfcc_1=0.10, mfcc_2=0.00, mfcc_3=0.10, mfcc_4=0.40, mfcc_5=0.50),
    "rnb":       dict(tempo=90,  energy=0.55, danceability=0.76, valence=0.56,
                      mfcc_1=0.20, mfcc_2=0.30, mfcc_3=0.10, mfcc_4=0.10, mfcc_5=0.20),
    "indie":     dict(tempo=115, energy=0.52, danceability=0.55, valence=0.48,
                      mfcc_1=0.30, mfcc_2=0.10, mfcc_3=0.20, mfcc_4=0.20, mfcc_5=0.10),
    "bollywood": dict(tempo=104, energy=0.60, danceability=0.68, valence=0.72,
                      mfcc_1=0.10, mfcc_2=0.20, mfcc_3=0.30, mfcc_4=0.10, mfcc_5=0.20),
}

ENERGY_PRESETS: dict[str, dict] = {
    "high":  dict(energy=0.90, tempo=155),
    "mid":   dict(energy=0.62, tempo=118),
    "low":   dict(energy=0.28, tempo=82),
    "mixed": dict(energy=0.55, tempo=110),
}

# Quiz song audio fingerprints — keep in sync with the frontend quiz cards.
QUIZ_SONG_VECTORS: dict[str, dict] = {
    "s1": dict(tempo=171, energy=0.80, danceability=0.51, valence=0.33,
               mfcc_1=0.20, mfcc_2=0.10, mfcc_3=0.00, mfcc_4=0.10, mfcc_5=0.00),
    "s2": dict(tempo=150, energy=0.62, danceability=0.90, valence=0.42,
               mfcc_1=0.30, mfcc_2=0.20, mfcc_3=0.10, mfcc_4=0.00, mfcc_5=0.10),
    "s3": dict(tempo=144, energy=0.40, danceability=0.35, valence=0.23,
               mfcc_1=0.40, mfcc_2=0.30, mfcc_3=0.20, mfcc_4=0.10, mfcc_5=0.00),
    "s4": dict(tempo=126, energy=0.63, danceability=0.62, valence=0.55,
               mfcc_1=0.10, mfcc_2=0.20, mfcc_3=0.30, mfcc_4=0.20, mfcc_5=0.10),
    "s5": dict(tempo=112, energy=0.30, danceability=0.45, valence=0.63,
               mfcc_1=0.00, mfcc_2=0.10, mfcc_3=0.20, mfcc_4=0.30, mfcc_5=0.40),
    "s6": dict(tempo=104, energy=0.55, danceability=0.60, valence=0.71,
               mfcc_1=0.10, mfcc_2=0.20, mfcc_3=0.30, mfcc_4=0.10, mfcc_5=0.20),
    "s7": dict(tempo=135, energy=0.43, danceability=0.70, valence=0.57,
               mfcc_1=0.20, mfcc_2=0.10, mfcc_3=0.00, mfcc_4=0.10, mfcc_5=0.00),
    "s8": dict(tempo=97,  energy=0.50, danceability=0.76, valence=0.52,
               mfcc_1=0.20, mfcc_2=0.30, mfcc_3=0.10, mfcc_4=0.10, mfcc_5=0.20),
}

# Song titles for quiz songs — used to find them in the DB
QUIZ_SONG_TITLES: dict[str, str] = {
    "s1": "Blinding Lights",
    "s2": "HUMBLE.",
    "s3": "Bohemian Rhapsody",
    "s4": "Levels",
    "s5": "Fleurette Africaine",
    "s6": "Kesariya",
    "s7": "bad guy",
    "s8": "Redbone",
}

FEATURE_KEYS = [
    "tempo", "energy", "danceability", "valence",
    "mfcc_1", "mfcc_2", "mfcc_3", "mfcc_4", "mfcc_5",
]


# ── Pydantic schemas ──────────────────────────────────────────────

class VibeCheckRequest(BaseModel):
    genres:          list[str]   # ["pop", "hiphop", ...]
    energy:          str         # "high" | "mid" | "low" | "mixed"
    liked_song_ids:  list[str]   # quiz IDs e.g. ["s1", "s3"]


class VibeCheckResponse(BaseModel):
    persona:    str
    tempo:      int
    energy_pct: int
    genres:     list[str]
    onboarded:  bool


class OnboardingStatus(BaseModel):
    needs_onboarding: bool
    history_count:    int


# ── Routes ────────────────────────────────────────────────────────

@router.get("/status", response_model=OnboardingStatus)
async def onboarding_status(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Called by the frontend on every login to decide whether to show
    the vibe check. Returns needs_onboarding=True if the user has
    fewer than 5 play history entries AND no saved preferences.
    """
    history_count = (await db.execute(
        text("SELECT COUNT(*) FROM play_history WHERE user_id = :uid"),
        {"uid": current_user.id},
    )).scalar() or 0

    has_prefs = (await db.execute(
        text("SELECT 1 FROM user_preferences WHERE user_id = :uid LIMIT 1"),
        {"uid": current_user.id},
    )).scalar()

    needs_onboarding = history_count < 5 and not has_prefs

    return OnboardingStatus(
        needs_onboarding=needs_onboarding,
        history_count=history_count,
    )


@router.post("/vibe-check", response_model=VibeCheckResponse)
async def submit_vibe_check(
    body: VibeCheckRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Accepts quiz answers and seeds the user's audio feature vector.

    Steps:
      1. Validate input
      2. Build weighted composite feature vector
      3. Upsert into user_preferences
      4. Seed synthetic play_history for liked quiz songs
      5. Return computed persona for the reveal screen
    """
    if not body.genres:
        raise HTTPException(status_code=400, detail="Select at least one genre")

    if body.energy not in ENERGY_PRESETS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid energy. Choose from: {list(ENERGY_PRESETS)}",
        )

    # Guard: don't overwrite a warm user's real history
    history_count = (await db.execute(
        text("SELECT COUNT(*) FROM play_history WHERE user_id = :uid"),
        {"uid": current_user.id},
    )).scalar() or 0

    if history_count > 20:
        raise HTTPException(
            status_code=400,
            detail="Already has sufficient listening history — vibe check not needed",
        )

    # ── Build composite feature vector ───────────────────────────
    # weighted_vectors: list of (feature_dict, weight)
    weighted: list[tuple[dict, float]] = []

    # Genre signals — weight 1.0 each
    for genre in body.genres:
        if genre in GENRE_VECTORS:
            weighted.append((GENRE_VECTORS[genre], 1.0))

    # Energy signal — weight 0.8, overrides energy + tempo dims
    energy_preset = ENERGY_PRESETS[body.energy]
    if weighted:
        base = dict(weighted[0][0])   # start from first genre
        base.update(energy_preset)    # override energy & tempo only
    else:
        base = {k: 0.5 for k in FEATURE_KEYS}
        base.update(energy_preset)
    weighted.append((base, 0.8))

    # Liked song signals — strongest weight (1.5 each)
    for sid in body.liked_song_ids:
        if sid in QUIZ_SONG_VECTORS:
            weighted.append((QUIZ_SONG_VECTORS[sid], 1.5))

    # Weighted average across all feature keys
    total_weight = sum(w for _, w in weighted)
    avg: dict[str, float] = {}
    for key in FEATURE_KEYS:
        avg[key] = sum(v.get(key, 0.0) * w for v, w in weighted) / total_weight

    # ── Upsert user_preferences ───────────────────────────────────
    params = {
        "uid":    current_user.id,
        "tempo":  avg["tempo"],
        "energy": avg["energy"],
        "dance":  avg["danceability"],
        "val":    avg["valence"],
        "m1":     avg["mfcc_1"],
        "m2":     avg["mfcc_2"],
        "m3":     avg["mfcc_3"],
        "m4":     avg["mfcc_4"],
        "m5":     avg["mfcc_5"],
    }

    existing_pref = (await db.execute(
        text("SELECT id FROM user_preferences WHERE user_id = :uid"),
        {"uid": current_user.id},
    )).scalar_one_or_none()

    if existing_pref:
        await db.execute(text("""
            UPDATE user_preferences SET
                avg_tempo        = :tempo,
                avg_energy       = :energy,
                avg_danceability = :dance,
                avg_valence      = :val,
                avg_mfcc_1       = :m1,
                avg_mfcc_2       = :m2,
                avg_mfcc_3       = :m3,
                avg_mfcc_4       = :m4,
                avg_mfcc_5       = :m5,
                songs_played     = 0,
                updated_at       = NOW()
            WHERE user_id = :uid
        """), params)
    else:
        await db.execute(text("""
            INSERT INTO user_preferences
                (user_id, avg_tempo, avg_energy, avg_danceability, avg_valence,
                 avg_mfcc_1, avg_mfcc_2, avg_mfcc_3, avg_mfcc_4, avg_mfcc_5,
                 songs_played)
            VALUES
                (:uid, :tempo, :energy, :dance, :val,
                 :m1, :m2, :m3, :m4, :m5, 0)
        """), params)

    # ── Seed synthetic play_history for liked quiz songs ──────────
    # This gives collaborative filtering something to work with
    # immediately and also populates the genre preference signal.
    for sid in body.liked_song_ids:
        db_song_id = await _find_quiz_song_in_db(db, sid)
        if db_song_id:
            await db.execute(text("""
                INSERT INTO play_history
                    (user_id, song_id, liked, skipped, replayed, played_at)
                VALUES
                    (:uid, :sid, true, false, false, NOW())
                ON CONFLICT DO NOTHING
            """), {"uid": current_user.id, "sid": db_song_id})
            logger.info(
                "vibe_check_seed_play",
                user_id=current_user.id,
                song_id=db_song_id,
                quiz_id=sid,
            )

    await db.commit()

    # ── Derive persona for the reveal screen ──────────────────────
    energy_pct = int(avg["energy"] * 100)
    tempo      = int(avg["tempo"])

    if energy_pct > 70:
        persona = "Hype machine"
    elif energy_pct > 45:
        persona = "Feel-good explorer"
    else:
        persona = "Deep listener"

    logger.info(
        "vibe_check_complete",
        user_id=current_user.id,
        genres=body.genres,
        energy=body.energy,
        liked_count=len(body.liked_song_ids),
        persona=persona,
        tempo=tempo,
        energy_pct=energy_pct,
    )

    return VibeCheckResponse(
        persona=persona,
        tempo=tempo,
        energy_pct=energy_pct,
        genres=body.genres,
        onboarded=True,
    )


# ── Helpers ───────────────────────────────────────────────────────

async def _find_quiz_song_in_db(db, quiz_id: str) -> Optional[int]:
    """
    Looks up a quiz song in the DB by title (case-insensitive).
    Returns the song's DB id, or None if the song is not in the DB yet.
    The quiz songs should be in your 10K MSD subset — if not, this is
    a no-op and just skips the seed entry.
    """
    title = QUIZ_SONG_TITLES.get(quiz_id)
    if not title:
        return None
    return (await db.execute(
        text("SELECT id FROM songs WHERE LOWER(title) = LOWER(:t) LIMIT 1"),
        {"t": title},
    )).scalar_one_or_none()


# ──────────────────────────────────────────────────────────────────
# NEW ENDPOINT: Dynamic Song Suggestions for Cold Start
# ──────────────────────────────────────────────────────────────────

class SuggestionsRequest(BaseModel):
    genres:  list[str]
    energy:  str = "mid"
    count:   int = 8


class SuggestedSong(BaseModel):
    id:      str
    title:   str
    artist:  str
    emoji:   str
    db_song_id: Optional[int] = None


class SuggestionsResponse(BaseModel):
    songs: list[SuggestedSong]


GENRE_EMOJIS: dict[str, str] = {
    "pop": "✨", "hiphop": "🎤", "hip-hop": "🎤", "hip hop": "🎤",
    "rock": "🎸", "electronic": "🎛️", "dance": "🎛️", "edm": "🎛️",
    "jazz": "🎷", "blues": "🎵", "classical": "🎻",
    "rnb": "💫", "r&b": "💫", "soul": "💫",
    "indie": "🎨", "alternative": "🎨",
    "bollywood": "🎬", "hindi": "🎬", "latin": "🎺",
    "metal": "🤘", "country": "🤠",
}

ENERGY_RANGE: dict[str, tuple[float, float]] = {
    "high":  (0.70, 1.00),
    "mid":   (0.40, 0.75),
    "low":   (0.00, 0.45),
    "mixed": (0.00, 1.00),
}


@router.post("/suggestions", response_model=SuggestionsResponse)
async def get_onboarding_suggestions(
    body: SuggestionsRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Returns personalized song suggestions for the cold-start quiz step 3,
    based on the genres + energy level the user selected in steps 1–2.

    Queries the songs table filtered by:
      • genre name matching one of the selected genres (case-insensitive LIKE)
      • audio energy within the energy band for the selected preset
      • ordered by play_count DESC (popular first)

    Falls back to top songs by play_count if genre matching yields too few.
    """
    energy_min, energy_max = ENERGY_RANGE.get(body.energy, (0.0, 1.0))
    count = min(max(body.count, 4), 20)

    params: dict = {
        "energy_min": energy_min,
        "energy_max": energy_max,
        "limit":      max(count * 5, 30),
    }

    query = text("""
        SELECT DISTINCT ON (s.id)
            s.id, s.title, a.name AS artist, g.name AS genre
        FROM songs s
        JOIN artists a      ON a.id  = s.artist_id
        JOIN song_features sf ON sf.song_id = s.id
        LEFT JOIN genres g  ON g.id  = s.genre_id
        WHERE sf.energy BETWEEN :energy_min AND :energy_max
        ORDER BY s.id, s.play_count DESC
        LIMIT :limit
    """)

    rows = (await db.execute(query, params)).fetchall()

    if body.genres:
        lowered_genres = [g.lower() for g in body.genres]
        filtered = []
        for row in rows:
            genre_name = (row.genre or "").lower()
            if any(g in genre_name for g in lowered_genres):
                filtered.append(row)
            if len(filtered) >= count:
                break
        rows = filtered

    # If insufficient results, fall back to most-played without genre filter
    if len(rows) < 4:
        fallback_q = text("""
            SELECT s.id, s.title, a.name AS artist, g.name AS genre
            FROM songs s
            JOIN artists a ON a.id = s.artist_id
            JOIN song_features sf ON sf.song_id = s.id
            LEFT JOIN genres g ON g.id = s.genre_id
            ORDER BY s.play_count DESC
            LIMIT :limit
        """)
        rows = (await db.execute(fallback_q, {"limit": count})).fetchall()

    songs = []
    for i, row in enumerate(rows):
        genre_lower = (row.genre or "").lower()
        emoji = "🎵"
        for key, em in GENRE_EMOJIS.items():
            if key in genre_lower:
                emoji = em
                break
        songs.append(SuggestedSong(
            id=f"db_{row.id}",
            title=row.title,
            artist=row.artist,
            emoji=emoji,
            db_song_id=row.id,
        ))

    return SuggestionsResponse(songs=songs)
