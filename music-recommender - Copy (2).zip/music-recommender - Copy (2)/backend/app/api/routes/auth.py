import redis.asyncio as aioredis
from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from jose import JWTError
import structlog

from app.database import get_db
from app.config import settings
from app.models.db_models import User
from app.schemas.recommendation import UserCreate, UserResponse, Token
from app.core.security import (
    hash_password,
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_token,
    get_current_user,
)

router = APIRouter()
logger = structlog.get_logger()

_LOGIN_WINDOW_SECONDS = 900
_LOCK_SECONDS = 900
_MAX_ATTEMPTS = 8


def _cookie_secure() -> bool:
    return settings.ENVIRONMENT.lower() != "development"


def _set_auth_cookies(response: Response, access_token: str, refresh_token: str) -> None:
    secure = _cookie_secure()
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        secure=secure,
        samesite="lax",
        max_age=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        path="/",
    )
    response.set_cookie(
        key="refresh_token",
        value=refresh_token,
        httponly=True,
        secure=secure,
        samesite="lax",
        max_age=settings.REFRESH_TOKEN_EXPIRE_DAYS * 24 * 3600,
        path="/api/v1/auth",
    )


def _clear_auth_cookies(response: Response) -> None:
    response.delete_cookie("access_token", path="/")
    response.delete_cookie("refresh_token", path="/api/v1/auth")


async def _check_login_lock(redis_client, ip: str, username: str) -> None:
    if redis_client is None:
        return
    ip_lock = f"auth:lock:ip:{ip}"
    user_lock = f"auth:lock:user:{username.lower()}"
    if await redis_client.exists(ip_lock) or await redis_client.exists(user_lock):
        raise HTTPException(status_code=429, detail="Too many login attempts. Try again later.")


async def _record_login_failure(redis_client, ip: str, username: str) -> None:
    if redis_client is None:
        return
    ip_fail = f"auth:fail:ip:{ip}"
    user_fail = f"auth:fail:user:{username.lower()}"

    ip_count = await redis_client.incr(ip_fail)
    user_count = await redis_client.incr(user_fail)
    await redis_client.expire(ip_fail, _LOGIN_WINDOW_SECONDS)
    await redis_client.expire(user_fail, _LOGIN_WINDOW_SECONDS)

    if ip_count >= _MAX_ATTEMPTS:
        await redis_client.setex(f"auth:lock:ip:{ip}", _LOCK_SECONDS, "1")
    if user_count >= _MAX_ATTEMPTS:
        await redis_client.setex(f"auth:lock:user:{username.lower()}", _LOCK_SECONDS, "1")


async def _clear_login_failures(redis_client, ip: str, username: str) -> None:
    if redis_client is None:
        return
    await redis_client.delete(f"auth:fail:ip:{ip}", f"auth:fail:user:{username.lower()}")


@router.post("/register", response_model=UserResponse, status_code=201)
async def register(user_data: UserCreate, db: AsyncSession = Depends(get_db)):
    existing = await db.execute(
        select(User).where(
            (User.email == user_data.email) | (User.username == user_data.username)
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Email or username already registered")

    user = User(
        username=user_data.username,
        email=user_data.email,
        hashed_password=hash_password(user_data.password),
    )
    db.add(user)
    await db.flush()
    return user


@router.post("/login", response_model=Token)
async def login(
    request: Request,
    response: Response,
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db),
):
    ip = request.client.host if request.client else "unknown"
    redis_client = None
    try:
        redis_client = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
    except Exception as e:
        logger.warning("auth_redis_init_failed", error=str(e), ip=ip)
        redis_client = None

    try:
        await _check_login_lock(redis_client, ip, form_data.username)

        result = await db.execute(select(User).where(User.username == form_data.username))
        user = result.scalar_one_or_none()

        if not user or not verify_password(form_data.password, user.hashed_password):
            await _record_login_failure(redis_client, ip, form_data.username)
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password",
            )

        await _clear_login_failures(redis_client, ip, form_data.username)
    finally:
        if redis_client is not None:
            await redis_client.aclose()

    access_token = create_access_token(data={"sub": str(user.id)})
    refresh_token = create_refresh_token(data={"sub": str(user.id)})
    _set_auth_cookies(response, access_token, refresh_token)
    return {"access_token": access_token, "token_type": "bearer"}


@router.post("/refresh", response_model=Token)
async def refresh_token(
    request: Request,
    response: Response,
    db: AsyncSession = Depends(get_db),
):
    refresh_token_value = request.cookies.get("refresh_token")
    if not refresh_token_value:
        raise HTTPException(status_code=401, detail="Missing refresh token")

    try:
        payload = decode_token(refresh_token_value)
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    if payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Invalid refresh token")
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    user = await db.get(User, int(user_id))
    if user is None or not user.is_active:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    access_token = create_access_token(data={"sub": str(user_id)})
    rotated_refresh = create_refresh_token(data={"sub": str(user_id)})
    _set_auth_cookies(response, access_token, rotated_refresh)
    return {"access_token": access_token, "token_type": "bearer"}


@router.post("/logout")
async def logout(response: Response):
    _clear_auth_cookies(response)
    return {"status": "logged_out"}


@router.get("/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_user)):
    return current_user
