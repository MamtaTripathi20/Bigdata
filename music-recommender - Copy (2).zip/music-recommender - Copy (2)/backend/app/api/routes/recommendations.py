"""
Recommendations Router — Mode Controller
=========================================

FIX B2: Redis connection leak
  Old _get_redis() created a client per-request, never closed in hot path.
  Fixed: FastAPI dependency with try/finally guaranteed teardown.

FIX B3: Like action incorrectly incremented play_count
  Separated like events from play events. New POST /liked endpoint.
  log_play_event now requires actual play duration to increment play_count.

FIX ARCH: Recommendations table never written to
  BackgroundTask fires _persist_recommendations after every response.
"""
from datetime import datetime, timezone

import redis.asyncio as aioredis
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
import structlog

from app.config import settings
from app.database import get_db, AsyncSessionLocal
from app.schemas.recommendation import (
    RecommendationMode, RecommendationResponse,
    RecommendationRequest, PlayEvent,
)
from app.pipelines.analytics_pipeline import AnalyticsPipeline
from app.pipelines.genai_pipeline import GenAIPipeline
from app.pipelines.hybrid_pipeline import HybridPipeline
from app.core.security import get_current_user
from app.models.db_models import User, PlayHistory, Song, Recommendation

logger = structlog.get_logger()
router = APIRouter()

_PLAY_MIN_SECONDS = 30
_PLAY_MIN_FRACTION = 0.30


# ── FIX B2: Redis as a proper FastAPI dependency with guaranteed teardown ──
async def get_redis():
    """
    Yields a Redis client and ALWAYS closes it via try/finally.
    The old helper returned a bare client that was never closed in the
    get_recommendations hot path, exhausting the connection pool.
    """
    r = aioredis.from_url(settings.REDIS_URL, decode_responses=False)
    try:
        yield r
    finally:
        await r.aclose()


# ── FIX ARCH: Background persistence for recommendations table ─────────────
async def _persist_recommendations(user_id: int, mode_value: str, rec_payload: list[dict]):
    """Writes returned recommendations to the DB after the response is sent."""
    async with AsyncSessionLocal() as db:
        try:
            for rec in rec_payload:
                db.add(Recommendation(
                    user_id=user_id,
                    song_id=rec["song_id"],
                    mode=mode_value,
                    score=rec.get("score"),
                    explanation=rec.get("explanation"),
                ))
            await db.commit()
            logger.info("recommendations_persisted", user_id=user_id, count=len(rec_payload))
        except Exception as e:
            logger.warning("recommendations_persist_failed", error=str(e))
            await db.rollback()


# ── Cold-start bridge: GenAI → Analytics ──────────────────────────────────
async def _seed_analytics_from_genai(
    user_id: int,
    song_ids: list[int],
):
    """
    After GenAI recommends songs to a cold-start user, compute the average
    audio feature vector of those songs and upsert it into user_preferences.

    This means the next Analytics request for this user will have a sensible
    starting vector derived from what GenAI showed them, rather than falling
    back to the global popular-songs list.

    Blend strategy:
      - No existing prefs  → write GenAI vector directly (weight 1.0)
      - Existing prefs     → blend 60 % existing + 40 % GenAI signal
        (existing prefs come from the vibe check and are more intentional)

    Skips silently if the user already has ≥ 5 play_history entries
    (they're no longer cold-start so the bridge isn't needed).
    """
    redis_client = None
    try:
        from sqlalchemy import text as _text
        import numpy as np

        redis_client = aioredis.from_url(settings.REDIS_URL, decode_responses=False)
        async with AsyncSessionLocal() as db:
            history_count = (await db.execute(
                _text("SELECT COUNT(*) FROM play_history WHERE user_id = :uid"),
                {"uid": user_id},
            )).scalar() or 0

            if history_count >= 5 or not song_ids:
                return

            rows = (await db.execute(
                _text("""
                    SELECT tempo, energy, danceability, valence,
                           mfcc_1, mfcc_2, mfcc_3, mfcc_4, mfcc_5
                    FROM song_features
                    WHERE song_id = ANY(:ids)
                      AND tempo IS NOT NULL
                """),
                {"ids": song_ids},
            )).fetchall()

            if not rows:
                return

            mat = np.array([
                [r.tempo or 0, r.energy or 0, r.danceability or 0, r.valence or 0,
                 r.mfcc_1 or 0, r.mfcc_2 or 0, r.mfcc_3 or 0, r.mfcc_4 or 0, r.mfcc_5 or 0]
                for r in rows
            ], dtype=float)
            genai_vec = mat.mean(axis=0)

            existing = (await db.execute(
                _text("""
                    SELECT avg_tempo, avg_energy, avg_danceability, avg_valence,
                           avg_mfcc_1, avg_mfcc_2, avg_mfcc_3, avg_mfcc_4, avg_mfcc_5
                    FROM user_preferences WHERE user_id = :uid
                """),
                {"uid": user_id},
            )).fetchone()

            if existing:
                exist_vec = np.array([
                    existing.avg_tempo or 0, existing.avg_energy or 0,
                    existing.avg_danceability or 0, existing.avg_valence or 0,
                    existing.avg_mfcc_1 or 0, existing.avg_mfcc_2 or 0,
                    existing.avg_mfcc_3 or 0, existing.avg_mfcc_4 or 0,
                    existing.avg_mfcc_5 or 0,
                ], dtype=float)
                blended = 0.6 * exist_vec + 0.4 * genai_vec
                await db.execute(
                    _text("""
                        UPDATE user_preferences SET
                            avg_tempo        = :tempo,
                            avg_energy       = :energy,
                            avg_danceability = :dance,
                            avg_valence      = :valence,
                            avg_mfcc_1       = :m1,
                            avg_mfcc_2       = :m2,
                            avg_mfcc_3       = :m3,
                            avg_mfcc_4       = :m4,
                            avg_mfcc_5       = :m5
                        WHERE user_id = :uid
                    """),
                    {"uid": user_id, "tempo": blended[0], "energy": blended[1],
                     "dance": blended[2], "valence": blended[3],
                     "m1": blended[4], "m2": blended[5], "m3": blended[6],
                     "m4": blended[7], "m5": blended[8]},
                )
            else:
                await db.execute(
                    _text("""
                        INSERT INTO user_preferences
                            (user_id, avg_tempo, avg_energy, avg_danceability, avg_valence,
                             avg_mfcc_1, avg_mfcc_2, avg_mfcc_3, avg_mfcc_4, avg_mfcc_5)
                        VALUES
                            (:uid, :tempo, :energy, :dance, :valence,
                             :m1, :m2, :m3, :m4, :m5)
                    """),
                    {"uid": user_id, "tempo": genai_vec[0], "energy": genai_vec[1],
                     "dance": genai_vec[2], "valence": genai_vec[3],
                     "m1": genai_vec[4], "m2": genai_vec[5], "m3": genai_vec[6],
                     "m4": genai_vec[7], "m5": genai_vec[8]},
                )

            await db.commit()

            if redis_client is not None:
                try:
                    await redis_client.delete(f"uservec:{user_id}")
                except Exception:
                    pass

            logger.info(
                "analytics_seeded_from_genai",
                user_id=user_id,
                songs_used=len(rows),
                blended=existing is not None,
            )

    except Exception as e:
        logger.warning("seed_analytics_from_genai_failed", user_id=user_id, error=str(e))
    finally:
        if redis_client is not None:
            await redis_client.aclose()


@router.get(
    "",
    response_model=RecommendationResponse,
    summary="Get recommendations (Analytics | GenAI | Hybrid)",
)
async def get_recommendations(
    background_tasks: BackgroundTasks,
    mode: RecommendationMode = Query(RecommendationMode.ANALYTICS),
    count: int = Query(10, ge=1, le=50),
    query_text: str = Query(None, max_length=200),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),   # FIX B2: proper DI
):
    user_id = current_user.id
    logger.info("recommendation_request", user_id=user_id, mode=mode, count=count)

    if mode == RecommendationMode.ANALYTICS:
        result = await AnalyticsPipeline(db, redis).recommend(user_id=user_id, count=count)
    elif mode == RecommendationMode.GENAI:
        result = await GenAIPipeline(db, redis).recommend(
            user_id=user_id, count=count, query_text=query_text
        )
    else:  # HYBRID
        result = await HybridPipeline(db, redis).recommend(
            user_id=user_id, count=count, query_text=query_text
        )

    # FIX ARCH: persist to recommendations table asynchronously
    if result.recommendations:
        rec_payload = [
            {"song_id": r.song_id, "score": r.score, "explanation": r.explanation}
            for r in result.recommendations
        ]
        background_tasks.add_task(
            _persist_recommendations, user_id, mode.value, rec_payload
        )

    # Cold-start bridge: when GenAI (or Hybrid) responds, seed user_preferences
    # so the Analytics pipeline has something to work with immediately.
    # Runs silently in the background — does not block the response.
    if mode in (RecommendationMode.GENAI, RecommendationMode.HYBRID) \
            and result.recommendations:
        song_ids = [r.song_id for r in result.recommendations if r.song_id]
        background_tasks.add_task(
            _seed_analytics_from_genai, user_id, song_ids
        )

    return result


@router.post("/play", summary="Log a play event (updates user preferences)")
async def log_play_event(
    event: PlayEvent,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),
):
    """
    FIX B3: play_count only increments for REAL plays (not like-only events).
    A like-only call has liked=True with no play_duration_s — this was
    incorrectly treated as a full play before, corrupting popularity scores.
    """
    song = await db.get(Song, event.song_id)
    if not song:
        raise HTTPException(status_code=404, detail="Song not found")

    play = PlayHistory(
        user_id=current_user.id,
        song_id=event.song_id,
        skipped=event.skipped,
        liked=event.liked,
        replayed=event.replayed,
        play_duration_s=event.play_duration_s,
        played_at=datetime.now(timezone.utc),
    )
    db.add(play)

    # Count a play only after meaningful playback to avoid inflated popularity.
    threshold_s = _PLAY_MIN_SECONDS
    if song.duration_s:
        threshold_s = min(_PLAY_MIN_SECONDS, int(song.duration_s * _PLAY_MIN_FRACTION))

    played_long_enough = bool(event.play_duration_s is not None and event.play_duration_s >= threshold_s)
    if not event.skipped and played_long_enough:
        song.play_count += 1

    await db.flush()

    # Invalidate cached user vector
    try:
        await redis.delete(f"uservec:{current_user.id}")
    except Exception:
        pass

    await db.commit()
    return {"status": "logged", "song_id": event.song_id}


@router.post("/liked", summary="Toggle like status without incrementing play_count")
async def toggle_like(
    song_id: int,
    liked: bool,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),
):
    """
    FIX B3: Dedicated endpoint for explicit likes/unlikes.
    Frontend's toggleLike() calls this instead of logPlay() to avoid
    inflating play_count on songs the user only liked, never heard.
    """
    song = await db.get(Song, song_id)
    if not song:
        raise HTTPException(status_code=404, detail="Song not found")

    play = PlayHistory(
        user_id=current_user.id,
        song_id=song_id,
        skipped=False,
        liked=liked,
        replayed=False,
        play_duration_s=None,
        played_at=datetime.now(timezone.utc),
    )
    db.add(play)

    try:
        await redis.delete(f"uservec:{current_user.id}")
    except Exception:
        pass

    await db.commit()
    return {"status": "liked" if liked else "unliked", "song_id": song_id}


@router.get("/modes", summary="List available recommendation modes with metadata")
async def list_modes():
    return {
        "modes": [
            {
                "id": "analytics",
                "name": "Analytics Mode",
                "description": "Traditional ML: Fuzzy C-Means + Collaborative Filtering + Look-alike",
                "latency": "~50ms (cached), ~150ms (cold)",
                "best_for": "Users with listening history",
                "cold_start": False,
            },
            {
                "id": "genai",
                "name": "Generative AI Mode",
                "description": "Sentence Transformer embeddings + iTunes catalog search",
                "latency": "~200ms (cached), ~3s (cold)",
                "best_for": "New users, natural language queries",
                "cold_start": True,
            },
            {
                "id": "hybrid",
                "name": "Hybrid Fusion Mode",
                "description": "Both pipelines in parallel, weighted score fusion (α=0.55, β=0.35, γ=0.10)",
                "latency": "~200ms (cached), ~3s (cold)",
                "best_for": "Maximum quality, all user types",
                "cold_start": True,
            },
        ]
    }
