import time
import redis.asyncio as aioredis
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import structlog

from app.database import get_db
from app.config import settings
from app.schemas.recommendation import HealthResponse, ServiceHealth

router = APIRouter()
logger = structlog.get_logger()


@router.get("", response_model=HealthResponse)
async def health_check(db: AsyncSession = Depends(get_db)):
    """Check status of all services: PostgreSQL and Redis."""

    # ── PostgreSQL ───────────────────────────────────────────────
    try:
        t = time.time()
        await db.execute(text("SELECT 1"))
        pg = ServiceHealth(status="ok", latency_ms=int((time.time() - t) * 1000))
    except Exception as e:
        logger.warning("health_postgres_failed", error=str(e))
        pg = ServiceHealth(status="down", detail="service unavailable")

    # ── Redis ────────────────────────────────────────────────────
    try:
        t = time.time()
        r = aioredis.from_url(settings.REDIS_URL)
        await r.ping()
        await r.aclose()
        redis_health = ServiceHealth(status="ok", latency_ms=int((time.time() - t) * 1000))
    except Exception as e:
        logger.warning("health_redis_failed", error=str(e))
        redis_health = ServiceHealth(status="down", detail="service unavailable")

    # ── Overall ──────────────────────────────────────────────────
    statuses = [pg.status, redis_health.status]
    overall = "healthy" if all(s == "ok" for s in statuses) else "degraded"

    return HealthResponse(overall=overall, postgres=pg, redis=redis_health)


@router.get("/analytics")
async def analytics_health(db: AsyncSession = Depends(get_db)):
    try:
        result = await db.execute(text("SELECT COUNT(*) FROM songs"))
        return {"status": "ok", "songs_in_db": result.scalar()}
    except Exception as e:
        logger.warning("health_analytics_failed", error=str(e))
        return {"status": "error", "detail": "service unavailable"}


@router.get("/genai")
async def genai_health():
    """GenAI pipeline uses sentence-transformer embeddings — no external service needed."""
    return {"status": "ok", "engine": "sentence-transformers", "model": "all-mpnet-base-v2"}
