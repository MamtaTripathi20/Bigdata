from pydantic import model_validator
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # App
    ENVIRONMENT: str = "development"
    SECRET_KEY: str = "changeme-generate-a-real-secret-key"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    REFRESH_TOKEN_EXPIRE_DAYS: int = 14

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://music_user:music_pass@localhost:5432/music_db"

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    ANALYTICS_CACHE_TTL: int = 1800   # 30 min
    GENAI_CACHE_TTL: int = 3600       # 1 hour

    # FIX B5: Hybrid fusion weights MUST sum to ≤ 1.0 to prevent scores > 1.0
    # Old (BUG): α=0.6 + β=0.4 + γ=0.1 = 1.1 → scores could display as 110%
    # Fixed:     α=0.55 + β=0.35 + γ=0.10 = 1.0 → max score is exactly 1.0
    FUSION_ALPHA: float = 0.55        # Analytics weight
    FUSION_BETA: float  = 0.35        # GenAI weight
    FUSION_GAMMA: float = 0.10        # Diversity bonus weight

    # CORS — configurable via env var so staging/prod deployments don't require code changes
    ALLOWED_ORIGINS: str = "http://localhost:3000,http://localhost:3001"

    @model_validator(mode="after")
    def validate_security_settings(self):
        weak_defaults = {
            "changeme-generate-a-real-secret-key",
            "changeme-in-production-32chars",
            "changeme",
        }
        if self.SECRET_KEY in weak_defaults or len(self.SECRET_KEY) < 32:
            raise ValueError("SECRET_KEY is weak/default. Set a strong key (>=32 chars).")
        return self

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
