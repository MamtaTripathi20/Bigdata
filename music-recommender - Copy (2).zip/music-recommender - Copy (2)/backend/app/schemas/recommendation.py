"""
Pydantic schemas for all recommendation-related API payloads.

Changes from v1:
  - RecommendationResponse now has fallback_used (was already in GenAI/Hybrid,
    now unified — Analytics also reports cold_start_popular when it falls back)
"""
from enum import Enum
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, EmailStr


class RecommendationMode(str, Enum):
    ANALYTICS = "analytics"
    GENAI     = "genai"
    HYBRID    = "hybrid"


# ── Auth ─────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    username: str
    email:    EmailStr
    password: str


class UserResponse(BaseModel):
    id:         int
    username:   str
    email:      str
    is_active:  bool
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type:   str = "bearer"


class TokenData(BaseModel):
    user_id: Optional[int] = None


# ── Song / Play ───────────────────────────────────────────────────

class SongMeta(BaseModel):
    id:         int
    title:      str
    artist:     str
    album:      Optional[str] = None
    genre:      Optional[str] = None
    duration_s: Optional[int] = None

    class Config:
        from_attributes = True


class PlayEvent(BaseModel):
    song_id:        int
    skipped:        bool         = False
    liked:          bool         = False
    replayed:       bool         = False
    play_duration_s: Optional[int] = None


# ── Recommendations ───────────────────────────────────────────────

class RecommendedSong(BaseModel):
    song_id:     int
    title:       str
    artist:      str
    album:       Optional[str]   = None
    genre:       Optional[str]   = None
    score:       float
    explanation: str
    artist_id:   Optional[int]   = None

    # GenAI / Hybrid — 30-second iTunes preview + cover art
    preview_url: Optional[str]   = None
    cover_url:   Optional[str]   = None

    # Hybrid only — individual pipeline scores for comparison dashboard
    analytics_score: Optional[float] = None
    genai_score:     Optional[float] = None


class RecommendationResponse(BaseModel):
    mode:            RecommendationMode
    recommendations: list[RecommendedSong]
    latency_ms:      int
    timestamp:       datetime
    count:           int
    query_text:      Optional[str] = None
    # Set when a pipeline fell back to an alternative strategy.
    # Values: "cold_start_popular" | "analytics_failed" | "genai_failed" |
    #         "both_failed_using_popular" | "error: <reason>"
    fallback_used:   Optional[str] = None


class RecommendationRequest(BaseModel):
    mode:       RecommendationMode = RecommendationMode.ANALYTICS
    count:      int                = 10
    query_text: Optional[str]      = None


# ── Health ────────────────────────────────────────────────────────

class ServiceHealth(BaseModel):
    status:     str
    latency_ms: Optional[int] = None
    detail:     Optional[str] = None


class HealthResponse(BaseModel):
    overall:  str
    postgres: ServiceHealth
    redis:    ServiceHealth
