"""
GenAI Pipeline — Sentence Transformer Embeddings
=================================================

FIX B4: artist_id was never set in GenAI/Hybrid responses.
  SongCard's "click artist name" navigation to /artists/{id} was broken
  for every GenAI and Hybrid song because _save_song_to_db() only
  returned song_id. Fixed: returns (song_id, artist_id) tuple.

FIX B8: iTunes songs had identical placeholder audio features.
  Every iTunes song was inserted with tempo=120, energy=0.5, dance=0.5,
  valence=0.5, mfcc_1-5=0. In the Analytics pipeline all iTunes-origin
  songs looked identical to FCM and lookalike scorers.
  Fixed: genre-based feature vectors from GENRE_VECTORS (same dict used
  by onboarding.py) give each iTunes song a realistic feature estimate.

FIX PERF: Batch song existence check.
  The old code did 1 SELECT per song in the candidate list (N+1 pattern).
  Now a single SELECT ... WHERE mb_id = ANY(:ids) checks all candidates
  at once. Only new songs go through the full insert path.
"""
import asyncio
import hashlib
import json
import time
from datetime import datetime, timezone
from typing import Optional

import httpx
import numpy as np
import structlog
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.schemas.recommendation import (
    RecommendationMode,
    RecommendationResponse,
    RecommendedSong,
)

logger = structlog.get_logger()

# ── Singleton model ───────────────────────────────────────────────
_embedding_model = None


def get_embedding_model():
    global _embedding_model
    if _embedding_model is None:
        try:
            from sentence_transformers import SentenceTransformer
            logger.info("loading_embedding_model", model="all-mpnet-base-v2")
            _embedding_model = SentenceTransformer("all-mpnet-base-v2")
            logger.info("embedding_model_loaded")
        except ImportError:
            logger.error("sentence_transformers_not_installed")
        except Exception as exc:
            logger.error("embedding_model_load_failed", error=str(exc))
    return _embedding_model


def cosine_similarity(query_vec: np.ndarray, song_vecs: np.ndarray) -> np.ndarray:
    query_norm = query_vec / (np.linalg.norm(query_vec) + 1e-10)
    song_norms = song_vecs / (np.linalg.norm(song_vecs, axis=1, keepdims=True) + 1e-10)
    return song_norms @ query_norm


def build_song_text(song: dict) -> str:
    parts = [
        song.get("title", ""),
        song.get("artist", ""),
        song.get("genre", ""),
        song.get("album", ""),
    ]
    return " ".join(p for p in parts if p).strip()


def build_query_text(query_text: Optional[str], history: list[dict]) -> str:
    if query_text and len(query_text.strip()) > 2:
        if history:
            genres  = list(dict.fromkeys(h["genre"]  for h in history[:5] if h.get("genre")))
            artists = list(dict.fromkeys(h["artist"] for h in history[:3]))
            taste   = ", ".join(genres[:3])
            return (
                f"{query_text.strip()} | listener enjoys: {', '.join(artists[:2])}"
                + (f" | genres: {taste}" if taste else "")
            )
        return query_text.strip()
    if history:
        artists = list(dict.fromkeys(h["artist"] for h in history[:5]))
        genres  = list(dict.fromkeys(h["genre"]  for h in history[:5] if h.get("genre")))
        return f"{' '.join(artists[:3])} {' '.join(genres[:2])} music"
    return "popular music"


# ── FIX B8: Genre-based feature vectors for iTunes songs ─────────
# Instead of identical placeholder values (tempo=120, energy=0.5 for ALL),
# use genre-appropriate centroids so iTunes songs have distinct feature
# profiles in the Analytics pipeline's FCM and lookalike scorer.
# These are the same vectors as onboarding.py GENRE_VECTORS (reused).
ITUNES_GENRE_FEATURES: dict[str, dict] = {
    "pop":        dict(tempo=118, energy=0.72, danceability=0.74, valence=0.63,
                       loudness=-7.0, key=5, mfcc_1=0.20, mfcc_2=0.10, mfcc_3=0.00, mfcc_4=0.10, mfcc_5=0.00),
    "hip-hop/rap":dict(tempo=95,  energy=0.65, danceability=0.82, valence=0.44,
                       loudness=-6.0, key=8, mfcc_1=0.30, mfcc_2=0.20, mfcc_3=0.10, mfcc_4=0.00, mfcc_5=0.10),
    "hip hop":    dict(tempo=95,  energy=0.65, danceability=0.82, valence=0.44,
                       loudness=-6.0, key=8, mfcc_1=0.30, mfcc_2=0.20, mfcc_3=0.10, mfcc_4=0.00, mfcc_5=0.10),
    "rock":       dict(tempo=130, energy=0.85, danceability=0.48, valence=0.42,
                       loudness=-5.0, key=7, mfcc_1=0.40, mfcc_2=0.30, mfcc_3=0.20, mfcc_4=0.10, mfcc_5=0.00),
    "alternative":dict(tempo=125, energy=0.75, danceability=0.50, valence=0.44,
                       loudness=-6.0, key=7, mfcc_1=0.35, mfcc_2=0.25, mfcc_3=0.15, mfcc_4=0.10, mfcc_5=0.05),
    "electronic": dict(tempo=128, energy=0.80, danceability=0.75, valence=0.53,
                       loudness=-7.0, key=6, mfcc_1=0.10, mfcc_2=0.20, mfcc_3=0.30, mfcc_4=0.20, mfcc_5=0.10),
    "dance":      dict(tempo=126, energy=0.82, danceability=0.80, valence=0.60,
                       loudness=-6.5, key=6, mfcc_1=0.15, mfcc_2=0.20, mfcc_3=0.25, mfcc_4=0.20, mfcc_5=0.10),
    "jazz":       dict(tempo=105, energy=0.35, danceability=0.52, valence=0.65,
                       loudness=-12.0, key=9, mfcc_1=0.00, mfcc_2=0.10, mfcc_3=0.20, mfcc_4=0.30, mfcc_5=0.40),
    "classical":  dict(tempo=90,  energy=0.22, danceability=0.28, valence=0.58,
                       loudness=-15.0, key=0, mfcc_1=0.10, mfcc_2=0.00, mfcc_3=0.10, mfcc_4=0.40, mfcc_5=0.50),
    "r&b/soul":   dict(tempo=90,  energy=0.55, danceability=0.76, valence=0.56,
                       loudness=-8.0, key=5, mfcc_1=0.20, mfcc_2=0.30, mfcc_3=0.10, mfcc_4=0.10, mfcc_5=0.20),
    "country":    dict(tempo=120, energy=0.60, danceability=0.58, valence=0.68,
                       loudness=-8.0, key=2, mfcc_1=0.25, mfcc_2=0.15, mfcc_3=0.10, mfcc_4=0.15, mfcc_5=0.10),
    "latin":      dict(tempo=110, energy=0.70, danceability=0.78, valence=0.72,
                       loudness=-7.0, key=4, mfcc_1=0.15, mfcc_2=0.25, mfcc_3=0.20, mfcc_4=0.10, mfcc_5=0.15),
    "bollywood":  dict(tempo=104, energy=0.60, danceability=0.68, valence=0.72,
                       loudness=-8.0, key=4, mfcc_1=0.10, mfcc_2=0.20, mfcc_3=0.30, mfcc_4=0.10, mfcc_5=0.20),
    "indie":      dict(tempo=115, energy=0.52, danceability=0.55, valence=0.48,
                       loudness=-9.0, key=3, mfcc_1=0.30, mfcc_2=0.10, mfcc_3=0.20, mfcc_4=0.20, mfcc_5=0.10),
    "metal":      dict(tempo=160, energy=0.95, danceability=0.35, valence=0.25,
                       loudness=-3.0, key=7, mfcc_1=0.50, mfcc_2=0.40, mfcc_3=0.30, mfcc_4=0.10, mfcc_5=0.05),
    "blues":      dict(tempo=100, energy=0.45, danceability=0.55, valence=0.42,
                       loudness=-10.0, key=9, mfcc_1=0.30, mfcc_2=0.20, mfcc_3=0.15, mfcc_4=0.20, mfcc_5=0.25),
}
# Neutral fallback for genres not in the map
_DEFAULT_FEATURES = dict(tempo=120, energy=0.55, danceability=0.58, valence=0.52,
                         loudness=-9.0, key=5, mfcc_1=0.15, mfcc_2=0.15, mfcc_3=0.10, mfcc_4=0.10, mfcc_5=0.10)


def _genre_features(genre: str) -> dict:
    """Return the best-matching feature vector for an iTunes genre string."""
    g = genre.lower().strip()
    # Exact match first
    if g in ITUNES_GENRE_FEATURES:
        return ITUNES_GENRE_FEATURES[g]
    # Substring match
    for key, vec in ITUNES_GENRE_FEATURES.items():
        if key in g or g in key:
            return vec
    return _DEFAULT_FEATURES


# Redis key prefix for cached song embedding vectors
_EMB_KEY_PREFIX = "songvec:"
_EMB_TTL        = 86400   # 24 hours


class GenAIPipeline:

    def __init__(self, db: AsyncSession, redis=None):
        self.db    = db
        self.redis = redis

    # ── Public entry point ───────────────────────────────────────

    async def recommend(
        self,
        user_id: int,
        count: int = 10,
        query_text: Optional[str] = None,
        analytics_hints: Optional[list[dict]] = None,
    ) -> RecommendationResponse:
        start = time.time()

        history       = await self._get_user_history(user_id)
        is_cold_start = len(history) < 10  # raised from 5: vibe-check seeds 3 songs

        search_queries = self._build_search_queries(history, query_text, is_cold_start)
        logger.info("genai_search_queries", queries=search_queries)

        candidates = await self._search_itunes(search_queries)
        logger.info("genai_itunes_results", count=len(candidates))

        if len(candidates) < 5:
            logger.warning("itunes_insufficient_results", found=len(candidates))
            candidates += await self._get_db_candidates(limit=20)

        if not candidates:
            return self._empty_response(start, query_text, "No candidates found")

        # ── Result-level cache ────────────────────────────────────
        cache_key = self._cache_key(user_id, query_text or "")
        cached    = await self._get_cache(cache_key)
        if cached:
            logger.info("genai_result_cache_hit", user_id=user_id)
            recs = [RecommendedSong(**r) for r in cached]
            return RecommendationResponse(
                mode=RecommendationMode.GENAI,
                recommendations=recs[:count],
                latency_ms=int((time.time() - start) * 1000),
                timestamp=datetime.now(timezone.utc),
                count=len(recs[:count]),
                query_text=query_text,
            )

        recs = await self._rank_with_embeddings(candidates, history, query_text, count)
        await self._set_cache(cache_key, [r.model_dump() for r in recs])

        latency_ms = int((time.time() - start) * 1000)
        logger.info("genai_recommend", user_id=user_id, latency_ms=latency_ms,
                    cold_start=is_cold_start, count=len(recs))

        return RecommendationResponse(
            mode=RecommendationMode.GENAI,
            recommendations=recs,
            latency_ms=latency_ms,
            timestamp=datetime.now(timezone.utc),
            count=len(recs),
            query_text=query_text,
        )

    # ── Embedding-based ranking with per-song vector cache ───────

    async def _rank_with_embeddings(
        self,
        candidates: list[dict],
        history: list[dict],
        query_text: Optional[str],
        count: int,
    ) -> list[RecommendedSong]:
        model = get_embedding_model()

        if model is None:
            logger.warning("embedding_model_unavailable_using_fallback")
            return await self._fallback_by_rank(candidates, count)

        query_str  = build_query_text(query_text, history)
        song_texts = [build_song_text(c) for c in candidates]

        # ── FIX PERF: Batch existence check for all candidates ───
        # Old code: 1 SELECT per song (up to 45 queries per request)
        # New code: 1 SELECT with ANY(:ids) for all candidates at once
        itunes_ids = [c["itunes_id"] for c in candidates]
        existing_rows = (await self.db.execute(
            text("SELECT id, mb_id, artist_id FROM songs WHERE mb_id = ANY(:ids)"),
            {"ids": itunes_ids},
        )).fetchall()
        existing_map: dict[str, tuple[int, int]] = {
            row.mb_id: (row.id, row.artist_id) for row in existing_rows
        }

        # ── Per-song embedding cache ─────────────────────────────
        cached_vecs:       dict[int, np.ndarray] = {}
        to_encode_indices: list[int]             = []

        if self.redis:
            for i, c in enumerate(candidates):
                key = f"{_EMB_KEY_PREFIX}{c['itunes_id']}"
                try:
                    raw = await self.redis.get(key)
                    if raw:
                        cached_vecs[i] = np.frombuffer(raw, dtype=np.float32)
                    else:
                        to_encode_indices.append(i)
                except Exception:
                    to_encode_indices.append(i)
        else:
            to_encode_indices = list(range(len(candidates)))

        logger.info("embedding_cache", hits=len(cached_vecs), misses=len(to_encode_indices))

        texts_to_encode = [query_str] + [song_texts[i] for i in to_encode_indices]
        t0              = time.time()
        new_embeds      = model.encode(texts_to_encode, batch_size=64, show_progress_bar=False)
        logger.info("embeddings_computed", n=len(texts_to_encode), ms=int((time.time() - t0) * 1000))

        query_vec = new_embeds[0]

        for j, i in enumerate(to_encode_indices):
            vec = new_embeds[1 + j]
            cached_vecs[i] = vec
            if self.redis:
                key = f"{_EMB_KEY_PREFIX}{candidates[i]['itunes_id']}"
                try:
                    await self.redis.setex(key, _EMB_TTL, vec.astype(np.float32).tobytes())
                except Exception:
                    pass

        song_vecs      = np.array([cached_vecs[i] for i in range(len(candidates))])
        scores         = cosine_similarity(query_vec, song_vecs)
        ranked_indices = np.argsort(scores)[::-1]

        recs = []
        for idx in ranked_indices:
            if len(recs) >= count:
                break
            candidate = candidates[idx]
            score     = float(scores[idx])

            # FIX B4: get both song_id AND artist_id from the DB save
            db_id, db_artist_id = await self._save_song_to_db(candidate, existing_map)
            if not db_id:
                continue

            recs.append(
                RecommendedSong(
                    song_id=db_id,
                    artist_id=db_artist_id,   # FIX B4: was always None before
                    title=candidate["title"],
                    artist=candidate["artist"],
                    album=candidate.get("album"),
                    genre=candidate.get("genre", "Unknown"),
                    score=round(score, 3),
                    explanation=self._score_to_explanation(score, query_text, candidate),
                    preview_url=candidate.get("preview_url"),
                    cover_url=candidate.get("cover_url"),
                )
            )

        return recs

    def _score_to_explanation(self, score: float, query_text: Optional[str], candidate: dict) -> str:
        genre  = candidate.get("genre", "")
        artist = candidate.get("artist", "")
        if score > 0.7:     strength = "Strong match"
        elif score > 0.5:   strength = "Good match"
        elif score > 0.3:   strength = "Related"
        else:               strength = "Suggested"

        if query_text:
            return f"{strength} for '{query_text}' — {genre} by {artist}"
        return f"{strength} based on your listening history — {genre} by {artist}"

    # ── iTunes search ────────────────────────────────────────────

    async def _search_itunes(self, queries: list[str]) -> list[dict]:
        async def search_one(query: str) -> list[dict]:
            try:
                async with httpx.AsyncClient(timeout=4) as client:
                    resp = await client.get(
                        "https://itunes.apple.com/search",
                        params={"term": query, "media": "music", "entity": "song",
                                "limit": 15, "country": "US"},
                    )
                    resp.raise_for_status()
                    songs = resp.json().get("results", [])
                    valid = [self._normalize_itunes(s) for s in songs if self._valid_itunes(s)]
                    logger.info("itunes_search", query=query, found=len(valid))
                    return valid
            except Exception as exc:
                logger.warning("itunes_search_error", query=query, error=str(exc))
                return []

        results = await asyncio.gather(*[search_one(q) for q in queries], return_exceptions=True)

        seen_ids: set[str]   = set()
        combined: list[dict] = []
        for batch in results:
            if isinstance(batch, Exception):
                continue
            for track in batch:
                if track["itunes_id"] not in seen_ids:
                    seen_ids.add(track["itunes_id"])
                    combined.append(track)

        logger.info("itunes_combined", total=len(combined), queries=len(queries))
        return combined

    def _valid_itunes(self, t: dict) -> bool:
        return bool(t.get("trackId") and t.get("trackName") and t.get("artistName"))

    def _normalize_itunes(self, t: dict) -> dict:
        return {
            "itunes_id":   str(t["trackId"]),
            "title":       t.get("trackName",        "Unknown")[:255],
            "artist":      t.get("artistName",       "Unknown")[:255],
            "album":       t.get("collectionName",   "")[:255],
            "genre":       t.get("primaryGenreName", "Unknown"),
            "duration_s":  int(t.get("trackTimeMillis", 0) / 1000),
            "preview_url": t.get("previewUrl", ""),
            "cover_url":   t.get("artworkUrl100", "").replace("100x100bb", "300x300bb"),
            "rank": int(t.get("trackCount", 0)),
        }

    # ── Vibe translation: query → music search terms ─────────────
    # Instead of searching iTunes literally for the user's words,
    # we translate the query into music-appropriate vibe descriptors.
    # This means "2am sad" → "melancholic indie ballads" not "2am sad".

    # Maps input patterns → (primary_search, secondary_search)
    VIBE_MAP: list[tuple[tuple[str, ...], tuple[str, str]]] = [
        # Time of day / atmosphere
        (("2am", "3am", "late night", "midnight", "night drive"),
         ("midnight indie melancholy", "atmospheric nocturnal")),
        (("morning", "sunrise", "wake up", "fresh start"),
         ("uplifting morning acoustic", "feel good start")),
        (("evening", "sunset", "golden hour"),
         ("mellow evening chill", "warm acoustic sunset")),

        # Emotions
        (("sad", "heartbreak", "cry", "miss", "broken", "lonely", "depressed"),
         ("emotional ballads heartbreak", "melancholic soul")),
        (("happy", "joy", "celebrate", "good mood", "sunshine"),
         ("feel good upbeat pop", "happy energy hits")),
        (("angry", "rage", "frustrated", "mad"),
         ("intense driving rock", "aggressive energy")),
        (("nostalgic", "throwback", "memories", "old school"),
         ("nostalgic throwback classics", "retro hits")),
        (("romantic", "love", "date", "crush"),
         ("romantic love songs", "smooth R&B soul")),
        (("anxious", "stressed", "nervous", "overwhelmed"),
         ("calming ambient soothing", "peaceful relaxing")),
        (("confident", "boss", "power", "unstoppable"),
         ("confident power anthems", "motivational hip hop")),

        # Activity
        (("workout", "gym", "run", "exercise", "training", "lift"),
         ("high energy workout music", "gym motivation beats")),
        (("study", "focus", "concentrate", "work", "coding"),
         ("lo-fi focus study beats", "instrumental concentration")),
        (("party", "club", "dance floor", "turn up"),
         ("dance party club hits", "electronic dance banger")),
        (("chill", "relax", "unwind", "lounge", "lazy"),
         ("chill lo-fi relaxing", "laid back smooth vibes")),
        (("sleep", "insomnia", "rest", "peaceful"),
         ("ambient sleep music", "calm piano meditation")),
        (("drive", "road trip", "car"),
         ("road trip driving playlist", "indie rock open road")),
        (("meditation", "mindful", "zen", "yoga"),
         ("meditation ambient peaceful", "yoga instrumental flow")),

        # Genres/styles
        (("jazz", "smooth", "saxophone"),
         ("smooth jazz instrumental", "neo soul jazz")),
        (("hip hop", "rap", "bars", "freestyle"),
         ("hip hop rap beats", "conscious rap")),
        (("rock", "guitar", "band", "alternative"),
         ("alternative indie rock", "guitar driven rock")),
        (("pop", "mainstream", "catchy"),
         ("catchy pop anthems", "mainstream pop hits")),
        (("electronic", "edm", "techno", "house"),
         ("electronic dance music", "house techno beats")),
        (("classical", "orchestra", "piano", "violin"),
         ("classical piano instrumental", "orchestral cinematic")),
        (("bollywood", "hindi", "indian"),
         ("bollywood hits hindi songs", "indian pop")),
        (("acoustic", "unplugged", "stripped"),
         ("acoustic guitar singer songwriter", "unplugged folk")),
        (("indie", "underground", "alternative"),
         ("indie alternative underground", "indie folk pop")),
        (("rnb", "r&b", "soul", "funk"),
         ("R&B soul smooth", "neo soul rhythm")),

        # Specific vibes
        (("summer", "beach", "tropical"),
         ("summer beach pop", "tropical vibes")),
        (("rainy day", "rain", "storm", "weather"),
         ("rainy day melancholy indie", "cozy rainy acoustic")),
        (("empowerment", "feminist", "strong", "woman"),
         ("female empowerment anthems", "strong women pop")),
        (("old school", "vintage", "classic", "70s", "80s", "90s"),
         ("classic vintage hits", "retro throwback")),
        (("new", "fresh", "2024", "2025", "trending"),
         ("trending new music 2025", "fresh pop hits")),
    ]

    def _translate_query_to_vibe(self, query_text: str) -> list[str]:
        """
        Translates a free-text user query into music-appropriate search terms.
        Returns 1-2 vibe-based search strings instead of the raw query.

        Example: "2am sad crying" → ["midnight indie melancholy", "emotional ballads heartbreak"]
        Example: "happy workout"  → ["high energy workout music", "feel good upbeat pop"]
        """
        q_lower = query_text.lower().strip()
        matched_vibes: list[str] = []

        for keywords, (primary, secondary) in self.VIBE_MAP:
            for kw in keywords:
                if kw in q_lower:
                    if primary not in matched_vibes:
                        matched_vibes.append(primary)
                    if secondary not in matched_vibes:
                        matched_vibes.append(secondary)
                    break  # Only one match per vibe category

        if not matched_vibes:
            # No known vibe patterns — construct a music-context query
            # by appending "music" or "songs" to make it iTunes-friendly
            words = q_lower.split()
            filtered = [w for w in words if len(w) > 2 and w not in {"the", "and", "for", "with", "that"}]
            if filtered:
                matched_vibes.append(" ".join(filtered[:3]) + " music")
            else:
                matched_vibes.append("popular music")

        logger.info("vibe_translation", original=query_text, vibes=matched_vibes[:2])
        return matched_vibes[:2]

    # ── Search query builder ─────────────────────────────────────

    def _build_search_queries(self, history: list[dict], query_text: Optional[str],
                               is_cold_start: bool) -> list[str]:
        queries: list[str] = []

        if query_text and len(query_text.strip()) > 2:
            vibe_queries = self._translate_query_to_vibe(query_text.strip())
            queries.extend(vibe_queries)
            # FIX: When an explicit mood/vibe query is provided, return ONLY those
            # vibe-translated terms. The old code always appended history-based
            # artist and genre queries on top, so searching 'party' would also fire
            # queries for sad artists the user previously listened to — completely
            # defeating the mood tag intent.
            seen_q: set[str] = set()
            unique_q: list[str] = []
            for q in queries:
                ql = q.lower().strip()
                if ql not in seen_q and len(ql) > 2:
                    seen_q.add(ql)
                    unique_q.append(q)
            return unique_q[:5]

        if history:
            # Use genres and artists from whatever history exists,
            # even if < 5 entries (vibe-check seed songs count too)
            seen_genres:  set[str] = set()
            seen_artists: set[str] = set()
            for song in history[:5]:
                genre  = (song.get("genre") or "").strip()
                artist = (song.get("artist") or "").strip()
                if genre and len(genre) > 2 and genre.lower() not in seen_genres:
                    seen_genres.add(genre.lower())
                    queries.append(f"best {genre} songs")
                if artist and len(artist) > 2 and artist not in seen_artists:
                    seen_artists.add(artist)
                    queries.append(artist)

        if is_cold_start or not queries:
            # True cold start: user has no history and no vibe check.
            # Use a deliberately diverse set of queries so the user gets
            # variety across genres rather than just mainstream pop.
            queries.extend([
                "top rock songs",
                "best hip hop",
                "popular pop music",
                "jazz classics",
                "electronic music hits",
                "indie folk",
                "r&b soul",
            ])

        seen: set[str]    = set()
        unique: list[str] = []
        for q in queries:
            q_lower = q.lower().strip()
            if q_lower not in seen and len(q_lower) > 2:
                seen.add(q_lower)
                unique.append(q)

        return unique[:5]  # raised from 3 → 5 for cold start diversity

    # ── DB helpers ────────────────────────────────────────────────

    async def _save_song_to_db(
        self,
        track: dict,
        existing_map: dict[str, tuple[int, int]] | None = None,
    ) -> tuple[Optional[int], Optional[int]]:
        """
        FIX B4: now returns (song_id, artist_id) so callers can populate
                the artist_id field on RecommendedSong.
        FIX B8: uses genre-based feature vectors instead of uniform placeholders.
        FIX PERF: accepts a pre-fetched existing_map to skip per-song SELECT.
        """
        try:
            # ── Fast path: DB-origin song (from _get_db_candidates fallback) ─
            # These already have a real row — just return its ids; no INSERT.
            if "_db_song_id" in track:
                return track["_db_song_id"], track.get("_db_artist_id")

            # ── Fast path: song already in DB (from batch prefetch) ──
            if existing_map and track["itunes_id"] in existing_map:
                song_id, artist_id = existing_map[track["itunes_id"]]
                return song_id, artist_id

            # ── Fallback single-song check (for _fallback_by_rank) ──
            existing = (await self.db.execute(
                text("SELECT id, artist_id FROM songs WHERE mb_id = :mb_id"),
                {"mb_id": track["itunes_id"]},
            )).fetchone()
            if existing:
                return existing.id, existing.artist_id

            # ── Genre ─────────────────────────────────────────────
            genre_name = track.get("genre", "Unknown")[:100]
            genre_id   = (await self.db.execute(
                text("SELECT id FROM genres WHERE name = :name"),
                {"name": genre_name},
            )).scalar_one_or_none()
            if not genre_id:
                await self.db.execute(
                    text("INSERT INTO genres (name) VALUES (:name)"),
                    {"name": genre_name},
                )
                genre_id = (await self.db.execute(
                    text("SELECT id FROM genres WHERE name = :name"),
                    {"name": genre_name},
                )).scalar_one_or_none()

            # ── Artist ────────────────────────────────────────────
            artist_name = track.get("artist", "Unknown")[:255]
            artist_id   = (await self.db.execute(
                text("SELECT id FROM artists WHERE name = :name"),
                {"name": artist_name},
            )).scalar_one_or_none()
            if not artist_id:
                await self.db.execute(
                    text("INSERT INTO artists (name) VALUES (:name)"),
                    {"name": artist_name},
                )
                artist_id = (await self.db.execute(
                    text("SELECT id FROM artists WHERE name = :name"),
                    {"name": artist_name},
                )).scalar_one_or_none()

            # ── Song ──────────────────────────────────────────────
            song_id = (await self.db.execute(
                text("""
                    INSERT INTO songs
                        (title, artist_id, genre_id, duration_s, mb_id, play_count)
                    VALUES (:title, :artist_id, :genre_id, :duration_s, :mb_id, 0)
                    RETURNING id
                """),
                {
                    "title":      track["title"][:255],
                    "artist_id":  artist_id,
                    "genre_id":   genre_id,
                    "duration_s": track.get("duration_s", 0),
                    "mb_id":      track["itunes_id"],
                },
            )).scalar_one()

            # ── FIX B8: Use genre-based audio features ────────────
            # Old code: ALL iTunes songs got tempo=120, energy=0.5, mfcc=0
            # This made them indistinguishable in the Analytics pipeline.
            # Fixed: use genre-specific centroids from ITUNES_GENRE_FEATURES.
            feats = _genre_features(track.get("genre", ""))
            await self.db.execute(
                text("""
                    INSERT INTO song_features
                        (song_id, tempo, energy, danceability, valence,
                         loudness, key, mfcc_1, mfcc_2, mfcc_3, mfcc_4, mfcc_5)
                    VALUES
                        (:song_id, :tempo, :energy, :dance, :valence,
                         :loudness, :key, :m1, :m2, :m3, :m4, :m5)
                """),
                {
                    "song_id": song_id,
                    "tempo":   feats["tempo"],
                    "energy":  feats["energy"],
                    "dance":   feats["danceability"],
                    "valence": feats["valence"],
                    "loudness":feats["loudness"],
                    "key":     feats["key"],
                    "m1":      feats["mfcc_1"],
                    "m2":      feats["mfcc_2"],
                    "m3":      feats["mfcc_3"],
                    "m4":      feats["mfcc_4"],
                    "m5":      feats["mfcc_5"],
                },
            )
            await self.db.flush()
            logger.info("new_song_saved", title=track["title"], artist=track["artist"],
                        genre=track.get("genre"))
            return song_id, artist_id

        except Exception as exc:
            logger.warning("save_song_failed", error=str(exc), track=track.get("title"))
            await self.db.rollback()
            return None, None

    async def _fallback_by_rank(self, candidates: list[dict], count: int) -> list[RecommendedSong]:
        sorted_candidates = sorted(candidates, key=lambda x: x.get("rank", 0), reverse=True)
        recs = []
        for i, c in enumerate(sorted_candidates[:count]):
            db_id, db_artist_id = await self._save_song_to_db(c)
            if db_id:
                recs.append(RecommendedSong(
                    song_id=db_id,
                    artist_id=db_artist_id,
                    title=c["title"],
                    artist=c["artist"],
                    album=c.get("album"),
                    genre=c.get("genre", "Unknown"),
                    score=round(1.0 - i * 0.05, 2),
                    explanation="Popular track",
                    preview_url=c.get("preview_url"),
                    cover_url=c.get("cover_url"),
                ))
        return recs

    async def _get_user_history(self, user_id: int, limit: int = 15) -> list[dict]:
        result = await self.db.execute(
            text("""
                SELECT s.title, a.name AS artist, g.name AS genre
                FROM play_history ph
                JOIN songs   s ON s.id = ph.song_id
                JOIN artists a ON a.id = s.artist_id
                LEFT JOIN genres g ON g.id = s.genre_id
                WHERE ph.user_id = :uid AND ph.skipped = false
                ORDER BY ph.played_at DESC
                LIMIT :lim
            """),
            {"uid": user_id, "lim": limit},
        )
        return [{"title": r.title, "artist": r.artist, "genre": r.genre or ""}
                for r in result.fetchall()]

    async def _get_db_candidates(self, limit: int = 10) -> list[dict]:
        result = await self.db.execute(
            text("""
                SELECT s.id, s.title, s.artist_id, a.name AS artist, g.name AS genre
                FROM songs   s
                JOIN artists a  ON a.id = s.artist_id
                LEFT JOIN genres g ON g.id = s.genre_id
                ORDER BY s.play_count DESC
                LIMIT :limit
            """),
            {"limit": limit},
        )
        return [
            {
                # FIX: tag with _db_song_id / _db_artist_id so _save_song_to_db
                # can fast-return without hitting INSERT.  Old code used a
                # synthetic mb_id like "db_42" which caused a duplicate song row
                # to be created (new record with mb_id="db_42" for a song that
                # already existed as id=42 with a real mb_id).
                "itunes_id":     f"db_{r.id}",
                "_db_song_id":   r.id,
                "_db_artist_id": r.artist_id,
                "title":         r.title,
                "artist":        r.artist,
                "genre":         r.genre,
                "preview_url":   None,
                "cover_url":     None,
                "album":         "",
                "duration_s":    0,
                "rank":          0,
            }
            for r in result.fetchall()
        ]

    # ── Redis helpers ─────────────────────────────────────────────

    def _cache_key(self, user_id: int, query: str) -> str:
        h = hashlib.md5(f"{user_id}:{query}".encode()).hexdigest()[:12]
        return f"genai_v5:{user_id}:{h}"

    async def _get_cache(self, key: str) -> Optional[list]:
        if not self.redis:
            return None
        try:
            val = await self.redis.get(key)
            return json.loads(val) if val else None
        except Exception:
            return None

    async def _set_cache(self, key: str, data: list) -> None:
        if not self.redis:
            return
        try:
            await self.redis.setex(key, settings.GENAI_CACHE_TTL, json.dumps(data))
        except Exception:
            pass

    def _empty_response(self, start: float, query_text: Optional[str], error: str) -> RecommendationResponse:
        return RecommendationResponse(
            mode=RecommendationMode.GENAI,
            recommendations=[],
            latency_ms=int((time.time() - start) * 1000),
            timestamp=datetime.now(timezone.utc),
            count=0,
            query_text=query_text,
            fallback_used=f"error: {error}",
        )
