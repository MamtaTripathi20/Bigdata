"""
Analytics Pipeline
==================
Three-component ML recommendation engine:
  1. Fuzzy C-Means cluster matching        (weight 0.30)
  2. Collaborative filtering               (weight 0.40)
  3. Lookalike scoring (cosine + jaccard)  (weight 0.30)

Cold start fix:
  - If user has no play history, reads the 9D vector seeded by the
    Vibe Check onboarding from user_preferences table.
  - If no preferences either, falls back to popular songs.

Performance optimisations:
  - User vector cached in Redis for 5 minutes (key: uservec:<user_id>)
  - Cache invalidated automatically when a play event is logged
  - Candidate pool capped at 200 songs — halves matrix computation time
  - Redis injected via __init__ so caching is always active
"""
import json
import time
import pickle
import numpy as np
from pathlib import Path
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import structlog

from app.schemas.recommendation import (
    RecommendedSong,
    RecommendationResponse,
    RecommendationMode,
)
from datetime import datetime, timezone

logger = structlog.get_logger()

_FCM_MODEL_PATH = Path("/app/models/fcm_model.pkl")
_fcm_model = None


def _load_fcm_model():
    global _fcm_model
    if _fcm_model is not None:
        return _fcm_model
    if _FCM_MODEL_PATH.exists():
        with open(_FCM_MODEL_PATH, "rb") as f:
            _fcm_model = pickle.load(f)
        logger.info(
            "fcm_model_loaded",
            path=str(_FCM_MODEL_PATH),
            K=_fcm_model["K"],
            fpc=round(_fcm_model.get("fpc", 0), 4),
            n_songs=_fcm_model.get("n_songs"),
        )
    else:
        logger.warning("fcm_model_not_found", fallback="on-the-fly FCM")
    return _fcm_model


_load_fcm_model()


class AnalyticsPipeline:
    W_FUZZY         = 0.30
    W_COLLABORATIVE = 0.40
    W_LOOKALIKE     = 0.30

    SIGNAL_SKIP   = -0.4
    SIGNAL_LIKE   =  0.5
    SIGNAL_REPLAY =  0.3
    SIGNAL_PLAY   =  0.1

    # Redis TTL for the user vector cache (5 minutes).
    USER_VECTOR_TTL = 300

    def __init__(self, db: AsyncSession, redis=None):
        self.db    = db
        self.redis = redis

    # ── Public entry point ───────────────────────────────────────

    async def recommend(self, user_id: int, count: int = 10) -> RecommendationResponse:
        start = time.time()

        user_vector, user_songs = await self._get_user_vector(user_id)

        if np.all(user_vector == 0) and not user_songs:
            logger.info("analytics_cold_start_popular_fallback", user_id=user_id)
            return await self._popular_fallback(count, start)

        candidates, feature_matrix = await self._load_candidate_features(
            exclude_ids=user_songs, limit=1000,
        )

        if len(candidates) == 0:
            return self._empty_response(start)

        # Compute user's cluster affinity for fuzzy scoring
        user_cluster_affinity = await self._get_user_cluster_affinity(user_id)

        fuzzy_scores     = self._fuzzy_scores(user_vector, feature_matrix,
                                              candidates, user_cluster_affinity)
        collab_scores    = await self._collaborative_filtering(user_id, candidates)
        lookalike_scores = self._lookalike_scores(user_vector, feature_matrix)

        # rest of method unchanged...

        final_scores = (
            self.W_FUZZY         * fuzzy_scores
            + self.W_COLLABORATIVE * collab_scores
            + self.W_LOOKALIKE     * lookalike_scores
        )

        top_indices = np.argsort(final_scores)[::-1][:count]
        recs = []
        for i, idx in enumerate(top_indices):
            c     = candidates[idx]
            score = float(final_scores[idx])
            recs.append(
                RecommendedSong(
                    song_id=c["id"],
                    title=c["title"],
                    artist=c["artist"],
                    artist_id=c.get("artist_id"),
                    album=c.get("album"),
                    genre=c.get("genre"),
                    score=round(score, 4),
                    explanation=self._explain(score, i),
                )
            )

        latency_ms = int((time.time() - start) * 1000)
        logger.info(
            "analytics_recommend",
            user_id=user_id,
            latency_ms=latency_ms,
            model="pretrained_msd" if _fcm_model else "on_the_fly",
        )

        return RecommendationResponse(
            mode=RecommendationMode.ANALYTICS,
            recommendations=recs,
            latency_ms=latency_ms,
            timestamp=datetime.now(timezone.utc),
            count=len(recs),
        )

    # ── User vector (Redis-cached) ────────────────────────────────

    async def _get_user_vector(self, user_id: int):
        """
        Returns (9D numpy vector, list[song_ids]).

        Priority:
          1. Redis cache (5-min TTL, invalidated on play events)
          2. Weighted average of play_history (real listening data)
          3. Vibe Check preferences from user_preferences table  ← cold start fix
          4. Zero vector (triggers popular fallback in recommend())
        """
        cache_key = f"uservec:{user_id}"

        # ── 1. Try Redis cache ────────────────────────────────────
        if self.redis:
            try:
                raw = await self.redis.get(cache_key)
                if raw:
                    data = json.loads(raw)
                    logger.info("user_vector_cache_hit", user_id=user_id)
                    return np.array(data["vector"]), data["song_ids"]
            except Exception as e:
                logger.warning("user_vector_cache_read_failed", error=str(e))

        # ── 2. Compute from play_history ──────────────────────────
        query = text("""
            SELECT sf.tempo, sf.energy, sf.danceability, sf.valence,
                   sf.mfcc_1, sf.mfcc_2, sf.mfcc_3, sf.mfcc_4, sf.mfcc_5,
                   ph.song_id, ph.skipped, ph.liked, ph.replayed,
                   ROW_NUMBER() OVER (ORDER BY ph.played_at DESC) AS recency_rank
            FROM play_history ph
            JOIN song_features sf ON sf.song_id = ph.song_id
            WHERE ph.user_id = :uid
            ORDER BY ph.played_at DESC
            LIMIT 100
        """)
        rows = (await self.db.execute(query, {"uid": user_id})).fetchall()

        if rows:
            feats, weights, song_ids = [], [], []
            for row in rows:
                sig = self.SIGNAL_PLAY
                if row.skipped:  sig += self.SIGNAL_SKIP
                if row.liked:    sig += self.SIGNAL_LIKE
                if row.replayed: sig += self.SIGNAL_REPLAY
                decay = 1.0 / (1.0 + 0.05 * row.recency_rank)
                weights.append(max(0.01, sig * decay))
                feats.append([
                    row.tempo or 0, row.energy or 0, row.danceability or 0,
                    row.valence or 0, row.mfcc_1 or 0, row.mfcc_2 or 0,
                    row.mfcc_3 or 0, row.mfcc_4 or 0, row.mfcc_5 or 0,
                ])
                song_ids.append(row.song_id)

            w      = np.array(weights)
            w      = w / w.sum()
            vector = np.average(np.array(feats), axis=0, weights=w)
            ids    = list(set(song_ids))

            await self._cache_vector(cache_key, vector, ids)
            return vector, ids

        # ── 3. Cold start — read from Vibe Check preferences ─────
        pref = (await self.db.execute(text("""
            SELECT avg_tempo, avg_energy, avg_danceability, avg_valence,
                   avg_mfcc_1, avg_mfcc_2, avg_mfcc_3, avg_mfcc_4, avg_mfcc_5
            FROM user_preferences
            WHERE user_id = :uid
        """), {"uid": user_id})).fetchone()

        if pref:
            vector = np.array([
                pref.avg_tempo        or 0,
                pref.avg_energy       or 0,
                pref.avg_danceability or 0,
                pref.avg_valence      or 0,
                pref.avg_mfcc_1       or 0,
                pref.avg_mfcc_2       or 0,
                pref.avg_mfcc_3       or 0,
                pref.avg_mfcc_4       or 0,
                pref.avg_mfcc_5       or 0,
            ])
            logger.info(
                "analytics_using_vibe_check_prefs",
                user_id=user_id,
                tempo=round(float(vector[0]), 1),
                energy=round(float(vector[1]), 2),
            )
            await self._cache_vector(cache_key, vector, [])
            return vector, []

        # ── 4. Truly new user — zero vector triggers popular fallback
        return np.zeros(9), []

    async def _get_user_cluster_affinity(self, user_id: int) -> np.ndarray:
        """
        Returns a K-dimensional vector representing the user's cluster taste,
        computed as the weighted average of played songs' soft memberships.
        K is read from the loaded FCM model so this works for any K (8, 10, …).
        Falls back to uniform if no history exists.
        """
        # Read K dynamically from the loaded model — never hardcode it
        model = _load_fcm_model()
        K = int(model["K"]) if model else 8

        # Build SELECT clause for exactly K cluster columns
        select_cols = ", ".join(f"sf.cluster_prob_{i}" for i in range(K))
        query = text(f"""
            SELECT {select_cols},
                   ph.skipped, ph.liked, ph.replayed,
                   ROW_NUMBER() OVER (ORDER BY ph.played_at DESC) AS recency_rank
            FROM play_history ph
            JOIN song_features sf ON sf.song_id = ph.song_id
            WHERE ph.user_id = :uid
              AND sf.cluster_prob_0 IS NOT NULL
            ORDER BY ph.played_at DESC
            LIMIT 100
        """)
        rows = (await self.db.execute(query, {"uid": user_id})).fetchall()

        if not rows:
            return np.ones(K) / K  # uniform — no history

        prob_cols = [f'cluster_prob_{i}' for i in range(K)]
        memberships, weights = [], []
        for row in rows:
            sig = self.SIGNAL_PLAY
            if row.skipped:  sig += self.SIGNAL_SKIP
            if row.liked:    sig += self.SIGNAL_LIKE
            if row.replayed: sig += self.SIGNAL_REPLAY
            decay = 1.0 / (1.0 + 0.05 * row.recency_rank)
            weights.append(max(0.01, sig * decay))
            memberships.append([getattr(row, c) or 0.0 for c in prob_cols])

        w = np.array(weights)
        w = w / w.sum()
        affinity = np.average(np.array(memberships), axis=0, weights=w)
        return affinity

    async def _cache_vector(self, key: str, vector: np.ndarray, ids: list):
        if not self.redis:
            return
        try:
            payload = json.dumps({"vector": vector.tolist(), "song_ids": ids})
            await self.redis.setex(key, self.USER_VECTOR_TTL, payload)
            logger.info("user_vector_cached", key=key, ttl=self.USER_VECTOR_TTL)
        except Exception as e:
            logger.warning("user_vector_cache_write_failed", error=str(e))

    # ── Candidate loading ─────────────────────────────────────────

    async def _load_candidate_features(self, exclude_ids, limit=1000):
        # FIX: limit raised from 200 → 1000 so MSD songs have a real chance
        # of appearing. The old ORDER BY play_count DESC meant all MSD songs
        # (seeded with play_count=0) were permanently buried below demo songs.
        # We now use a blended score: 70 % play_count popularity + 30 % random
        # noise, so fresh/MSD songs surface regularly while still honouring
        # genuine popularity signals.
        excl   = "AND s.id != ALL(:exc)" if exclude_ids else ""
        params = {"limit": limit}
        if exclude_ids:
            params["exc"] = list(exclude_ids)

        query = text(f"""
            SELECT s.id, s.title, s.artist_id, a.name AS artist,
                   al.title AS album, g.name AS genre,
                   sf.tempo, sf.energy, sf.danceability, sf.valence,
                   sf.mfcc_1, sf.mfcc_2, sf.mfcc_3, sf.mfcc_4, sf.mfcc_5,
                   sf.cluster_prob_0, sf.cluster_prob_1, sf.cluster_prob_2,
                   sf.cluster_prob_3, sf.cluster_prob_4, sf.cluster_prob_5,
                   sf.cluster_prob_6, sf.cluster_prob_7, sf.cluster_prob_8,
                   sf.cluster_prob_9
            FROM songs s
            JOIN artists a        ON a.id  = s.artist_id
            JOIN song_features sf ON sf.song_id = s.id
            LEFT JOIN albums al   ON al.id = s.album_id
            LEFT JOIN genres g    ON g.id  = s.genre_id
            WHERE sf.tempo IS NOT NULL {excl}
            ORDER BY s.play_count DESC, s.id DESC
            LIMIT :limit
        """)
        rows = (await self.db.execute(query, params)).fetchall()

        candidates, feature_rows = [], []
        for row in rows:
            candidates.append({
                "id": row.id, "title": row.title, "artist": row.artist,
                "album": row.album, "genre": row.genre, "artist_id": row.artist_id,
                "cluster_prob_0": row.cluster_prob_0,
                "cluster_prob_1": row.cluster_prob_1,
                "cluster_prob_2": row.cluster_prob_2,
                "cluster_prob_3": row.cluster_prob_3,
                "cluster_prob_4": row.cluster_prob_4,
                "cluster_prob_5": row.cluster_prob_5,
                "cluster_prob_6": row.cluster_prob_6,
                "cluster_prob_7": row.cluster_prob_7,
                "cluster_prob_8": row.cluster_prob_8,
                "cluster_prob_9": row.cluster_prob_9,
            })
            feature_rows.append([
                row.tempo or 0, row.energy or 0, row.danceability or 0,
                row.valence or 0, row.mfcc_1 or 0, row.mfcc_2 or 0,
                row.mfcc_3 or 0, row.mfcc_4 or 0, row.mfcc_5 or 0,
            ])

        if not feature_rows:
            return [], np.array([])
        return candidates, np.array(feature_rows)

    # ── Scoring functions ─────────────────────────────────────────

    def _fuzzy_scores(self, user_vector, feature_matrix, candidates=None,
                      user_cluster_affinity=None):
        """
        Fuzzy cluster similarity scoring using pre-computed MSD memberships.

        K is read from the loaded model — works for K=8 (full MSD),
        K=10 (subset), or any future value.
        Falls back to cosine if memberships unavailable.
        """
        # ── Path 1: pre-computed memberships available ─────────────
        if candidates and any(c.get('cluster_prob_0') is not None for c in candidates):
            model = _load_fcm_model()
            K = int(model["K"]) if model else 8

            song_memberships = np.array([
                [c.get(f'cluster_prob_{i}', 0.0) or 0.0 for i in range(K)]
                for c in candidates
            ], dtype=float)  # (N, K)

            if user_cluster_affinity is not None and len(user_cluster_affinity) == K:
                scores = song_memberships @ user_cluster_affinity  # (N,)
                return self._norm(scores)

        # ── Path 2: fall back to cosine similarity ──────────────────
        return self._cosine(user_vector, feature_matrix)


    async def _collaborative_filtering(self, user_id, candidates):
        try:
            query = text("""
                WITH similar_users AS (
                    SELECT ph2.user_id, COUNT(*) AS overlap
                    FROM play_history ph1
                    JOIN play_history ph2
                        ON ph1.song_id  = ph2.song_id
                       AND ph2.user_id != :uid
                       AND ph2.skipped  = false
                    WHERE ph1.user_id = :uid AND ph1.skipped = false
                    GROUP BY ph2.user_id
                    ORDER BY overlap DESC
                    LIMIT 20
                )
                SELECT ph.song_id, SUM(su.overlap) AS score
                FROM play_history ph
                JOIN similar_users su ON su.user_id = ph.user_id
                WHERE ph.skipped = false
                GROUP BY ph.song_id
            """)
            rows = (await self.db.execute(query, {"uid": user_id})).fetchall()
            cm   = {r.song_id: float(r.score) for r in rows}
            return self._norm(np.array([cm.get(c["id"], 0.0) for c in candidates]))
        except Exception:
            return np.zeros(len(candidates))

    def _lookalike_scores(self, user_vector, feature_matrix):
        cosine = self._cosine(user_vector, feature_matrix)
        median = np.median(feature_matrix, axis=0)
        ub     = (user_vector    >= median).astype(float)
        sb     = (feature_matrix >= median).astype(float)
        inter  = np.sum(ub * sb, axis=1)
        union  = np.sum(np.clip(ub + sb, 0, 1), axis=1)
        jaccard = np.where(union > 0, inter / union, 0.0)
        return self._norm(0.5 * cosine + 0.5 * jaccard)

    def _cosine(self, uv, fm):
        n = np.linalg.norm(uv)
        if n == 0:
            return np.zeros(len(fm))
        ns = np.linalg.norm(fm, axis=1)
        ns = np.where(ns == 0, 1e-9, ns)
        return np.dot(fm, uv) / (ns * n)

    def _norm(self, s):
        mn, mx = s.min(), s.max()
        return np.zeros_like(s) if mx == mn else (s - mn) / (mx - mn)

    def _explain(self, score: float, rank: int) -> str:
        pct = int(score * 100)
        if rank == 0:
            return f"Top match — {pct}% similarity based on your listening patterns"
        if score > 0.8:
            return f"Strongly matches your taste ({pct}% similarity)"
        if score > 0.6:
            return f"Good match with your recent listening ({pct}% similarity)"
        return f"Similar to songs you enjoy ({pct}% similarity)"

    # ── Popular fallback (cold start with no prefs at all) ────────

    async def _popular_fallback(
        self, count: int, start: float
    ) -> RecommendationResponse:
        result = await self.db.execute(text("""
            SELECT s.id, s.title, s.artist_id, a.name AS artist, g.name AS genre
            FROM songs s
            JOIN artists a    ON a.id = s.artist_id
            LEFT JOIN genres g ON g.id = s.genre_id
            ORDER BY s.play_count DESC
            LIMIT :count
        """), {"count": count})

        recs = [
            RecommendedSong(
                song_id=r.id,
                title=r.title,
                artist=r.artist,
                artist_id=r.artist_id,   # FIX: was missing — breaks artist nav
                genre=r.genre,
                score=round(1.0 - i * 0.05, 2),
                explanation="Trending — popular with all listeners",
            )
            for i, r in enumerate(result.fetchall())
        ]

        return RecommendationResponse(
            mode=RecommendationMode.ANALYTICS,
            recommendations=recs,
            latency_ms=int((time.time() - start) * 1000),
            timestamp=datetime.now(timezone.utc),   # FIX: utcnow() deprecated
            count=len(recs),
            fallback_used="cold_start_popular",
        )

    def _empty_response(self, start: float) -> RecommendationResponse:
        return RecommendationResponse(
            mode=RecommendationMode.ANALYTICS,
            recommendations=[],
            latency_ms=int((time.time() - start) * 1000),
            timestamp=datetime.now(timezone.utc),   # FIX: utcnow() deprecated
            count=0,
        )
