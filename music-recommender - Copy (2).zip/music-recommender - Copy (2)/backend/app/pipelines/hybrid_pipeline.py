"""
Hybrid Fusion Pipeline
=======================
Runs Analytics and GenAI pipelines in PARALLEL via asyncio.gather().
Combines scores using a weighted fusion formula:

  S_final(i) = α × S_analytics(i) + β × S_genai(i) + γ × diversity_bonus(i)

Bug fix (was present in original):
  AnalyticsPipeline was instantiated WITHOUT redis, disabling its cache.
  Now redis is passed to both pipelines.

Dynamic fusion weights (cold start aware):
  history=0,  no prefs → α=0.0, β=1.0  (pure GenAI — truly new user)
  history<10  or vibe prefs only → α=0.2, β=0.8
  history<50  → α=0.4, β=0.6
  history>=50 → α=0.6, β=0.4  (standard — warm user)

Fallback logic:
  GenAI fails      → use Analytics results only
  Analytics fails  → use GenAI results only
  Both fail        → popular songs from DB
"""
import asyncio
import time
from datetime import datetime, timezone
from typing import Optional

import numpy as np
import structlog
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.pipelines.analytics_pipeline import AnalyticsPipeline
from app.pipelines.genai_pipeline import GenAIPipeline
from app.schemas.recommendation import (
    RecommendationMode,
    RecommendationResponse,
    RecommendedSong,
)

logger = structlog.get_logger()


class HybridPipeline:

    def __init__(self, db: AsyncSession, redis=None):
        self.db    = db
        self.redis = redis
        # BUG FIX: pass redis to AnalyticsPipeline so its user-vector
        # cache is active during Hybrid requests too.
        self.analytics = AnalyticsPipeline(db, redis)
        self.genai     = GenAIPipeline(db, redis)

        self.alpha = settings.FUSION_ALPHA   # default Analytics weight (0.6)
        self.beta  = settings.FUSION_BETA    # default GenAI weight    (0.4)
        self.gamma = settings.FUSION_GAMMA   # diversity bonus          (0.1)

    # ── Public entry point ───────────────────────────────────────

    async def recommend(
        self,
        user_id: int,
        count: int = 10,
        query_text: Optional[str] = None,
        alpha: Optional[float] = None,
        beta: Optional[float] = None,
    ) -> RecommendationResponse:
        start = time.time()

        # ── Dynamic weights based on how warm the user is ────────
        a, b = await self._fusion_weights(user_id, alpha, beta)
        logger.info("hybrid_weights", user_id=user_id, alpha=a, beta=b)

        # Run both pipelines in parallel
        results = await asyncio.gather(
            self.analytics.recommend(user_id, count * 2),
            self.genai.recommend(user_id, count, query_text=query_text),
            return_exceptions=True,
        )
        analytics_resp, genai_resp = results

        analytics_ok = (
            not isinstance(analytics_resp, Exception)
            and analytics_resp.count > 0
        )
        genai_ok = (
            not isinstance(genai_resp, Exception)
            and genai_resp.count > 0
        )

        # ── Fallback handling ────────────────────────────────────
        if not analytics_ok and not genai_ok:
            logger.warning("hybrid_both_failed", user_id=user_id)
            popular = await self._popular_fallback(count)
            return RecommendationResponse(
                mode=RecommendationMode.HYBRID,
                recommendations=popular,
                latency_ms=int((time.time() - start) * 1000),
                timestamp=datetime.now(timezone.utc),
                count=len(popular),
                query_text=query_text,
                fallback_used="both_failed_using_popular",
            )

        if not analytics_ok:
            logger.warning("hybrid_analytics_failed_using_genai", user_id=user_id)
            recs = genai_resp.recommendations[:count]
            return RecommendationResponse(
                mode=RecommendationMode.HYBRID,
                recommendations=recs,
                latency_ms=int((time.time() - start) * 1000),
                timestamp=datetime.now(timezone.utc),
                count=len(recs),
                query_text=query_text,
                fallback_used="analytics_failed",
            )

        if not genai_ok:
            logger.warning("hybrid_genai_failed_using_analytics", user_id=user_id)
            recs = analytics_resp.recommendations[:count]
            return RecommendationResponse(
                mode=RecommendationMode.HYBRID,
                recommendations=recs,
                latency_ms=int((time.time() - start) * 1000),
                timestamp=datetime.now(timezone.utc),
                count=len(recs),
                query_text=query_text,
                fallback_used="genai_failed",
            )

        # ── Both succeeded — fuse ────────────────────────────────
        recs = self._fuse(
            analytics_recs=analytics_resp.recommendations,
            genai_recs=genai_resp.recommendations,
            count=count,
            alpha=a,
            beta=b,
        )

        latency_ms = int((time.time() - start) * 1000)
        logger.info(
            "hybrid_recommend",
            user_id=user_id,
            latency_ms=latency_ms,
            analytics_ms=analytics_resp.latency_ms,
            genai_ms=genai_resp.latency_ms,
            alpha=a,
            beta=b,
        )

        return RecommendationResponse(
            mode=RecommendationMode.HYBRID,
            recommendations=recs,
            latency_ms=latency_ms,
            timestamp=datetime.now(timezone.utc),
            count=len(recs),
            query_text=query_text,
        )

    # ── Dynamic fusion weight selection ──────────────────────────

    async def _fusion_weights(
        self,
        user_id: int,
        alpha_override: Optional[float],
        beta_override: Optional[float],
    ) -> tuple[float, float]:
        """
        Returns (alpha, beta) adapted to how much history the user has.
        Manual overrides from the request take priority.
        """
        if alpha_override is not None and beta_override is not None:
            return alpha_override, beta_override

        try:
            history_count = (await self.db.execute(
                text("SELECT COUNT(*) FROM play_history WHERE user_id = :uid"),
                {"uid": user_id},
            )).scalar() or 0

            has_vibe_prefs = (await self.db.execute(
                text("SELECT 1 FROM user_preferences WHERE user_id = :uid LIMIT 1"),
                {"uid": user_id},
            )).scalar()

            if history_count == 0 and not has_vibe_prefs:
                # Total stranger — no quiz, no history. Pure GenAI.
                return 0.0, 1.0
            elif history_count < 10:
                # Vibe check done or very few real plays. Lean GenAI.
                return 0.2, 0.8
            elif history_count < 50:
                # Growing library. Balanced, trending toward Analytics.
                return 0.4, 0.6
            else:
                # Warm user. Standard configured weights.
                return self.alpha, self.beta

        except Exception as e:
            logger.warning("hybrid_weight_calc_failed", error=str(e))
            return self.alpha, self.beta

    # ── Score fusion ─────────────────────────────────────────────

    def _fuse(
        self,
        analytics_recs: list[RecommendedSong],
        genai_recs: list[RecommendedSong],
        count: int,
        alpha: float,
        beta: float,
    ) -> list[RecommendedSong]:
        """
        S_final = α × S_analytics + β × S_genai + γ × diversity_bonus
        """
        a_map = {r.song_id: r for r in analytics_recs}
        g_map = {r.song_id: r for r in genai_recs}
        all_ids = set(a_map.keys()) | set(g_map.keys())

        genre_counts: dict[str, int] = {}
        fused: list[tuple[float, float, RecommendedSong]] = []

        for sid in all_ids:
            a_rec = a_map.get(sid)
            g_rec = g_map.get(sid)

            a_score  = a_rec.score if a_rec else 0.0
            g_score  = g_rec.score if g_rec else 0.0
            base_rec = a_rec or g_rec
            genre    = base_rec.genre or "Unknown"

            # FIX: carry artist_id from whichever pipeline provided it.
            # Analytics always has it (from _load_candidate_features);
            # GenAI has it after FIX B4. Without this, every Hybrid song
            # card had artist_id=None → clicking the artist name did nothing.
            artist_id = (a_rec.artist_id if a_rec else None) or (g_rec.artist_id if g_rec else None)

            genre_counts[genre] = genre_counts.get(genre, 0) + 1

            fused.append((
                a_score,
                g_score,
                RecommendedSong(
                    song_id=sid,
                    title=base_rec.title,
                    artist=base_rec.artist,
                    album=base_rec.album,
                    genre=genre,
                    score=0.0,          # computed below
                    explanation=self._merge_explanations(a_rec, g_rec),
                    analytics_score=round(a_score, 4),
                    genai_score=round(g_score, 4),
                    preview_url=g_rec.preview_url if g_rec else None,
                    cover_url=g_rec.cover_url   if g_rec else None,
                    artist_id=artist_id,           # FIX: was always None
                ),
            ))

        # Compute final scores and apply diversity cap
        MAX_GENRE_FRACTION = 0.60
        genre_caps = {
            g: max(1, int(count * MAX_GENRE_FRACTION))
            for g in genre_counts
        }
        genre_used: dict[str, int] = {}

        scored = []
        for a_score, g_score, rec in fused:
            genre           = rec.genre or "Unknown"
            diversity_bonus = 1.0 if genre_counts.get(genre, 0) <= 2 else 0.0
            final           = alpha * a_score + beta * g_score + self.gamma * diversity_bonus
            scored.append((final, rec))

        scored.sort(key=lambda x: x[0], reverse=True)

        results: list[RecommendedSong] = []
        for final_score, rec in scored:
            if len(results) >= count:
                break
            genre = rec.genre or "Unknown"
            used  = genre_used.get(genre, 0)
            if used >= genre_caps.get(genre, count):
                continue
            genre_used[genre] = used + 1
            rec.score = round(final_score, 4)
            results.append(rec)

        # Fill remaining slots ignoring the diversity cap
        if len(results) < count:
            already = {r.song_id for r in results}
            for final_score, rec in scored:
                if len(results) >= count:
                    break
                if rec.song_id not in already:
                    rec.score = round(final_score, 4)
                    results.append(rec)

        return results

    def _merge_explanations(
        self,
        a_rec: Optional[RecommendedSong],
        g_rec: Optional[RecommendedSong],
    ) -> str:
        if a_rec and g_rec:
            return f"Analytics: {a_rec.explanation} | AI: {g_rec.explanation}"
        if a_rec:
            return a_rec.explanation
        if g_rec:
            return g_rec.explanation
        return "Recommended by hybrid system"

    # ── Popular fallback ─────────────────────────────────────────

    async def _popular_fallback(self, count: int) -> list[RecommendedSong]:
        result = await self.db.execute(
            text("""
                SELECT s.id, s.title, s.artist_id, a.name AS artist, g.name AS genre
                FROM songs s
                JOIN artists a    ON a.id = s.artist_id
                LEFT JOIN genres g ON g.id = s.genre_id
                ORDER BY s.play_count DESC
                LIMIT :count
            """),
            {"count": count},
        )
        return [
            RecommendedSong(
                song_id=r.id,
                title=r.title,
                artist=r.artist,
                artist_id=r.artist_id,   # FIX: was missing — breaks artist nav
                genre=r.genre,
                score=round(1.0 - i * 0.05, 2),
                explanation="Trending — popular with listeners",
            )
            for i, r in enumerate(result.fetchall())
        ]
