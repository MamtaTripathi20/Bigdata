import asyncio
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy import text

async def check():
    e = create_async_engine(
        "postgresql+asyncpg://music_user:music_pass@postgres:5432/music_db"
    )
    async with e.connect() as conn:
        songs  = (await conn.execute(text("SELECT COUNT(*) FROM songs"))).scalar()
        feats  = (await conn.execute(text("SELECT COUNT(*) FROM song_features"))).scalar()
        probs  = (await conn.execute(text("SELECT COUNT(*) FROM song_features WHERE cluster_prob_0 IS NOT NULL"))).scalar()
        genres = (await conn.execute(text("SELECT COUNT(*) FROM genres"))).scalar()
        print(f"Songs:              {songs}")
        print(f"Song features:      {feats}")
        print(f"With cluster probs: {probs}")
        print(f"Genres:             {genres}")

asyncio.run(check())