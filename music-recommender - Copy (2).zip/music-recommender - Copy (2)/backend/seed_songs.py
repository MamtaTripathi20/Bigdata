"""
Clean seed - no passlib, seeds songs/artists/genres/features + play history for existing demo user.
"""
import asyncio
import random
import sys
sys.path.insert(0, '/app')

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy import text
from app.models.db_models import Artist, Genre, Album, Song, SongFeature, PlayHistory
from app.database import Base
from datetime import datetime, timedelta

DATABASE_URL = "postgresql+asyncpg://music_user:music_pass@postgres:5432/music_db"

GENRES = ["Pop", "Rock", "Jazz", "Electronic", "Hip-Hop",
          "Classical", "R&B", "Country", "Metal", "Indie"]

ARTISTS_BY_GENRE = {
    "Pop":        ["Taylor Swift", "Ed Sheeran", "Dua Lipa", "Billie Eilish"],
    "Rock":       ["Arctic Monkeys", "Radiohead", "The Strokes", "Queens of the Stone Age"],
    "Jazz":       ["Miles Davis", "Coltrane Project", "Bill Evans Trio", "Herbie Hancock"],
    "Electronic": ["Daft Punk", "Aphex Twin", "Boards of Canada", "Four Tet"],
    "Hip-Hop":    ["Kendrick Lamar", "J. Cole", "Tyler The Creator", "Frank Ocean"],
    "Classical":  ["Bach Ensemble", "Vienna Strings", "London Symphony", "Berlin Philharmonic"],
    "R&B":        ["Sza", "H.E.R.", "Daniel Caesar", "Jorja Smith"],
    "Country":    ["Kacey Musgraves", "Chris Stapleton", "Sturgill Simpson", "Phoebe Bridgers"],
    "Metal":      ["Tool", "Mastodon", "Ghost", "Opeth"],
    "Indie":      ["Tame Impala", "Vampire Weekend", "Bon Iver", "Fleet Foxes"],
}

ADJECTIVES = ["Golden", "Broken", "Silent", "Electric", "Midnight", "Neon",
               "Crystal", "Heavy", "Soft", "Distant", "Ancient", "Wild"]
NOUNS      = ["Rain", "Sun", "Fire", "Storm", "River", "Sky", "Heart",
               "Shadow", "Ghost", "Road", "Dream", "Wave", "Desert", "City"]
VERBS      = ["Fall", "Run", "Fly", "Burn", "Rise", "Sink", "Drift", "Fade"]
TEMPLATES  = ["{adj} {noun}", "The {noun}", "{noun} of {noun2}", "My {adj} {noun}",
              "{verb}ing {noun}", "Lost in {noun}", "{noun} Dreams", "After {noun}"]

def random_title():
    t = random.choice(TEMPLATES)
    return (t.replace("{adj}", random.choice(ADJECTIVES))
             .replace("{noun2}", random.choice(NOUNS))
             .replace("{noun}", random.choice(NOUNS))
             .replace("{verb}", random.choice(VERBS)))

def random_features(genre):
    templates = {
        "Pop":        dict(tempo=(100,130), energy=(0.6,0.9), danceability=(0.6,0.9), valence=(0.5,0.9)),
        "Rock":       dict(tempo=(110,160), energy=(0.7,1.0), danceability=(0.4,0.7), valence=(0.3,0.7)),
        "Jazz":       dict(tempo=(70,120),  energy=(0.3,0.6), danceability=(0.3,0.6), valence=(0.4,0.7)),
        "Electronic": dict(tempo=(120,145), energy=(0.7,1.0), danceability=(0.7,1.0), valence=(0.4,0.8)),
        "Hip-Hop":    dict(tempo=(85,100),  energy=(0.6,0.9), danceability=(0.7,0.95),valence=(0.3,0.7)),
        "Classical":  dict(tempo=(60,120),  energy=(0.1,0.5), danceability=(0.1,0.4), valence=(0.3,0.8)),
        "R&B":        dict(tempo=(75,105),  energy=(0.4,0.7), danceability=(0.6,0.9), valence=(0.4,0.8)),
        "Country":    dict(tempo=(90,130),  energy=(0.4,0.8), danceability=(0.4,0.7), valence=(0.5,0.9)),
        "Metal":      dict(tempo=(140,200), energy=(0.8,1.0), danceability=(0.2,0.5), valence=(0.1,0.4)),
        "Indie":      dict(tempo=(90,130),  energy=(0.4,0.8), danceability=(0.4,0.7), valence=(0.4,0.8)),
    }
    t = templates.get(genre, templates["Pop"])
    def r(lo, hi): return round(random.uniform(lo, hi), 4)
    return dict(
        tempo=r(*t["tempo"]), energy=r(*t["energy"]),
        danceability=r(*t["danceability"]), valence=r(*t["valence"]),
        key=random.randint(0, 11), loudness=round(random.uniform(-20, -3), 2),
        mfcc_1=round(random.gauss(-200,50),2), mfcc_2=round(random.gauss(100,30),2),
        mfcc_3=round(random.gauss(-20,15),2),  mfcc_4=round(random.gauss(15,10),2),
        mfcc_5=round(random.gauss(-5,8),2),
    )

async def seed():
    engine = create_async_engine(DATABASE_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with Session() as db:

        # ── Genres ───────────────────────────────────────────
        print("Seeding genres...")
        genre_objs = {}
        for g in GENRES:
            genre = Genre(name=g)
            db.add(genre)
            genre_objs[g] = genre
        await db.flush()

        # ── Artists, Albums, Songs, Features ─────────────────
        print("Seeding artists & songs...")
        all_songs = []
        for genre_name, artists in ARTISTS_BY_GENRE.items():
            genre = genre_objs[genre_name]
            for artist_name in artists:
                artist = Artist(name=artist_name)
                db.add(artist)
                await db.flush()

                album = Album(
                    title=f"{random_title()} (Album)",
                    artist_id=artist.id,
                    release_year=random.randint(2010, 2024),
                )
                db.add(album)
                await db.flush()

                for _ in range(random.randint(2, 3)):
                    song = Song(
                        title=random_title(),
                        artist_id=artist.id,
                        album_id=album.id,
                        genre_id=genre.id,
                        duration_s=random.randint(120, 380),
                        play_count=random.randint(0, 50000),
                    )
                    db.add(song)
                    await db.flush()
                    db.add(SongFeature(song_id=song.id, **random_features(genre_name)))
                    all_songs.append(song.id)

        await db.flush()
        print(f"  → {len(all_songs)} songs seeded")

        # ── Play history for demo user (id=1) ─────────────────
        print("Seeding play history for demo user...")
        sample = random.sample(all_songs, min(20, len(all_songs)))
        for i, song_id in enumerate(sample):
            db.add(PlayHistory(
                user_id=1,
                song_id=song_id,
                skipped=random.random() < 0.15,
                liked=random.random() < 0.3,
                replayed=random.random() < 0.1,
                played_at=datetime.utcnow() - timedelta(hours=i * 2),
            ))

        await db.commit()
        print("✓ Done! Songs, features, and play history all seeded.")

asyncio.run(seed())
