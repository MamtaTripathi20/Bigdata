"""add playlist position constraint and supporting indexes

Revision ID: 20260418_01
Revises:
Create Date: 2026-04-18
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20260418_01"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        CREATE INDEX IF NOT EXISTS ix_play_history_song_id
        ON play_history (song_id)
        """
    )
    op.execute(
        """
        CREATE INDEX IF NOT EXISTS ix_play_history_user_song
        ON play_history (user_id, song_id)
        """
    )
    op.execute(
        """
        CREATE INDEX IF NOT EXISTS ix_playlists_user_id
        ON playlists (user_id)
        """
    )
    op.execute(
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM pg_constraint WHERE conname = 'uq_playlist_position'
            ) THEN
                ALTER TABLE playlist_songs
                ADD CONSTRAINT uq_playlist_position UNIQUE (playlist_id, position);
            END IF;
        END
        $$;
        """
    )
    op.execute(
        """
        CREATE INDEX IF NOT EXISTS ix_playlist_songs_playlist_position
        ON playlist_songs (playlist_id, position)
        """
    )


def downgrade() -> None:
    op.execute(
        """
        DROP INDEX IF EXISTS ix_playlist_songs_playlist_position
        """
    )
    op.execute(
        """
        ALTER TABLE playlist_songs
        DROP CONSTRAINT IF EXISTS uq_playlist_position
        """
    )
    op.execute(
        """
        DROP INDEX IF EXISTS ix_playlists_user_id
        """
    )
    op.execute(
        """
        DROP INDEX IF EXISTS ix_play_history_user_song
        """
    )
    op.execute(
        """
        DROP INDEX IF EXISTS ix_play_history_song_id
        """
    )
