"""
FCM Training Script
===================
Run this ONCE offline to generate /app/models/fcm_model.pkl.
The AnalyticsPipeline loads this file at startup. If it does not
exist, it falls back to live on-the-fly FCM per request (slower).

Usage:
  cd backend
  python train_fcm.py

Requirements:
  pip install scikit-fuzzy scikit-learn numpy asyncpg sqlalchemy asyncio

FIXES applied in this version:
  FIX 1 — Old query required energy IS NOT NULL AND danceability IS NOT NULL
           AND valence IS NOT NULL, which excluded ALL MSD songs (they were
           seeded with those fields as None). Now uses COALESCE so every
           song with at least a valid tempo participates in training.
  FIX 2 — MAX_SONGS raised from 100 000 to 1 000 000 to use the full MSD
           dataset. Lower it back for quick iteration / dev testing.
  FIX 3 — K kept at 8 to match the cluster_membership.csv that ships with
           the project. Change only if you regenerate cluster_membership.csv.

Output:
  /app/models/fcm_model.pkl  — dict with keys:
    cluster_centers  : ndarray (K, 9)
    scaler           : StandardScaler fitted on the training data
    m                : fuzzifier (2.0)
    K                : number of clusters (8)
    fpc              : fuzzy partition coefficient (quality metric, 0-1)
    n_songs          : number of songs trained on
"""
import asyncio
import os
import pickle
from pathlib import Path

import numpy as np
from sklearn.preprocessing import StandardScaler

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://music_user:music_pass@localhost:5432/music_db",
)

OUTPUT_PATH = Path("/app/models/fcm_model.pkl")
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

FEATURE_KEYS = [
    "tempo", "energy", "danceability", "valence",
    "mfcc_1", "mfcc_2", "mfcc_3", "mfcc_4", "mfcc_5",
]

K   = 8        # must match cluster_membership.csv (8 columns confirmed)
M   = 2.0      # fuzzifier — 2.0 is standard
# FIX 2: raised from 100_000 to 1_000_000 for full MSD
# Set to e.g. 50_000 for fast dev/test iterations
MAX_SONGS = 1_000_000


async def fetch_features() -> np.ndarray:
    from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
    from sqlalchemy.ext.asyncio import async_sessionmaker
    from sqlalchemy import text

    engine     = create_async_engine(DATABASE_URL, echo=False)
    SessionLocal = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    print(f"Connecting to DB and fetching up to {MAX_SONGS:,} songs...")
    async with SessionLocal() as db:
        # COALESCE replaces NULL with sensible defaults.
        # The extra `col = col` filters out PostgreSQL IEEE-754 NaN values
        # (NaN != NaN is true in SQL just as in IEEE 754). These can appear
        # if a previous seed run stored Python float('nan') directly, which
        # PostgreSQL stores as NaN — not NULL — bypassing COALESCE.
        rows = (await db.execute(text(f"""
            SELECT
                COALESCE(tempo,        120.0) AS tempo,
                COALESCE(energy,         0.5) AS energy,
                COALESCE(danceability,   0.5) AS danceability,
                COALESCE(valence,        0.5) AS valence,
                COALESCE(mfcc_1,         0.0) AS mfcc_1,
                COALESCE(mfcc_2,         0.0) AS mfcc_2,
                COALESCE(mfcc_3,         0.0) AS mfcc_3,
                COALESCE(mfcc_4,         0.0) AS mfcc_4,
                COALESCE(mfcc_5,         0.0) AS mfcc_5
            FROM song_features
            WHERE tempo IS NOT NULL
              AND tempo        = tempo
              AND energy       = energy
              AND danceability = danceability
              AND valence      = valence
            ORDER BY RANDOM()
            LIMIT {MAX_SONGS}
        """))).fetchall()

    await engine.dispose()

    if not rows:
        raise RuntimeError(
            "No songs with audio features found in the database. "
            "Run seed_msd_songs.py first."
        )

    X = np.array(
        [
            [
                row.tempo, row.energy, row.danceability, row.valence,
                row.mfcc_1, row.mfcc_2, row.mfcc_3, row.mfcc_4, row.mfcc_5,
            ]
            for row in rows
        ],
        dtype=float,
    )

    print(f"Loaded {len(X):,} songs.")

    # Safety net: drop any rows with NaN or inf that slipped through.
    # These cause StandardScaler to produce NaN columns, which makes
    # FCM converge to a degenerate uniform solution (FPC = 1/K).
    mask = np.isfinite(X).all(axis=1)
    n_bad = int((~mask).sum())
    if n_bad:
        print(f"  Dropping {n_bad:,} rows with NaN/inf features.")
        X = X[mask]
    print(f"  Clean rows for training: {len(X):,}")

    return X


def train(X: np.ndarray) -> dict:
    try:
        import skfuzzy as fuzz
    except ImportError:
        raise ImportError("Install skfuzzy: pip install scikit-fuzzy")

    print("Scaling features...")
    scaler   = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    print(f"Running Fuzzy C-Means (K={K}, m={M}) on {len(X):,} songs...")
    print("This may take a few minutes on 10K songs, longer on 100K+.")

    cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(
        X_scaled.T,     # skfuzzy expects (features, samples)
        K,
        M,
        error=0.005,
        maxiter=300,
        init=None,
        seed=42,
    )

    print("Training complete.")
    print(f"  Fuzzy Partition Coefficient (FPC): {fpc:.4f}  (higher = better, max=1.0)")
    print(f"  Iterations to converge: {p}")
    print(f"  Cluster centres shape: {cntr.shape}")

    print("\nCluster summary (dominant audio features):")
    centres_original = scaler.inverse_transform(cntr)
    for i, centre in enumerate(centres_original):
        print(
            f"  Cluster {i+1:2d}: "
            f"tempo={centre[0]:.0f}  "
            f"energy={centre[1]:.2f}  "
            f"dance={centre[2]:.2f}  "
            f"valence={centre[3]:.2f}"
        )

    return {
        "cluster_centers": cntr,    # scaled space — used in cmeans_predict
        "scaler":          scaler,
        "m":               M,
        "K":               K,
        "fpc":             fpc,
        "n_songs":         len(X),
    }


def save(model: dict):
    with open(OUTPUT_PATH, "wb") as f:
        pickle.dump(model, f)
    size_kb = OUTPUT_PATH.stat().st_size // 1024
    print(f"\nModel saved to {OUTPUT_PATH}  ({size_kb} KB)")
    print("Restart the FastAPI server to load the new model.")


async def main():
    X     = await fetch_features()
    model = train(X)
    save(model)


if __name__ == "__main__":
    asyncio.run(main())
