"""
Seed Script — Populates DB with 100 realistic sample songs for immediate testing.

Run with:
  cd backend
  python -m scripts.seed_data

For Week 1 testing (no Million Song Dataset needed).
Replace with MSD import script later.
"""
import asyncio
import random
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from app.models.db_models import User, Artist, Genre, Album, Song, SongFeature, UserPreference, PlayHistory
from app.core.security import hash_password

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://music_user:music_pass@localhost:5432/music_db"
)

# ── Sample data ──────────────────────────────────────────────────

GENRES = ["Pop", "Rock", "Jazz", "Electronic", "Hip-Hop",
          "Classical", "R&B", "Country", "Metal", "Indie"]

ARTISTS_BY_GENRE = {
    "Pop":       ["Taylor Swift", "Ed Sheeran", "Dua Lipa", "Billie Eilish"],
    "Rock":      ["Arctic Monkeys", "Radiohead", "The Strokes", "Queens of the Stone Age"],
    "Jazz":      ["Miles Davis", "Coltrane Project", "Bill Evans Trio", "Herbie Hancock"],
    "Electronic":["Daft Punk", "Aphex Twin", "Boards of Canada", "Four Tet"],
    "Hip-Hop":   ["Kendrick Lamar", "J. Cole", "Tyler The Creator", "Frank Ocean"],
    "Classical": ["Bach Ensemble", "Vienna Strings", "London Symphony", "Berlin Philharmonic"],
    "R&B":       ["Sza", "H.E.R.", "Daniel Caesar", "Jorja Smith"],
    "Country":   ["Kacey Musgraves", "Chris Stapleton", "Sturgill Simpson", "Phoebe Bridgers"],
    "Metal":     ["Tool", "Mastodon", "Ghost", "Opeth"],
    "Indie":     ["Tame Impala", "Vampire Weekend", "Bon Iver", "Fleet Foxes"],
}

SONG_TEMPLATES = [
    "{adj} {noun}", "The {noun}", "{noun} of {noun2}", "My {adj} {noun}",
    "{verb}ing {noun}", "Lost in {noun}", "{noun} Dreams", "After {noun}",
    "Before the {noun}", "{adj} Light", "Under the {noun}",
]

ADJECTIVES  = ["Golden", "Broken", "Silent", "Electric", "Midnight", "Neon",
               "Crystal", "Heavy", "Soft", "Distant", "Ancient", "Wild"]
NOUNS       = ["Rain", "Sun", "Fire", "Storm", "River", "Sky", "Heart",
               "Shadow", "Ghost", "Road", "Dream", "Wave", "Desert", "City"]
VERBS       = ["Fall", "Run", "Fly", "Burn", "Rise", "Sink", "Drift", "Fade"]


def random_title() -> str:
    tmpl = random.choice(SONG_TEMPLATES)
    return (tmpl
        .replace("{adj}",   random.choice(ADJECTIVES))
        .replace("{noun2}", random.choice(NOUNS))
        .replace("{noun}",  random.choice(NOUNS))
        .replace("{verb}",  random.choice(VERBS))
    )


def random_features(genre: str) -> dict:
    """
    Generate plausible 9D audio feature vector per genre.
    These are approximations — real values come from MSD import.
    """
    templates = {
        "Pop":        dict(tempo=(100, 130), energy=(0.6, 0.9), danceability=(0.6, 0.9), valence=(0.5, 0.9)),
        "Rock":       dict(tempo=(110, 160), energy=(0.7, 1.0), danceability=(0.4, 0.7), valence=(0.3, 0.7)),
        "Jazz":       dict(tempo=(70, 120),  energy=(0.3, 0.6), danceability=(0.3, 0.6), valence=(0.4, 0.7)),
        "Electronic": dict(tempo=(120, 145), energy=(0.7, 1.0), danceability=(0.7, 1.0), valence=(0.4, 0.8)),
        "Hip-Hop":    dict(tempo=(85, 100),  energy=(0.6, 0.9), danceability=(0.7, 0.95),valence=(0.3, 0.7)),
        "Classical":  dict(tempo=(60, 120),  energy=(0.1, 0.5), danceability=(0.1, 0.4), valence=(0.3, 0.8)),
        "R&B":        dict(tempo=(75, 105),  energy=(0.4, 0.7), danceability=(0.6, 0.9), valence=(0.4, 0.8)),
        "Country":    dict(tempo=(90, 130),  energy=(0.4, 0.8), danceability=(0.4, 0.7), valence=(0.5, 0.9)),
        "Metal":      dict(tempo=(140, 200), energy=(0.8, 1.0), danceability=(0.2, 0.5), valence=(0.1, 0.4)),
        "Indie":      dict(tempo=(90, 130),  energy=(0.4, 0.8), danceability=(0.4, 0.7), valence=(0.4, 0.8)),
    }
    t = templates.get(genre, templates["Pop"])

    def r(lo, hi): return round(random.uniform(lo, hi), 4)

    return {
        "tempo":        r(*t["tempo"]),
        "energy":       r(*t["energy"]),
        "danceability": r(*t["danceability"]),
        "valence":      r(*t["valence"]),
        "key":          random.randint(0, 11),
        "loudness":     round(random.uniform(-20, -3), 2),
        "mfcc_1":       round(random.gauss(-200, 50), 2),
        "mfcc_2":       round(random.gauss(100, 30),  2),
        "mfcc_3":       round(random.gauss(-20, 15),  2),
        "mfcc_4":       round(random.gauss(15, 10),   2),
        "mfcc_5":       round(random.gauss(-5, 8),    2),
    }


# ── Main seed logic ──────────────────────────────────────────────

async def seed():
    engine = create_async_engine(DATABASE_URL, echo=False)
    from app.database import Base
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    async with Session() as db:
        print("Seeding genres...")
        genre_objs = {}
        for g in GENRES:
            genre = Genre(name=g)
            db.add(genre)
            genre_objs[g] = genre
        await db.flush()

        print("Seeding artists & songs...")
        song_count = 0
        for genre_name, artists in ARTISTS_BY_GENRE.items():
            genre = genre_objs[genre_name]
            for artist_name in artists:
                artist = Artist(name=artist_name)
                db.add(artist)
                await db.flush()

                album = Album(
                    title=f"{random_title()} (Album)",
                    artist_id=artist.id,
                    release_year=random.randint(2010, 2024),
                )
                db.add(album)
                await db.flush()

                # 2–3 songs per artist
                for _ in range(random.randint(2, 3)):
                    song = Song(
                        title=random_title(),
                        artist_id=artist.id,
                        album_id=album.id,
                        genre_id=genre.id,
                        duration_s=random.randint(120, 380),
                        play_count=random.randint(0, 50_000),
                    )
                    db.add(song)
                    await db.flush()

                    features = SongFeature(song_id=song.id, **random_features(genre_name))
                    db.add(features)
                    song_count += 1

        await db.flush()
        print(f"  → {song_count} songs seeded")

        # ── Demo user ────────────────────────────────────────────
        print("Seeding demo user...")
        demo = User(
            username="demo",
            email="demo@music.local",
            hashed_password=hash_password("demo1234"),
        )
        db.add(demo)
        await db.flush()

        # Give demo user some play history
        from sqlalchemy import select
        songs_result = await db.execute(select(Song).limit(30))
        songs = songs_result.scalars().all()

        from datetime import datetime, timedelta
        for i, song in enumerate(random.sample(songs, min(20, len(songs)))):
            ph = PlayHistory(
                user_id=demo.id,
                song_id=song.id,
                skipped=random.random() < 0.15,
                liked=random.random() < 0.3,
                replayed=random.random() < 0.1,
                played_at=datetime.utcnow() - timedelta(hours=i * 2),
            )
            db.add(ph)

        await db.commit()
        print("✓ Seed complete!")
        print(f"  Demo credentials: username=demo, password=demo1234")
        print(f"  Songs: {song_count}")
        print(f"  Play history: 20 events for demo user")


if __name__ == "__main__":
    asyncio.run(seed())
