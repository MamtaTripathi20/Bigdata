#!/bin/bash
# setup_ollama.sh — Pull the LLM model into Ollama container
# Run ONCE after `docker compose up ollama`

set -e

MODEL="${OLLAMA_MODEL:-llama3.2:3b}"
OLLAMA_URL="${OLLAMA_URL:-http://localhost:11434}"

echo "================================================"
echo "  Music Recommender — Ollama Setup"
echo "================================================"
echo ""
echo "Waiting for Ollama to start..."
until curl -sf "$OLLAMA_URL/api/tags" > /dev/null; do
  printf "."
  sleep 2
done
echo ""
echo "Ollama is ready!"
echo ""
echo "Pulling model: $MODEL"
echo "(This is a one-time download — may take 5-15 min on first run)"
echo ""

docker exec music_ollama ollama pull "$MODEL"

echo ""
echo "================================================"
echo "  Model '$MODEL' is ready!"
echo ""
echo "  For better quality (needs ~8GB RAM):"
echo "    OLLAMA_MODEL=mistral:7b-q4 bash setup_ollama.sh"
echo ""
echo "  For fastest responses (weaker quality):"
echo "    OLLAMA_MODEL=gemma2:2b bash setup_ollama.sh"
echo "================================================"
