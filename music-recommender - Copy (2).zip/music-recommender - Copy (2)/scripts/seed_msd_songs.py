"""
seed_msd_songs.py
=================
Seeds the database with real MSD songs from songs_features.csv,
cluster assignments from song_clusters.csv, and soft memberships
from cluster_membership.csv.

FIXES applied in this version:
  FIX 1  — energy and danceability read from CSV where non-zero.
  FIX 2  — valence derived NaN-safely from mode+tempo+energy+hotttnesss.
  FIX 3  — K read dynamically from fcm_model.pkl (defaults to 8).
  FIX 4  — Numeric-only genre values (e.g. "68.105") stripped.
  FIX 5  — Batch commit every 5 000 rows (prevents memory blow-up).
  FIX 6  — VARCHAR(255) overflow: clean_str() splits on ";" and truncates.
  FIX 7  — NaN propagation fixed via safe_float() using pd.notna().
  FIX 8  — Genre-based imputation replaced by ACOUSTIC imputation.
           MSD energy and danceability are 0.0 for 99%+ of songs (the
           EchoNest fields were simply never computed for most tracks).
           Genre centroids gave every Rock song the same value → zero
           within-genre variance → FCM collapses to one cluster again.
           Fix: derive features from per-song MSD fields that ARE always
           populated with real, varied values:
             energy       ← loudness   (louder track = higher energy)
             danceability ← tempo+mode (faster+major = more danceable)
           These produce genuine per-song variation so FCM can find
           meaningful structure in the data.

Run inside the backend container:
  docker compose exec backend python scripts/seed_msd_songs.py
"""
import asyncio
import os
import pickle
import sys

sys.path.insert(0, "/app")

import pandas as pd
import numpy as np
from sqlalchemy.ext.asyncio import (
    create_async_engine,
    AsyncSession,
    async_sessionmaker,
)
from app.models.db_models import Artist, Genre, Album, Song, SongFeature
from app.database import Base

DATABASE_URL = "postgresql+asyncpg://music_user:music_pass@postgres:5432/music_db"
MODELS_DIR   = "/app/models"
BATCH_FLUSH  = 200
BATCH_COMMIT = 5_000


# ── NaN-safe numeric helper ───────────────────────────────────────

def safe_float(value, default):
    """
    Convert value to float, returning default if None / NaN / inf.
    Fixes: float(nan) or default == nan  (NaN is truthy, "or" never fires).
    """
    if value is None:
        return default
    try:
        f = float(value)
        return default if (not pd.notna(f) or not np.isfinite(f)) else f
    except (ValueError, TypeError):
        return default


# ── Acoustic imputation (FIX 8) ──────────────────────────────────
# MSD energy and danceability are 0.0 for ~99% of songs — the EchoNest
# pipeline simply never computed them for most tracks.  Instead of using
# a genre centroid (same value for every Rock/Pop/Jazz song → no variance),
# we derive per-song estimates from fields that ARE always populated.

def impute_energy(loudness: float) -> float:
    """
    Derive energy from loudness.
    MSD loudness ranges roughly -60 dB (silent) to 0 dB (loud).
    Map linearly to [0, 1]: silence → 0, maximum loudness → 1.
    We clamp to [0.05, 0.95] to avoid degenerate extremes.
    """
    e = (loudness + 60.0) / 60.0
    return float(np.clip(e, 0.05, 0.95))


def impute_danceability(tempo: float, mode: float) -> float:
    """
    Derive danceability from tempo and mode.
    - Tempo contribution: danceable tempos peak around 120 BPM.
      Use a tent function that's 1.0 at 120 BPM and falls off either side.
    - Mode contribution: major key (mode=1) is more dance-friendly.
    Weights: 70% tempo shape, 30% mode.
    """
    # Tent: max at 120 BPM, zero at 0 or 240 BPM
    tempo_score = max(0.0, 1.0 - abs(tempo - 120.0) / 120.0)
    d = 0.70 * tempo_score + 0.30 * mode
    return float(np.clip(d, 0.05, 0.95))


def impute_valence(mode: float, tempo: float,
                   energy: float, hotness: float) -> float:
    """
    Derive valence (musical positiveness) from available MSD fields.
    All inputs are already NaN-safe floats by the time this is called.
    """
    v = (
        0.35 * mode
        + 0.25 * min(tempo / 200.0, 1.0)
        + 0.20 * energy
        + 0.20 * hotness
    )
    result = float(np.clip(v, 0.0, 1.0))
    return round(result if np.isfinite(result) else 0.5, 4)


# ── K detection ───────────────────────────────────────────────────

def detect_K() -> int:
    pkl_path = f"{MODELS_DIR}/fcm_model.pkl"
    if os.path.exists(pkl_path):
        try:
            with open(pkl_path, "rb") as f:
                model = pickle.load(f)
            K = int(model.get("K", 8))
            print(f"  Detected K={K} from fcm_model.pkl")
            return K
        except Exception as e:
            print(f"  WARNING: could not read fcm_model.pkl ({e}), defaulting to K=8")
    else:
        print("  WARNING: fcm_model.pkl not found, defaulting to K=8")
    return 8


# ── String sanitisation ───────────────────────────────────────────

def clean_str(value, max_len: int = 250) -> str:
    if value is None or (isinstance(value, float) and not np.isfinite(value)):
        return ""
    return str(value).split(";")[0].strip()[:max_len]


# ── Main seeding logic ────────────────────────────────────────────

async def seed():
    K = detect_K()

    print("Loading CSVs...")
    songs_df    = pd.read_csv(f"{MODELS_DIR}/songs_features.csv",    low_memory=False)
    clusters_df = pd.read_csv(f"{MODELS_DIR}/song_clusters.csv")
    member_df   = pd.read_csv(f"{MODELS_DIR}/cluster_membership.csv", index_col=0)

    # Strip numeric-only genre values (e.g. "68.105")
    songs_df = songs_df[
        ~songs_df["genre"].astype(str).str.match(r"^\d+\.?\d*$", na=False)
    ]

    print(f"  songs_features rows : {len(songs_df):,}")
    print(f"  song_clusters rows  : {len(clusters_df):,}")
    print(f"  cluster_membership  : {len(member_df):,} x {len(member_df.columns)} cols")

    # Quick stats on how sparse energy/danceability actually are
    n_energy = int((songs_df["energy"].replace(0, np.nan).notna()).sum()) \
        if "energy" in songs_df.columns else 0
    n_dance  = int((songs_df["danceability"].replace(0, np.nan).notna()).sum()) \
        if "danceability" in songs_df.columns else 0
    print(f"  energy non-zero     : {n_energy:,} / {len(songs_df):,} "
          f"({100*n_energy/len(songs_df):.1f}%)")
    print(f"  danceability non-zero: {n_dance:,} / {len(songs_df):,} "
          f"({100*n_dance/len(songs_df):.1f}%)")

    expected_cols = [f"cluster_{i}_prob" for i in range(K)]
    missing = [c for c in expected_cols if c not in member_df.columns]
    if missing:
        raise ValueError(
            f"cluster_membership.csv missing columns: {missing}\n"
            f"  Detected K={K} — check fcm_model.pkl matches the CSV."
        )

    clusters_full = pd.concat(
        [clusters_df.reset_index(drop=True), member_df.reset_index(drop=True)],
        axis=1,
    )
    merge_cols = ["track_id", "cluster", "cluster_confidence"] + expected_cols
    df = songs_df.merge(clusters_full[merge_cols], on="track_id", how="left")
    print(f"  Songs after merge   : {len(df):,}")

    engine = create_async_engine(DATABASE_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    print("  DB schema recreated.")

    Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with Session() as db:

        # ── Genres ────────────────────────────────────────────────────
        print("Seeding genres...")
        genre_map: dict = {}
        for name in songs_df["genre"].dropna().unique():
            g = Genre(name=str(name))
            db.add(g)
            await db.flush()
            genre_map[str(name)] = g.id
        await db.flush()

        # ── Artists ───────────────────────────────────────────────────
        print("Seeding artists...")
        artist_map: dict = {}
        for name in df["artist_name"].dropna().unique():
            cleaned = clean_str(name)
            if not cleaned or cleaned in artist_map:
                continue
            a = Artist(name=cleaned)
            db.add(a)
            await db.flush()
            artist_map[cleaned] = a.id
        await db.flush()

        # ── Albums ────────────────────────────────────────────────────
        print("Seeding albums...")
        album_map: dict = {}
        for _, row in df[["album_title", "artist_name", "year"]].drop_duplicates().iterrows():
            raw_album  = clean_str(row["album_title"])
            raw_artist = clean_str(row["artist_name"])
            key = (raw_album, raw_artist)
            if not raw_album or key in album_map:
                continue
            artist_id = artist_map.get(raw_artist)
            if not artist_id:
                continue
            try:
                yr_raw = row.get("year")
                yr = int(float(yr_raw)) if pd.notna(yr_raw) and float(yr_raw) > 0 else None
            except (ValueError, TypeError):
                yr = None
            al = Album(title=raw_album, artist_id=artist_id, release_year=yr)
            db.add(al)
            await db.flush()
            album_map[key] = al.id
        await db.flush()

        # ── Songs + Features ──────────────────────────────────────────
        print("Seeding songs and features...")
        csv_prob_cols = [f"cluster_{i}_prob" for i in range(K)]
        db_prob_cols  = [f"cluster_prob_{i}"  for i in range(K)]

        count           = 0
        acoustic_impute = 0   # used loudness/tempo imputation

        for _, row in df.iterrows():
            clean_artist = clean_str(row["artist_name"])
            artist_id = artist_map.get(clean_artist)
            if not artist_id:
                continue

            album_key = (clean_str(row.get("album_title", "")), clean_artist)
            album_id  = album_map.get(album_key)
            genre_str = str(row.get("genre", ""))
            genre_id  = genre_map.get(genre_str)

            song = Song(
                title      = clean_str(row["title"]),
                artist_id  = artist_id,
                album_id   = album_id,
                genre_id   = genre_id,
                track_id   = str(row["track_id"]),
                duration_s = int(float(row["duration"])) if pd.notna(row.get("duration")) else None,
                play_count = 0,
            )
            db.add(song)
            await db.flush()

            # Always-populated MSD fields (real per-song values)
            loudness = safe_float(row.get("loudness"), -20.0)
            tempo    = safe_float(row.get("tempo"),    120.0)
            mode     = safe_float(row.get("mode"),     0.5)
            hotness  = safe_float(row.get("song_hotttnesss"), 0.5)

            # FIX 8: energy — use CSV value if genuinely non-zero,
            # otherwise derive from loudness (per-song, always varies)
            energy_csv = safe_float(row.get("energy"), 0.0)
            if energy_csv and energy_csv != 0.0:
                energy = round(float(np.clip(energy_csv, 0.0, 1.0)), 4)
            else:
                energy = round(impute_energy(loudness), 4)
                acoustic_impute += 1

            # FIX 8: danceability — use CSV value if non-zero,
            # otherwise derive from tempo + mode (per-song, always varies)
            dance_csv = safe_float(row.get("danceability"), 0.0)
            if dance_csv and dance_csv != 0.0:
                danceability = round(float(np.clip(dance_csv, 0.0, 1.0)), 4)
            else:
                danceability = round(impute_danceability(tempo, mode), 4)

            # Valence always derived (not in MSD)
            valence = impute_valence(mode, tempo, energy, hotness)

            probs = {
                db_col: safe_float(row.get(csv_col), None)
                for db_col, csv_col in zip(db_prob_cols, csv_prob_cols)
            }

            db.add(SongFeature(
                song_id        = song.id,
                tempo          = safe_float(row.get("tempo"),    None),
                loudness       = safe_float(row.get("loudness"), None),
                key            = int(float(row["key"])) if pd.notna(row.get("key")) else None,
                energy         = energy,
                danceability   = danceability,
                valence        = valence,
                mfcc_1         = safe_float(row.get("mfcc_1"), None),
                mfcc_2         = safe_float(row.get("mfcc_2"), None),
                mfcc_3         = safe_float(row.get("mfcc_3"), None),
                mfcc_4         = safe_float(row.get("mfcc_4"), None),
                mfcc_5         = safe_float(row.get("mfcc_5"), None),
                fcm_cluster    = int(float(row["cluster"])) if pd.notna(row.get("cluster")) else None,
                fcm_confidence = safe_float(row.get("cluster_confidence"), None),
                **probs,
            ))

            count += 1
            if count % BATCH_FLUSH == 0:
                await db.flush()
            if count % BATCH_COMMIT == 0:
                await db.commit()
                print(f"  ... {count:,} songs committed")

        await db.commit()

    pct = 100 * acoustic_impute / count if count else 0
    print(f"\nDone! {count:,} MSD songs seeded with K={K} cluster memberships.")
    print(f"  energy   : {count - acoustic_impute:,} from CSV, "
          f"{acoustic_impute:,} derived from loudness ({pct:.1f}%)")
    print(f"  danceability: derived from tempo+mode where CSV was 0")
    print(f"  valence  : derived from mode+tempo+energy+hotttnesss (NaN-safe)")


asyncio.run(seed())
