-- Runs automatically when PostgreSQL container starts (via docker-entrypoint-initdb.d)
-- SQLAlchemy will create the actual tables via create_all() on first startup.
-- This file sets up extensions and performance config.

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS pg_trgm;   -- For fuzzy text matching on song titles
CREATE EXTENSION IF NOT EXISTS unaccent;  -- For accent-insensitive search

-- Performance settings (applied at session level)
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET work_mem = '16MB';
ALTER SYSTEM SET maintenance_work_mem = '64MB';
ALTER SYSTEM SET random_page_cost = '1.1';  -- SSD-friendly

SELECT pg_reload_conf();
