/** @type {import('next').NextConfig} */

// Fallback to the Docker service name so the rewrite is never "undefined/..."
const API_ORIGIN =
  process.env.NEXT_PUBLIC_API_URL ||
  process.env.BACKEND_URL ||         // server-side only alternative
  "http://music_backend:8000";       // docker-compose default service name

const nextConfig = {
  reactStrictMode: true,
  async rewrites() {
    return [
      {
        source:      "/api/:path*",
        destination: `${API_ORIGIN}/api/:path*`,
      },
    ];
  },
};

module.exports = nextConfig;
