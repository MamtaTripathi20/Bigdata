"use client";

import { usePlayer } from "@/components/ui/PlayerContext";
import { X, Music, Play, Trash2 } from "lucide-react";
import { clsx } from "clsx";
import { MODE_META } from "@/types";

const COVER_GRADIENTS = [
  ["#4f8ef7", "#c084fc"],
  ["#c084fc", "#2dd4bf"],
  ["#2dd4bf", "#4f8ef7"],
  ["#f59e0b", "#ef4444"],
  ["#ec4899", "#8b5cf6"],
];

export function QueuePanel() {
  const {
    showQueue, toggleQueue, queue, currentSong, isPlaying,
    playSong, removeFromQueue,
  } = usePlayer();

  return (
    <>
      {/* Backdrop */}
      {showQueue && (
        <div
          className="fixed inset-0 z-40 fade-in"
          style={{ background: "rgba(0,0,0,0.4)" }}
          onClick={toggleQueue}
        />
      )}

      {/* Panel */}
      {showQueue && (
      <div
        className="fixed right-0 top-0 bottom-0 z-50 flex flex-col transition-all duration-300 ease-in-out"
        style={{
          width:      "340px",
          transform:  "translateX(0)",
          background: "rgba(10, 10, 20, 0.97)",
          backdropFilter: "blur(32px)",
          borderLeft: "1px solid rgba(255,255,255,0.07)",
          boxShadow:  "-16px 0 48px rgba(0,0,0,0.5)",
          paddingBottom: "88px", // account for PlayerBar
        }}
        role="dialog"
        aria-modal="true"
        aria-label="Queue"
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-5 py-4 flex-shrink-0"
          style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
        >
          <div>
            <h2 className="font-display font-bold text-base text-white">Queue</h2>
            <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.35)" }}>
              {queue.length} {queue.length === 1 ? "track" : "tracks"} up next
            </p>
          </div>
          <button
            onClick={toggleQueue}
            className="p-2 rounded-xl transition-colors"
            style={{ color: "rgba(255,255,255,0.4)" }}
            onMouseEnter={(e) => { e.currentTarget.style.color = "white"; e.currentTarget.style.background = "rgba(255,255,255,0.07)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.color = "rgba(255,255,255,0.4)"; e.currentTarget.style.background = "transparent"; }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Now playing */}
        {currentSong && (
          <div className="px-4 py-3 flex-shrink-0">
            <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "rgba(255,255,255,0.25)" }}>
              Now Playing
            </p>
            <QueueItem
              song={currentSong}
              isPlaying={isPlaying}
              isCurrent
              accent={`var(--${currentSong.mode})`}
            />
          </div>
        )}

        {/* Divider */}
        {queue.length > 0 && (
          <div
            className="mx-4 my-1"
            style={{ height: "1px", background: "rgba(255,255,255,0.05)" }}
          />
        )}

        {/* Up next */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-1">
          {queue.length === 0 ? (
            <div className="text-center py-12">
              <div
                className="w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-3"
                style={{ background: "rgba(255,255,255,0.04)" }}
              >
                <Music className="w-5 h-5" style={{ color: "rgba(255,255,255,0.15)" }} />
              </div>
              <p className="text-sm font-display font-bold" style={{ color: "rgba(255,255,255,0.3)" }}>
                Queue is empty
              </p>
              <p className="text-xs mt-1.5" style={{ color: "rgba(255,255,255,0.18)" }}>
                Add tracks using the ⊕ button on any song
              </p>
            </div>
          ) : (
            <>
              <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "rgba(255,255,255,0.25)" }}>
                Up Next
              </p>
              {queue.map((item, idx) => (
                <QueueItem
                  key={item.queueId}
                  song={item}
                  mode={item.mode}
                  onPlay={() => playSong(item, item.mode)}
                  onRemove={() => removeFromQueue(item.queueId)}
                  rank={idx + 1}
                />
              ))}
            </>
          )}
        </div>
      </div>
      )}
    </>
  );
}

function QueueItem({
  song, mode, isCurrent, isPlaying, accent, onPlay, onRemove, rank,
}: {
  song:       any;
  mode?:      string;
  isCurrent?: boolean;
  isPlaying?: boolean;
  accent?:    string;
  onPlay?:    () => void;
  onRemove?:  () => void;
  rank?:      number;
}) {
  const gradColors = COVER_GRADIENTS[song.song_id % COVER_GRADIENTS.length];
  const modeAccent = accent ?? (mode ? `var(--${mode})` : "var(--analytics)");

  return (
    <div
      className="group flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-150 cursor-pointer"
      style={{
        background: isCurrent ? "rgba(255,255,255,0.07)" : "transparent",
        border:     `1px solid ${isCurrent ? "rgba(255,255,255,0.09)" : "transparent"}`,
      }}
      onMouseEnter={(e) => {
        if (!isCurrent) {
          e.currentTarget.style.background = "rgba(255,255,255,0.04)";
          e.currentTarget.style.border = "1px solid rgba(255,255,255,0.07)";
        }
      }}
      onMouseLeave={(e) => {
        if (!isCurrent) {
          e.currentTarget.style.background = "transparent";
          e.currentTarget.style.border = "1px solid transparent";
        }
      }}
      onClick={onPlay}
    >
      {/* Cover */}
      <div
        className="w-9 h-9 rounded-lg overflow-hidden flex-shrink-0 relative"
        style={{ boxShadow: isCurrent ? `0 0 10px ${modeAccent}44` : "none" }}
      >
        {song.cover_url ? (
          <img src={song.cover_url} alt={song.title} className="w-full h-full object-cover" />
        ) : (
          <div
            className="w-full h-full flex items-center justify-center"
            style={{ background: `linear-gradient(135deg, ${gradColors[0]}, ${gradColors[1]})` }}
          >
            <Music className="w-3.5 h-3.5 text-white/50" />
          </div>
        )}
        {isCurrent && isPlaying && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <div className="flex gap-px items-end h-3">
              <div className="w-0.5 rounded-full eq-bar-1" style={{ background: modeAccent }} />
              <div className="w-0.5 rounded-full eq-bar-2" style={{ background: modeAccent }} />
              <div className="w-0.5 rounded-full eq-bar-3" style={{ background: modeAccent }} />
            </div>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <p
          className="text-xs font-medium truncate"
          style={{ color: isCurrent ? modeAccent : "var(--text)" }}
        >
          {song.title}
        </p>
        <p className="text-xs truncate mt-0.5" style={{ color: "rgba(255,255,255,0.35)" }}>
          {song.artist}
        </p>
      </div>

      {/* Mode dot */}
      {mode && (
        <div
          className="w-1.5 h-1.5 rounded-full flex-shrink-0"
          style={{ background: modeAccent }}
          title={mode}
        />
      )}

      {/* Remove button (queue items only) */}
      {onRemove && (
        <button
          onClick={(e) => { e.stopPropagation(); onRemove(); }}
          className="p-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-all flex-shrink-0"
          style={{ color: "rgba(255,255,255,0.3)" }}
          onMouseEnter={(e) => { e.currentTarget.style.color = "rgba(239,68,68,0.8)"; }}
          onMouseLeave={(e) => { e.currentTarget.style.color = "rgba(255,255,255,0.3)"; }}
          title="Remove from queue"
          aria-label="Remove from queue"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  );
}
