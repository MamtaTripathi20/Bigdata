"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Home,
  Library,
  Mic2,
  Disc3,
  ChevronLeft,
  ChevronRight,
  Music4,
  ListMusic,
} from "lucide-react";
import { clsx } from "clsx";

interface NavItem {
  href:  string;
  icon:  React.ReactNode;
  label: string;
}

const NAV_ITEMS: NavItem[] = [
  { href: "/",               icon: <Home    className="w-4 h-4" />, label: "Home" },
  { href: "/library",        icon: <Library className="w-4 h-4" />, label: "Library" },
  { href: "/artists",        icon: <Mic2    className="w-4 h-4" />, label: "Artists" },
  { href: "/albums",         icon: <Disc3   className="w-4 h-4" />, label: "Albums" },
  { href: "/library/playlists", icon: <ListMusic className="w-4 h-4" />, label: "Playlists" },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();

  return (
    <aside
      className="hidden md:flex flex-col flex-shrink-0 transition-all duration-300 ease-in-out relative"
      style={{
        width:      collapsed ? "64px" : "220px",
        background: "rgba(10, 10, 20, 0.95)",
        borderRight: "1px solid rgba(255,255,255,0.06)",
        height:     "calc(100vh - 88px)", // account for PlayerBar
        position:   "sticky",
        top:        0,
      }}
    >
      {/* Logo */}
      <div
        className="flex items-center gap-3 px-4 py-5 border-b"
        style={{ borderColor: "rgba(255,255,255,0.06)" }}
      >
        <div
          className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{
            background: "linear-gradient(135deg, #4f8ef7 0%, #c084fc 50%, #2dd4bf 100%)",
            boxShadow:  "0 0 16px rgba(79,142,247,0.35)",
          }}
        >
          <Music4 className="w-4 h-4 text-white" />
        </div>
        {!collapsed && (
          <div className="slide-left" style={{ animationDelay: "0.05s" }}>
            <p className="text-sm font-display font-bold text-white leading-none">Resonance</p>
            <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.3)" }}>Multi-Mode AI</p>
          </div>
        )}
      </div>

      {/* Nav items */}
      <nav className="flex-1 p-2 space-y-0.5 overflow-y-auto mt-2">
        {NAV_ITEMS.map((item) => {
          const isActive = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={clsx(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-150 group",
                isActive
                  ? "text-white"
                  : "text-white/40 hover:text-white/70"
              )}
              style={{
                background: isActive ? "rgba(79,142,247,0.12)" : "transparent",
                border:     isActive ? "1px solid rgba(79,142,247,0.2)" : "1px solid transparent",
              }}
              title={collapsed ? item.label : undefined}
            >
              <span
                className={clsx("flex-shrink-0 transition-colors", isActive ? "text-analytics-500" : "")}
              >
                {item.icon}
              </span>
              {!collapsed && (
                <span className="text-sm font-medium truncate">{item.label}</span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Mode legend */}
      {!collapsed && (
        <div
          className="mx-2 mb-3 p-3 rounded-xl fade-in"
          style={{
            background: "rgba(255,255,255,0.03)",
            border:     "1px solid rgba(255,255,255,0.05)",
          }}
        >
          <p className="text-xs font-display font-semibold text-white/30 mb-2 uppercase tracking-wider">AI Modes</p>
          {[
            { color: "#4f8ef7", label: "Analytics", sub: "ML-based" },
            { color: "#c084fc", label: "GenAI",     sub: "Embeddings" },
            { color: "#2dd4bf", label: "Hybrid",    sub: "Fusion" },
          ].map((m) => (
            <div key={m.label} className="flex items-center gap-2 mb-1.5 last:mb-0">
              <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: m.color }} />
              <span className="text-xs text-white/55 font-medium">{m.label}</span>
              <span className="text-xs text-white/25 ml-auto">{m.sub}</span>
            </div>
          ))}
        </div>
      )}

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-16 w-6 h-6 rounded-full flex items-center justify-center z-10 transition-all hover:scale-110"
        style={{
          background: "#10101e",
          border:     "1px solid rgba(255,255,255,0.12)",
          boxShadow:  "0 2px 8px rgba(0,0,0,0.4)",
          color:      "rgba(255,255,255,0.5)",
        }}
        title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
      >
        {collapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
      </button>
    </aside>
  );
}
