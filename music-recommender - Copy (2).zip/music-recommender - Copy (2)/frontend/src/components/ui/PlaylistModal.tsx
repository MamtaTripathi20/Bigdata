"use client";

// ✅ Fix: added Escape key handler to close modal
// 🎨 Enhancement: scale-in animation on open
// 🎨 Enhancement: better "added" state — shows playlist song count increment
// 🎨 Enhancement: new playlist auto-focuses input on open
// ⚡ Optimization: no API or logic changes

import { useEffect, useState, useCallback, useRef } from "react";
import { X, Plus, Check, ListMusic, Loader2 } from "lucide-react";
import type { RecommendedSong } from "@/types";
import { libraryApi } from "@/lib/api";

interface PlaylistModalProps {
  song:    RecommendedSong | null;
  onClose: () => void;
}

interface Playlist {
  id:         number;
  name:       string;
  song_count: number;
  is_public:  boolean;
}

export function PlaylistModal({ song, onClose }: PlaylistModalProps) {
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [loading,   setLoading]   = useState(false);
  const [creating,  setCreating]  = useState(false);
  const [newName,   setNewName]   = useState("");
  const [added,     setAdded]     = useState<Set<number>>(new Set());
  const [saving,    setSaving]    = useState<number | null>(null);
  const [errorMsg,  setErrorMsg]  = useState<string>("");
  const inputRef = useRef<HTMLInputElement>(null);
  const modalRef = useRef<HTMLDivElement>(null);
  const closeBtnRef = useRef<HTMLButtonElement>(null);

  const parsePlaylists = (payload: any): Playlist[] => {
    const raw = Array.isArray(payload)
      ? payload
      : Array.isArray(payload?.items)
      ? payload.items
      : Array.isArray(payload?.playlists)
      ? payload.playlists
      : [];

    return raw.filter((item: any) => item && typeof item.id === "number");
  };

  // ✅ Fix: Escape closes modal
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === "Escape") onClose();
  }, [onClose]);

  useEffect(() => {
    if (!song) return;
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [song, handleKeyDown]);

  useEffect(() => {
    if (!song) return;
    setLoading(true);
    setAdded(new Set());
    setNewName("");
    setErrorMsg("");
    libraryApi.getPlaylists()
      .then((r) => setPlaylists(parsePlaylists(r.data)))
      .catch((e) => {
        console.error(e);
        setPlaylists([]);
        setErrorMsg("Could not load playlists. Please try again.");
      })
      .finally(() => setLoading(false));
    // 🎨 Enhancement: auto-focus name input for fast creation
    setTimeout(() => inputRef.current?.focus(), 100);
  }, [song?.song_id]);

  useEffect(() => {
    if (!song) return;
    closeBtnRef.current?.focus();

    const onTrap = (e: KeyboardEvent) => {
      if (e.key !== "Tab" || !modalRef.current) return;
      const focusables = modalRef.current.querySelectorAll<HTMLElement>(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];

      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", onTrap);
    return () => document.removeEventListener("keydown", onTrap);
  }, [song]);

  if (!song) return null;

  const handleAdd = async (playlistId: number) => {
    if (added.has(playlistId)) return;
    setSaving(playlistId);
    try {
      await libraryApi.addSongToPlaylist(playlistId, song.song_id);
      setAdded((prev) => new Set([...prev, playlistId]));
      setErrorMsg("");
      // 🎨 Enhancement: update local song_count so UI reflects the add
      setPlaylists((prev) =>
        prev.map((pl) =>
          pl.id === playlistId ? { ...pl, song_count: pl.song_count + 1 } : pl
        )
      );
    } catch (e) {
      console.error(e);
      setErrorMsg("Could not add this song to the playlist.");
    } finally {
      setSaving(null);
    }
  };

  const handleCreate = async () => {
    if (!newName.trim()) return;
    setCreating(true);
    try {
      const res = await libraryApi.createPlaylist(newName.trim());
      const created = Array.isArray(res.data?.items)
        ? res.data.items[0]
        : res.data?.playlist ?? res.data;
      if (!created?.id) {
        setErrorMsg("Playlist was created but could not be loaded. Please refresh.");
        return;
      }
      setPlaylists((prev) => [created, ...prev]);
      setNewName("");
      setErrorMsg("");
      await handleAdd(created.id);
    } catch (e) {
      console.error(e);
      setErrorMsg("Could not create playlist. Please try again.");
    } finally {
      setCreating(false);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm" onClick={onClose} />

      {/* 🎨 Enhancement: scale-in animation */}
      <div
        ref={modalRef}
        className="fixed z-50 left-1/2 top-1/2 w-full max-w-sm rounded-2xl overflow-hidden scale-in"
        style={{
          background: "#16161f",
          border:     "1px solid rgba(255,255,255,0.1)",
          boxShadow:  "0 24px 64px rgba(0,0,0,0.7)",
          transform:  "translate(-50%, -50%)",
        }}
        role="dialog"
        aria-modal="true"
        aria-labelledby="playlist-modal-title"
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-5 py-4"
          style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
        >
          <div>
            <h3 id="playlist-modal-title" className="text-sm font-semibold text-white">Add to playlist</h3>
            <p className="text-xs mt-0.5 truncate text-white/38">
              {song.title} — {song.artist}
            </p>
          </div>
          <button
            ref={closeBtnRef}
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/35 hover:text-white/80 transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {errorMsg && (
          <div
            className="mx-4 mt-3 rounded-lg px-3 py-2 text-xs"
            style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.18)", color: "rgba(248,113,113,0.95)" }}
          >
            {errorMsg}
          </div>
        )}

        {/* Create new playlist */}
        <div className="px-4 py-3" style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <div className="flex gap-2">
            <input
              ref={inputRef}
              type="text"
              placeholder="New playlist name…"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreate()}
              className="flex-1 text-sm px-3 py-2 rounded-xl outline-none text-white placeholder-white/20 focus-ring"
              style={{
                background: "rgba(255,255,255,0.06)",
                border:     "1px solid rgba(255,255,255,0.08)",
              }}
            />
            <button
              onClick={handleCreate}
              disabled={!newName.trim() || creating}
              className="px-3 py-2 rounded-xl text-xs font-medium transition-all disabled:opacity-40 focus-ring"
              style={{
                background: "rgba(139,92,246,0.25)",
                color:      "rgba(192,132,252,0.9)",
              }}
              aria-label="Create playlist"
            >
              {creating
                ? <Loader2 className="w-4 h-4 animate-spin" />
                : <Plus className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Playlist list */}
        <div className="max-h-60 overflow-y-auto py-1.5">
          {loading ? (
            <div className="px-4 py-2 space-y-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="skeleton h-12 rounded-lg" />
              ))}
            </div>
          ) : playlists.length === 0 ? (
            <div className="text-center py-8 space-y-2">
              <ListMusic className="w-8 h-8 mx-auto text-white/10" />
              <p className="text-xs text-white/28">
                No playlists yet — create one above
              </p>
            </div>
          ) : (
            playlists.map((pl) => {
              const isAdded  = added.has(pl.id);
              const isSaving = saving === pl.id;
              return (
                <button
                  key={pl.id}
                  onClick={() => handleAdd(pl.id)}
                  disabled={isAdded || isSaving}
                  className="w-full flex items-center gap-3 px-4 py-2.5 transition-colors text-left disabled:opacity-70 hover:bg-white/[4%] focus-ring"
                >
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ background: "rgba(255,255,255,0.06)" }}
                  >
                    <ListMusic className="w-3.5 h-3.5 text-white/25" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate">{pl.name}</p>
                    <p className="text-xs text-white/28">
                      {pl.song_count} song{pl.song_count !== 1 ? "s" : ""}
                      {pl.is_public ? " · Public" : ""}
                    </p>
                  </div>
                  <div className="flex-shrink-0">
                    {isSaving ? (
                      <Loader2 className="w-4 h-4 text-white/30 animate-spin" />
                    ) : isAdded ? (
                      <Check className="w-4 h-4 text-green-400" />
                    ) : (
                      <Plus className="w-4 h-4 text-white/25" />
                    )}
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>
    </>
  );
}
