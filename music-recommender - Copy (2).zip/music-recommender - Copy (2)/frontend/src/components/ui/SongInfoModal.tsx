"use client";

// ✅ Fix: added Escape key handler to close modal (missing from original)
// ✅ Fix: modal scroll overflow — long content now scrolls inside, not the full page
// 🎨 Enhancement: audio feature bars have mode-matching colors
// 🎨 Enhancement: scale-in animation on open
// 🎨 Enhancement: skeleton loading state for song detail
// ⚡ Optimization: no logic changes, same API calls

import { useEffect, useState, useCallback } from "react";
import { X, Music, ExternalLink, Disc3 } from "lucide-react";
import type { RecommendedSong } from "@/types";
import { libraryApi } from "@/lib/api";

interface SongInfoModalProps {
  song:    RecommendedSong | null;
  onClose: () => void;
}

interface SongDetail {
  song_id:         number;
  title:           string;
  artist:          string;
  artist_id:       number;
  album?:          string;
  album_id?:       number;
  genre?:          string;
  duration_s?:     number;
  play_count:      number;
  tempo?:          number;
  loudness?:       number;
  key_name?:       string;
  mode_name?:      string;
  time_signature?: number;
  energy?:         number;
  danceability?:   number;
  mfcc_1?:         number;
  liked:           boolean;
  times_played:    number;
}

function formatDuration(s?: number) {
  if (!s) return "—";
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

function FeatureBar({ label, value, max = 1, color = "rgba(139,92,246,0.7)" }: {
  label: string;
  value?: number;
  max?: number;
  color?: string;
}) {
  if (value == null) return null;
  const pct = Math.min(100, (value / max) * 100);
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs w-24 flex-shrink-0 text-white/38">{label}</span>
      <div className="flex-1 h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.07)" }}>
        {/* 🎨 Enhancement: animated bar fill on mount */}
        <div
          className="h-1.5 rounded-full transition-all duration-700 ease-out"
          style={{ width: `${pct}%`, background: color }}
        />
      </div>
      <span className="text-xs w-10 text-right font-mono text-white/38">
        {max === 1 ? value.toFixed(2) : Math.round(value)}
      </span>
    </div>
  );
}

// 🎨 Enhancement: skeleton for loading detail
function DetailSkeleton() {
  return (
    <div className="px-5 pb-4 space-y-4">
      <div className="grid grid-cols-3 gap-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="skeleton h-12 rounded-lg" />
        ))}
      </div>
      <div className="space-y-2.5">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3">
            <div className="skeleton h-2.5 w-20 rounded" />
            <div className="skeleton flex-1 h-1.5 rounded-full" />
            <div className="skeleton h-2.5 w-8 rounded" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function SongInfoModal({ song, onClose }: SongInfoModalProps) {
  const [detail,  setDetail]  = useState<SongDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const modalRef = useCallback((node: HTMLDivElement | null) => {
    if (!node) return;
    const closeBtn = node.querySelector<HTMLButtonElement>('button[aria-label="Close"]');
    closeBtn?.focus();
  }, []);

  // ✅ Fix: Escape key closes modal
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === "Escape") onClose();
  }, [onClose]);

  useEffect(() => {
    if (!song) return;
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [song, handleKeyDown]);

  useEffect(() => {
    if (!song) return;
    setDetail(null);
    setLoading(true);
    setErrorMsg("");
    libraryApi.getSongDetail(song.song_id)
      .then((r) => setDetail(r.data))
      .catch((e) => {
        console.error(e);
        setErrorMsg("Could not load song details right now.");
      })
      .finally(() => setLoading(false));
  }, [song?.song_id]);

  useEffect(() => {
    if (!song) return;

    const onTrap = (e: KeyboardEvent) => {
      if (e.key !== "Tab") return;
      const modal = document.getElementById("song-info-modal");
      if (!modal) return;
      const focusables = modal.querySelectorAll<HTMLElement>(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];

      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", onTrap);
    return () => document.removeEventListener("keydown", onTrap);
  }, [song]);

  if (!song) return null;

  const d = detail;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal — ✅ Fix: max-h + overflow-y-auto prevents page scroll */}
      <div
        id="song-info-modal"
        ref={modalRef}
        className="fixed z-50 left-1/2 top-1/2 w-full max-w-md rounded-2xl overflow-hidden scale-in"
        style={{
          background:  "#16161f",
          border:      "1px solid rgba(255,255,255,0.1)",
          boxShadow:   "0 24px 64px rgba(0,0,0,0.7)",
          maxHeight:   "calc(100vh - 120px)",
          transform:   "translate(-50%, -50%)",
        }}
        role="dialog"
        aria-modal="true"
        aria-labelledby="song-info-title"
      >
        {/* Inner scroll container */}
        <div className="overflow-y-auto max-h-[calc(100vh-140px)]">
          {/* Header */}
          <div className="flex items-start gap-4 p-5 pb-4 sticky top-0"
               style={{ background: "#16161f", zIndex: 1 }}>
            {/* Cover */}
            <div className="w-16 h-16 rounded-xl flex-shrink-0 overflow-hidden"
                 style={{ background: "rgba(255,255,255,0.06)" }}>
              {song.cover_url ? (
                <img src={song.cover_url} alt={song.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Music className="w-6 h-6 text-white/20" />
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0 pt-1">
              <h2 id="song-info-title" className="text-base font-semibold text-white truncate">{song.title}</h2>
              <p className="text-sm mt-0.5 truncate text-white/50">{song.artist}</p>
              {(song.album || d?.album) && (
                <p className="text-xs mt-1 truncate text-white/28 flex items-center gap-1">
                  <Disc3 className="w-3 h-3" />
                  {song.album || d?.album}
                </p>
              )}
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-white/35 hover:text-white/80 transition-colors flex-shrink-0"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {errorMsg && (
            <div
              className="mx-5 mb-3 rounded-lg px-3 py-2 text-xs"
              style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.18)", color: "rgba(248,113,113,0.95)" }}
            >
              {errorMsg}
            </div>
          )}

          {/* Stats row */}
          <div
            className="flex mx-5 mb-4 rounded-xl overflow-hidden"
            style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}
          >
            {[
              { label: "Genre",    value: song.genre || d?.genre || "—" },
              { label: "Duration", value: formatDuration(d?.duration_s) },
              { label: "Plays",    value: d ? String(d.play_count) : "—" },
              { label: "Liked",    value: d ? (d.liked ? "♥" : "—") : "—" },
            ].map((item, i) => (
              <div
                key={item.label}
                className="flex-1 py-3 text-center"
                style={{ borderRight: i < 3 ? "1px solid rgba(255,255,255,0.06)" : "none" }}
              >
                <div className={clsx("text-xs font-medium", item.label === "Liked" && d?.liked ? "text-red-400" : "text-white")}>
                  {item.value}
                </div>
                <div className="text-xs mt-0.5 text-white/28">{item.label}</div>
              </div>
            ))}
          </div>

          {/* Loading skeleton */}
          {loading && <DetailSkeleton />}

          {/* Detail content */}
          {d && (
            <>
              {/* Key / tempo info grid */}
              <div className="px-5 pb-3 grid grid-cols-3 gap-2">
                {[
                  { label: "Key",            value: d.key_name || "—" },
                  { label: "Mode",           value: d.mode_name || "—" },
                  { label: "Time",           value: d.time_signature ? `${d.time_signature}/4` : "—" },
                  { label: "Tempo",          value: d.tempo ? `${Math.round(d.tempo)} BPM` : "—" },
                  { label: "Loudness",       value: d.loudness ? `${d.loudness.toFixed(1)} dB` : "—" },
                  { label: "You played",     value: `${d.times_played}×` },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="rounded-lg px-3 py-2"
                    style={{ background: "rgba(255,255,255,0.04)" }}
                  >
                    <div className="text-xs font-medium text-white font-mono">{item.value}</div>
                    <div className="text-xs mt-0.5 text-white/28">{item.label}</div>
                  </div>
                ))}
              </div>

              {/* Audio feature bars */}
              {(d.energy != null || d.danceability != null) && (
                <div className="px-5 pb-5 space-y-2.5">
                  <p className="text-xs font-semibold tracking-wide text-white/28">
                    AUDIO FEATURES
                  </p>
                  <FeatureBar
                    label="Energy"
                    value={d.energy}
                    color="rgba(59,130,246,0.8)"
                  />
                  <FeatureBar
                    label="Danceability"
                    value={d.danceability}
                    color="rgba(168,85,247,0.8)"
                  />
                  <FeatureBar
                    label="MFCC-1"
                    value={d.mfcc_1 != null
                      ? Math.min(1, Math.max(0, (d.mfcc_1 + 300) / 600))
                      : undefined}
                    color="rgba(16,185,129,0.8)"
                  />
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer links */}
        <div
          className="flex gap-2 px-5 py-3"
          style={{ borderTop: "1px solid rgba(255,255,255,0.06)", background: "#16161f" }}
        >
          <ExternalButton
            href={`https://www.youtube.com/results?search_query=${encodeURIComponent(`${song.title} ${song.artist}`)}`}
            label="YouTube"
          />
          <ExternalButton
            href={`https://open.spotify.com/search/${encodeURIComponent(`${song.title} ${song.artist}`)}`}
            label="Spotify"
          />
        </div>
      </div>
    </>
  );
}

// 🎨 Enhancement: small reusable external link button
function ExternalButton({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs transition-all hover:bg-white/10 focus-ring"
      style={{ background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.55)" }}
    >
      <ExternalLink className="w-3 h-3" />
      {label}
    </a>
  );
}

// needed for the liked check above
function clsx(...args: (string | boolean | undefined)[]) {
  return args.filter(Boolean).join(" ");
}
