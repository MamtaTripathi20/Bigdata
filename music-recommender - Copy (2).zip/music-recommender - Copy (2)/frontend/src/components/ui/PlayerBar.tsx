"use client";

import { usePlayer } from "@/components/ui/PlayerContext";
import {
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX,
  ListMusic, Heart, Loader2, Music, Infinity,
} from "lucide-react";
import { MODE_META } from "@/types";

function formatTime(s: number) {
  if (!s || isNaN(s) || s <= 0) return "0:00";
  const m   = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

function getPctFromEvent(
  e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>,
  el: HTMLDivElement
) {
  const rect    = el.getBoundingClientRect();
  const clientX = "touches" in e
    ? e.touches[0]?.clientX ?? e.changedTouches[0]?.clientX
    : e.clientX;
  return Math.max(0, Math.min(100, ((clientX - rect.left) / rect.width) * 100));
}

const MODE_ACCENT: Record<string, string> = {
  analytics: "var(--analytics)",
  genai:     "var(--genai)",
  hybrid:    "var(--hybrid)",
};

function SourceBadge({ source }: { source: "youtube" | "itunes" | "loading" | "none" }) {
  if (source === "none") return null;
  if (source === "loading") return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs animate-pulse"
      style={{ background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.3)", fontSize: 10 }}
    >
      <Loader2 className="w-2.5 h-2.5 animate-spin" /> Loading…
    </span>
  );
  if (source === "youtube") return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold"
      style={{ background: "rgba(255,60,60,0.15)", color: "rgba(255,90,90,0.9)", fontSize: 10 }}
    >
      ▶ YouTube
    </span>
  );
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold"
      style={{ background: "rgba(45,212,191,0.12)", color: "rgba(52,211,153,0.85)", fontSize: 10 }}
    >
      ♫ iTunes Preview
    </span>
  );
}

export function PlayerBar() {
  const {
    currentSong, isPlaying, progress, duration, volume,
    isLoadingYT, showQueue, autoPlay, isLoadingNext,
    audioSource,
    togglePlay, next, prev, seek, setVolume,
    toggleQueue, toggleLike, isLiked, toggleAutoPlay,
  } = usePlayer();

  if (!currentSong) return null;

  const liked    = isLiked(currentSong.song_id);
  const accent   = MODE_ACCENT[currentSong.mode] ?? "var(--analytics)";
  const modeMeta = MODE_META[currentSong.mode];

  const handleSeek = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    seek(getPctFromEvent(e, e.currentTarget as HTMLDivElement));
  };

  const currentTime = (progress / 100) * duration;

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-50"
      style={{
        height:         "88px",
        backdropFilter: "blur(32px) saturate(180%)",
      }}
    >
      {/* Blurred album art backdrop */}
      {currentSong.cover_url && (
        <div
          className="absolute inset-0 opacity-20 pointer-events-none"
          style={{
            backgroundImage:    `url(${currentSong.cover_url})`,
            backgroundSize:     "cover",
            backgroundPosition: "center",
            filter:             "blur(40px)",
          }}
        />
      )}
      {/* Dark overlay */}
      <div className="absolute inset-0" style={{ background: "rgba(6, 6, 14, 0.90)" }} />
      {/* Top glow + progress line */}
      {/* Ambient glow that spans the full width — always visible */}
      <div
        className="absolute top-0 left-0 right-0 pointer-events-none"
        style={{
          height: "3px",
          background: `linear-gradient(90deg, transparent 0%, ${accent}55 30%, ${accent}70 50%, ${accent}55 70%, transparent 100%)`,
          filter: "blur(2px)",
        }}
      />
      {/* Hard top border */}
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: "rgba(255,255,255,0.10)" }} />
      {/* Progress line — follows playback */}
      <div
        className="absolute top-0 left-0 h-px transition-all duration-700"
        style={{ background: accent, width: `${progress}%`, opacity: 1.0 }}
      />
      {/* Glow blob under the progress thumb */}
      {progress > 0 && (
        <div
          className="absolute top-0 h-2 pointer-events-none transition-all duration-700"
          style={{
            left:    `calc(${Math.min(progress, 98)}% - 12px)`,
            width:   "24px",
            background: accent,
            filter:  "blur(6px)",
            opacity: 0.75,
          }}
        />
      )}

      <div className="relative h-full max-w-screen-2xl mx-auto px-4 sm:px-6 flex items-center">

        {/* ── MOBILE LAYOUT ─────────────────────────────────────────── */}
        <div className="sm:hidden w-full space-y-2 py-2">
          {/* Top row: art + title + controls */}
          <div className="flex items-center gap-3">
            <CoverArt song={currentSong} size={36} isLoadingYT={isLoadingYT} />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold truncate text-white">{currentSong.title}</p>
              <p className="text-xs truncate" style={{ color: "rgba(255,255,255,0.4)" }}>{currentSong.artist}</p>
            </div>
            <SourceBadge source={audioSource} />
            <button
              onClick={() => toggleLike(currentSong.song_id)}
              className="p-1.5 flex-shrink-0 transition-all"
              style={{ color: liked ? "rgb(248,113,113)" : "rgba(255,255,255,0.3)" }}
              aria-label={liked ? "Unlike song" : "Like song"}
              aria-pressed={liked}
            >
              <Heart className="w-4 h-4" fill={liked ? "currentColor" : "none"} />
            </button>
            <ControlBtn onClick={prev} aria-label="Previous"><SkipBack className="w-4 h-4" /></ControlBtn>
            <PlayBtn isPlaying={isPlaying} onClick={togglePlay} accent={accent} size="sm" />
            <ControlBtn onClick={next} aria-label="Next"><SkipForward className="w-4 h-4" /></ControlBtn>
          </div>
          {/* Progress bar */}
          <ProgressBar
            progress={progress}
            duration={duration}
            currentTime={currentTime}
            isLoadingDuration={audioSource === "loading"}
            onSeek={handleSeek}
            accent={accent}
            compact
          />
        </div>

        {/* ── DESKTOP LAYOUT ────────────────────────────────────────── */}
        <div className="hidden sm:grid w-full grid-cols-3 items-center gap-6">

          {/* Left: song info */}
          <div className="flex items-center gap-3 min-w-0">
            <CoverArt song={currentSong} size={44} isLoadingYT={isLoadingYT} />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold truncate text-white">{currentSong.title}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <p className="text-xs truncate" style={{ color: "rgba(255,255,255,0.42)" }}>
                  {currentSong.artist}
                </p>
                <SourceBadge source={audioSource} />
              </div>
            </div>
            <button
              onClick={() => toggleLike(currentSong.song_id)}
              className="p-1.5 rounded-full flex-shrink-0 transition-all"
              style={{ color: liked ? "rgb(248,113,113)" : "rgba(255,255,255,0.25)" }}
              aria-label={liked ? "Unlike song" : "Like song"}
              aria-pressed={liked}
            >
              <Heart className="w-4 h-4" fill={liked ? "currentColor" : "none"} />
            </button>
          </div>

          {/* Center: controls + progress */}
          <div className="flex flex-col items-center gap-2">
            <div className="flex items-center gap-4">
              <ControlBtn onClick={prev} aria-label="Previous">
                <SkipBack className="w-4 h-4" />
              </ControlBtn>
              <PlayBtn isPlaying={isPlaying} onClick={togglePlay} accent={accent} size="md" />
              <ControlBtn onClick={next} aria-label="Next">
                <SkipForward className="w-4 h-4" />
              </ControlBtn>
            </div>
            <ProgressBar
              progress={progress}
              duration={duration}
              currentTime={currentTime}
              isLoadingDuration={audioSource === "loading"}
              onSeek={handleSeek}
              accent={accent}
            />
          </div>

          {/* Right: volume + queue + autoplay */}
          <div className="flex items-center gap-2 justify-end">
            {(isLoadingYT || isLoadingNext) && (
              <span className="text-xs flex items-center gap-1" style={{ color: "rgba(255,255,255,0.25)" }}>
                <Loader2 className="w-3 h-3 animate-spin" />
                <span className="hidden lg:inline">{isLoadingNext ? "Finding next…" : "Loading…"}</span>
              </span>
            )}

            {/* Mode badge */}
            <span
              className="hidden lg:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold"
              style={{
                background: `${accent}22`,
                color:      accent,
                border:     `1px solid ${accent}44`,
              }}
            >
              {modeMeta.icon} {modeMeta.label}
            </span>

            {/* Autoplay */}
            <button
              onClick={toggleAutoPlay}
              title={autoPlay ? "Autoplay on" : "Autoplay off"}
              className="p-2 rounded-lg transition-all relative"
              style={{
                background: autoPlay ? "rgba(45,212,191,0.1)" : "transparent",
                color:      autoPlay ? "var(--hybrid)" : "rgba(255,255,255,0.25)",
              }}
              aria-label={autoPlay ? "Disable autoplay" : "Enable autoplay"}
              aria-pressed={autoPlay}
            >
              <Infinity className="w-4 h-4" />
              {autoPlay && (
                <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-hybrid-500" />
              )}
            </button>

            {/* Volume */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setVolume(volume > 0 ? 0 : 0.8)}
                className="transition-colors"
                style={{ color: "rgba(255,255,255,0.35)" }}
                aria-label={volume === 0 ? "Unmute" : "Mute"}
              >
                {volume === 0
                  ? <VolumeX className="w-4 h-4" />
                  : <Volume2 className="w-4 h-4" />
                }
              </button>
              <input
                type="range" min={0} max={1} step={0.01} value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-20 hidden lg:block"
                style={{ accentColor: accent }}
                aria-label="Volume"
              />
            </div>

            {/* Queue */}
            <button
              onClick={toggleQueue}
              className="p-2 rounded-lg transition-all"
              style={{
                background: showQueue ? "rgba(255,255,255,0.1)" : "transparent",
                color:      showQueue ? "white" : "rgba(255,255,255,0.35)",
              }}
              title="Queue"
              aria-label={showQueue ? "Hide queue" : "Show queue"}
              aria-pressed={showQueue}
            >
              <ListMusic className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Sub-components ───────────────────────────────────────────── */

function CoverArt({
  song, size, isLoadingYT,
}: {
  song: any; size: number; isLoadingYT: boolean;
}) {
  return (
    <div
      className="rounded-xl overflow-hidden relative flex-shrink-0"
      style={{ width: size, height: size }}
    >
      {song.cover_url ? (
        <img src={song.cover_url} alt={song.title} className="w-full h-full object-cover" />
      ) : (
        <div className="w-full h-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.08)" }}>
          <Music className="w-4 h-4" style={{ color: "rgba(255,255,255,0.2)" }} />
        </div>
      )}
      {isLoadingYT && (
        <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
          <Loader2 className="w-3 h-3 text-white animate-spin" />
        </div>
      )}
    </div>
  );
}

function PlayBtn({
  isPlaying, onClick, accent, size,
}: {
  isPlaying: boolean; onClick: () => void; accent: string; size: "sm" | "md";
}) {
  const dim = size === "md" ? "w-10 h-10" : "w-8 h-8";
  return (
    <button
      onClick={onClick}
      className={`${dim} rounded-full flex items-center justify-center text-black transition-all hover:scale-105 active:scale-95`}
      style={{
        background: "white",
        boxShadow:  `0 0 16px ${accent}55`,
      }}
      aria-label={isPlaying ? "Pause" : "Play"}
    >
      {isPlaying
        ? <Pause className={size === "md" ? "w-4 h-4" : "w-3.5 h-3.5"} />
        : <Play  className={size === "md" ? "w-4 h-4 ml-0.5" : "w-3.5 h-3.5 ml-0.5"} />
      }
    </button>
  );
}

function ControlBtn({
  children, onClick, ...rest
}: {
  children: React.ReactNode; onClick: () => void; [key: string]: any;
}) {
  return (
    <button
      onClick={onClick}
      className="transition-colors"
      style={{ color: "rgba(255,255,255,0.35)" }}
      onMouseEnter={(e) => { e.currentTarget.style.color = "rgba(255,255,255,0.8)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.color = "rgba(255,255,255,0.35)"; }}
      {...rest}
    >
      {children}
    </button>
  );
}

function ProgressBar({
  progress, duration, currentTime, isLoadingDuration, onSeek, accent, compact,
}: {
  progress:          number;
  duration:          number;
  currentTime:       number;
  isLoadingDuration: boolean;
  onSeek:            (e: any) => void;
  accent:            string;
  compact?:          boolean;
}) {
  const timeStr = (t: number, loading: boolean) => {
    if (loading && t <= 0) return <span className="animate-pulse opacity-50">–:––</span>;
    return formatTime(t);
  };

  return (
    <div className={`w-full flex items-center gap-2 ${compact ? "" : ""}`}>
      <span className="text-xs w-8 text-right tabular-nums" style={{ color: "rgba(255,255,255,0.25)", fontFamily: "monospace" }}>
        {timeStr(currentTime, isLoadingDuration)}
      </span>

      <div
        className="flex-1 h-4 flex items-center cursor-pointer group"
        onClick={onSeek}
        onTouchStart={onSeek}
        role="slider"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(progress)}
        aria-label="Playback position"
      >
        <div
          className="w-full rounded-full relative transition-all duration-100"
          style={{ height: "3px", background: "rgba(255,255,255,0.1)" }}
        >
          {/* Filled track */}
          <div
            className="h-full rounded-full"
            style={{ width: `${progress}%`, background: accent }}
          />
          {/* Handle */}
          <div
            className="absolute top-1/2 -translate-y-1/2 rounded-full bg-white shadow-md transition-all duration-100 opacity-0 group-hover:opacity-100"
            style={{
              width:  "12px",
              height: "12px",
              left:   `calc(${progress}% - 6px)`,
              opacity: progress > 0 ? undefined : 0,
            }}
          />
        </div>
      </div>

      <span className="text-xs w-8 tabular-nums" style={{ color: "rgba(255,255,255,0.25)", fontFamily: "monospace" }}>
        {timeStr(duration, isLoadingDuration)}
      </span>
    </div>
  );
}
