"use client";

// ✅ FIX: Player state now resets when the logged-in user changes.
// ✅ FIX: Duration polling — iframe polled every 2s when duration=0, fixing "0:00 forever"
// ✅ FIX: audioSource field exposed so PlayerBar shows clear YouTube/iTunes badge

import {
  createContext, useContext, useState, useRef,
  useCallback, useEffect,
} from "react";
import type { RecommendedSong, RecommendationMode } from "@/types";
import { recommendApi, libraryApi } from "@/lib/api";

export interface QueueItem extends RecommendedSong {
  mode:    RecommendationMode;
  queueId: string;
}

interface PlayerState {
  currentSong:    QueueItem | null;
  queue:          QueueItem[];
  isPlaying:      boolean;
  progress:       number;
  duration:       number;
  volume:         number;
  youtubeVideoId: string | null;
  isLoadingYT:    boolean;
  showQueue:      boolean;
  likedSongs:     Set<number>;
  autoPlay:       boolean;
  isLoadingNext:  boolean;
  usingItunesFallback: boolean;
  audioSource: "youtube" | "itunes" | "loading" | "none";
}

interface PlayerActions {
  playSong:        (song: RecommendedSong, mode: RecommendationMode, queue?: RecommendedSong[]) => void;
  togglePlay:      () => void;
  next:            () => void;
  prev:            () => void;
  seek:            (pct: number) => void;
  setVolume:       (v: number) => void;
  toggleQueue:     () => void;
  reorderQueue:    (from: number, to: number) => void;
  removeFromQueue: (queueId: string) => void;
  addToQueue:      (song: RecommendedSong, mode: RecommendationMode) => void;
  toggleLike:      (songId: number) => void;
  isLiked:         (songId: number) => boolean;
  toggleAutoPlay:  () => void;
  resetPlayer:     () => void;
}

const PlayerContext = createContext<(PlayerState & PlayerActions) | null>(null);
const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
const YT_ORIGIN = "https://www.youtube.com";

export function PlayerProvider({ children }: { children: React.ReactNode }) {
  const [currentSong,    setCurrentSong]    = useState<QueueItem | null>(null);
  const [queue,          setQueue]          = useState<QueueItem[]>([]);
  const [isPlaying,      setIsPlaying]      = useState(false);
  const [progress,       setProgress]       = useState(0);
  const [duration,       setDuration]       = useState(0);
  const [volume,         setVolumeState]    = useState(0.8);
  const [youtubeVideoId, setYoutubeVideoId] = useState<string | null>(null);
  const [isLoadingYT,    setIsLoadingYT]    = useState(false);
  const [showQueue,      setShowQueue]      = useState(false);
  const [likedSongs,     setLikedSongs]     = useState<Set<number>>(new Set());
  const [autoPlay,       setAutoPlay]       = useState(true);
  const [isLoadingNext,  setIsLoadingNext]  = useState(false);
  const [itunesAudioSrc,      setItunesAudioSrc]      = useState<string | null>(null);
  const [usingItunesFallback, setUsingItunesFallback] = useState(false);

  const [authEpoch, setAuthEpoch] = useState(0);

  const iframeRef          = useRef<HTMLIFrameElement | null>(null);
  const itunesAudioRef     = useRef<HTMLAudioElement | null>(null);
  const tickerRef          = useRef<ReturnType<typeof setInterval> | null>(null);
  const durationPollRef    = useRef<ReturnType<typeof setInterval> | null>(null);
  const currentTimeRef     = useRef(0);
  const durationRef        = useRef(0);
  const isPlayingRef       = useRef(false);
  const queueRef           = useRef(queue);
  const autoplayedVideoRef = useRef<string | null>(null);
  const currentSongRef     = useRef<QueueItem | null>(null);
  const autoPlayRef        = useRef(autoPlay);
  const songEndedFiredRef  = useRef(false);
  const handleSongEndedRef = useRef<(() => void) | null>(null);
  const [history,  setHistory]  = useState<QueueItem[]>([]);
  const historyRef = useRef<QueueItem[]>([]);
  historyRef.current  = history;
  queueRef.current       = queue;
  currentSongRef.current = currentSong;
  autoPlayRef.current    = autoPlay;

  // Derive audioSource for UI badge
  const audioSource: "youtube" | "itunes" | "loading" | "none" = !currentSong
    ? "none"
    : isLoadingYT
      ? "loading"
      : usingItunesFallback
        ? "itunes"
        : youtubeVideoId
          ? "youtube"
          : "loading";

  // Listen for explicit auth lifecycle changes (login/logout/session refresh).
  useEffect(() => {
    const onAuthChanged = () => setAuthEpoch((x) => x + 1);
    window.addEventListener("auth-changed", onAuthChanged);
    return () => window.removeEventListener("auth-changed", onAuthChanged);
  }, []);

  // When user changes: clear all player state + reload liked songs
  useEffect(() => {
    setCurrentSong(null);
    setQueue([]);
    setIsPlaying(false);
    setProgress(0);
    setDuration(0);
    setYoutubeVideoId(null);
    setItunesAudioSrc(null);
    setUsingItunesFallback(false);
    setHistory([]);
    setLikedSongs(new Set());
    currentTimeRef.current    = 0;
    durationRef.current       = 0;
    songEndedFiredRef.current = false;
    autoplayedVideoRef.current = null;

    libraryApi
      .getLikedSongs()
      .then((r) => {
        const ids: number[] = r.data.songs.map((s: any) => s.song_id);
        setLikedSongs(new Set(ids));
      })
      .catch(() => {});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authEpoch]);

  const sendYTCommand = useCallback((func: string, args: unknown[] = []) => {
    iframeRef.current?.contentWindow?.postMessage(
      JSON.stringify({ event: "command", func, args }),
      YT_ORIGIN,
    );
  }, []);

  // Duration polling: when YT duration is still 0, keep asking the iframe
  const stopDurationPoll = useCallback(() => {
    if (durationPollRef.current) {
      clearInterval(durationPollRef.current);
      durationPollRef.current = null;
    }
  }, []);

  const startDurationPoll = useCallback(() => {
    stopDurationPoll();
    durationPollRef.current = setInterval(() => {
      if (durationRef.current > 0) {
        stopDurationPoll();
        return;
      }
      // Re-send "listening" to trigger infoDelivery from YT
      iframeRef.current?.contentWindow?.postMessage(
        JSON.stringify({ event: "listening", id: 1, channel: "widget" }),
        YT_ORIGIN,
      );
    }, 2000);
  }, [stopDurationPoll]);

  const fetchYouTubeIdInner = useCallback(async (
    songId: number,
    previewUrl?: string | null,
  ) => {
    setIsLoadingYT(true);
    setYoutubeVideoId(null);
    setItunesAudioSrc(null);
    setUsingItunesFallback(false);
    currentTimeRef.current    = 0;
    durationRef.current       = 0;
    songEndedFiredRef.current = false;
    setProgress(0);
    setDuration(0);
    autoplayedVideoRef.current = null;

    try {
      const res   = await fetch(`${API_BASE}/api/v1/youtube/${songId}`, { credentials: "include" });
      const data = await res.json();
      if (data.video_id) {
        setYoutubeVideoId(data.video_id);
        startDurationPoll();
      } else if (previewUrl) {
        setItunesAudioSrc(previewUrl);
        setUsingItunesFallback(true);
        setIsPlaying(true);
      }
    } catch {
      if (previewUrl) {
        setItunesAudioSrc(previewUrl);
        setUsingItunesFallback(true);
        setIsPlaying(true);
      }
    } finally {
      setIsLoadingYT(false);
    }
  }, [startDurationPoll]);

  const fetchAndQueueNext = useCallback(async () => {
    const current = currentSongRef.current;
    if (!current) return;
    setIsLoadingNext(true);
    try {
      const res = await recommendApi.get(current.mode, 10);
      const freshSongs: RecommendedSong[] = res.data.recommendations ?? [];
      const filtered = freshSongs.filter((s) => s.song_id !== current.song_id);
      if (filtered.length === 0) { setIsPlaying(false); return; }
      const [nextSong, ...rest] = filtered;
      const nextItem: QueueItem = { ...nextSong, mode: current.mode, queueId: `${nextSong.song_id}-${Date.now()}` };
      const restItems: QueueItem[] = rest.map((s, i) => ({ ...s, mode: current.mode, queueId: `${s.song_id}-${Date.now()}-${i}` }));
      setCurrentSong(nextItem);
      setQueue(restItems);
      setIsPlaying(true);
      currentTimeRef.current = 0; durationRef.current = 0; songEndedFiredRef.current = false;
      setProgress(0); setDuration(0); setYoutubeVideoId(null); setItunesAudioSrc(null);
      setTimeout(() => fetchYouTubeIdInner(nextItem.song_id, nextItem.preview_url), 200);
    } catch { setIsPlaying(false); }
    finally { setIsLoadingNext(false); }
  }, [fetchYouTubeIdInner]);

  useEffect(() => {
    handleSongEndedRef.current = () => {
      if (songEndedFiredRef.current) return;
      songEndedFiredRef.current = true;
      if (currentSongRef.current) setHistory((h) => [...h.slice(-19), currentSongRef.current!]);
      const q = queueRef.current;
      const finished = currentSongRef.current;
      const playedSeconds = Math.round(currentTimeRef.current || 0);
      if (finished && playedSeconds > 0) {
        recommendApi
          .logPlay({ song_id: finished.song_id, play_duration_s: playedSeconds, skipped: false })
          .catch(() => {});
      }

      if (q.length > 0) {
        const [nextSong, ...rest] = q;
        setQueue(rest); setCurrentSong(nextSong); setIsPlaying(true);
        currentTimeRef.current = 0; durationRef.current = 0; songEndedFiredRef.current = false;
        setProgress(0); setDuration(0); setYoutubeVideoId(null); setItunesAudioSrc(null);
        setTimeout(() => fetchYouTubeIdInner(nextSong.song_id, nextSong.preview_url), 200);
      } else if (autoPlayRef.current) {
        fetchAndQueueNext();
      } else {
        setIsPlaying(false);
      }
    };
  }, [fetchYouTubeIdInner, fetchAndQueueNext]);

  const stopTicker = useCallback(() => {
    if (tickerRef.current) { clearInterval(tickerRef.current); tickerRef.current = null; }
  }, []);

  const startTicker = useCallback(() => {
    if (tickerRef.current) return;
    tickerRef.current = setInterval(() => {
      if (!isPlayingRef.current || durationRef.current === 0) return;
      currentTimeRef.current = Math.min(currentTimeRef.current + 0.5, durationRef.current);
      setProgress((currentTimeRef.current / durationRef.current) * 100);
      if (durationRef.current > 0 && currentTimeRef.current >= durationRef.current - 1 && !songEndedFiredRef.current) {
        handleSongEndedRef.current?.();
      }
    }, 500);
  }, []);

  useEffect(() => { return () => { stopTicker(); stopDurationPoll(); }; }, [stopTicker, stopDurationPoll]);
  useEffect(() => {
    isPlayingRef.current = isPlaying;
    if (isPlaying) startTicker(); else stopTicker();
  }, [isPlaying, startTicker, stopTicker]);

  useEffect(() => {
    if (youtubeVideoId && isPlayingRef.current && autoplayedVideoRef.current !== youtubeVideoId) {
      autoplayedVideoRef.current = youtubeVideoId;
      [50, 150, 300, 500, 800].forEach((delay) => setTimeout(() => sendYTCommand("playVideo"), delay));
    }
  }, [youtubeVideoId, sendYTCommand]);

  const handleIframeLoad = useCallback(() => {
    iframeRef.current?.contentWindow?.postMessage(JSON.stringify({ event: "listening", id: 1, channel: "widget" }), YT_ORIGIN);
    sendYTCommand("setVolume", [Math.round(volume * 100)]);
    if (isPlayingRef.current) setTimeout(() => sendYTCommand("playVideo"), 50);
    startDurationPoll();
  }, [sendYTCommand, volume, startDurationPoll]);

  useEffect(() => {
    const handler = (e: MessageEvent) => {
      if (e.origin !== YT_ORIGIN) return;
      let data: any;
      try { data = JSON.parse(e.data); } catch { return; }
      if (data.event === "infoDelivery" && data.info) {
        if (data.info.currentTime != null) currentTimeRef.current = data.info.currentTime;
        if (data.info.duration != null && data.info.duration > 0) {
          durationRef.current = data.info.duration;
          setDuration(data.info.duration);
          stopDurationPoll();
        }
        if (durationRef.current > 0) setProgress((currentTimeRef.current / durationRef.current) * 100);
      }
      if (data.event === "onStateChange") {
        if (data.info === 1) { setIsPlaying(true); startDurationPoll(); }
        if (data.info === 2) setIsPlaying(false);
        if (data.info === 0) handleSongEndedRef.current?.();
        if (data.info === 5 || data.info === -1) {
          const preview = currentSongRef.current?.preview_url;
          if (preview) {
            stopDurationPoll();
            setYoutubeVideoId(null); setItunesAudioSrc(preview);
            setUsingItunesFallback(true); setIsPlaying(true);
          }
        }
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, [startDurationPoll, stopDurationPoll]);

  const playSong = useCallback(
    (song: RecommendedSong, mode: RecommendationMode, newQueue?: RecommendedSong[]) => {
      if (currentSongRef.current) setHistory((h) => [...h.slice(-19), currentSongRef.current!]);
      const item: QueueItem = { ...song, mode, queueId: `${song.song_id}-${Date.now()}` };
      setCurrentSong(item); setIsPlaying(true);
      currentTimeRef.current = 0; durationRef.current = 0; songEndedFiredRef.current = false;
      setProgress(0); setDuration(0); autoplayedVideoRef.current = null;
      setItunesAudioSrc(null); setUsingItunesFallback(false);
      stopDurationPoll();
      if (newQueue) {
        const rest = newQueue.filter((s) => s.song_id !== song.song_id).map((s, i) => ({ ...s, mode, queueId: `${s.song_id}-${Date.now()}-${i}` }));
        setQueue(rest);
      }
      fetchYouTubeIdInner(song.song_id, song.preview_url);
    },
    [fetchYouTubeIdInner, stopDurationPoll],
  );

  const togglePlay = useCallback(() => {
    setIsPlaying((p) => {
      if (usingItunesFallback && itunesAudioRef.current) {
        if (p) itunesAudioRef.current.pause(); else itunesAudioRef.current.play().catch(() => {});
      } else {
        if (p) sendYTCommand("pauseVideo"); else sendYTCommand("playVideo");
      }
      return !p;
    });
  }, [sendYTCommand, usingItunesFallback]);

  const next = useCallback(() => { songEndedFiredRef.current = false; handleSongEndedRef.current?.(); }, []);

  const prev = useCallback(() => {
    const h = historyRef.current;
    if (h.length === 0) {
      if (usingItunesFallback && itunesAudioRef.current) itunesAudioRef.current.currentTime = 0;
      else sendYTCommand("seekTo", [0, true]);
      currentTimeRef.current = 0; songEndedFiredRef.current = false; setProgress(0); return;
    }
    const prevSong = h[h.length - 1];
    setHistory((h) => h.slice(0, -1));
    if (currentSongRef.current) setQueue((q) => [currentSongRef.current!, ...q]);
    setCurrentSong(prevSong); setIsPlaying(true);
    currentTimeRef.current = 0; durationRef.current = 0; songEndedFiredRef.current = false;
    setProgress(0); setDuration(0); setYoutubeVideoId(null); setItunesAudioSrc(null); setUsingItunesFallback(false);
    stopDurationPoll();
    setTimeout(() => fetchYouTubeIdInner(prevSong.song_id, prevSong.preview_url), 200);
  }, [sendYTCommand, fetchYouTubeIdInner, usingItunesFallback, stopDurationPoll]);

  const seek = useCallback((pct: number) => {
    if (durationRef.current > 0) {
      const secs = (pct / 100) * durationRef.current;
      if (usingItunesFallback && itunesAudioRef.current) itunesAudioRef.current.currentTime = secs;
      else sendYTCommand("seekTo", [secs, true]);
      currentTimeRef.current = secs;
      if (pct < 98) songEndedFiredRef.current = false;
    }
    setProgress(pct);
  }, [sendYTCommand, usingItunesFallback]);

  const setVolume = useCallback((v: number) => {
    setVolumeState(v);
    if (itunesAudioRef.current) itunesAudioRef.current.volume = v;
    sendYTCommand("setVolume", [Math.round(v * 100)]);
    if (v === 0) sendYTCommand("mute"); else sendYTCommand("unMute");
  }, [sendYTCommand]);

  const toggleQueue    = useCallback(() => setShowQueue((s) => !s), []);
  const toggleAutoPlay = useCallback(() => setAutoPlay((a) => !a), []);

  const reorderQueue = useCallback((from: number, to: number) => {
    setQueue((q) => { const next = [...q]; const [item] = next.splice(from, 1); next.splice(to, 0, item); return next; });
  }, []);

  const removeFromQueue = useCallback((queueId: string) => setQueue((q) => q.filter((s) => s.queueId !== queueId)), []);
  const addToQueue = useCallback((song: RecommendedSong, mode: RecommendationMode) => {
    setQueue((q) => [...q, { ...song, mode, queueId: `${song.song_id}-${Date.now()}` }]);
  }, []);

  const toggleLike = useCallback((songId: number) => {
    setLikedSongs((prev) => {
      const next = new Set(prev);
      const liked = !next.has(songId);
      if (liked) next.add(songId); else next.delete(songId);
      recommendApi.toggleLike(songId, liked).catch(() => {});
      return next;
    });
  }, []);

  const isLiked = useCallback((songId: number) => likedSongs.has(songId), [likedSongs]);

  const resetPlayer = useCallback(() => {
    setCurrentSong(null); setQueue([]); setIsPlaying(false); setProgress(0); setDuration(0);
    setYoutubeVideoId(null); setItunesAudioSrc(null); setUsingItunesFallback(false);
    setHistory([]); setLikedSongs(new Set());
    currentTimeRef.current = 0; durationRef.current = 0;
    songEndedFiredRef.current = false; autoplayedVideoRef.current = null;
    stopTicker(); stopDurationPoll();
  }, [stopTicker, stopDurationPoll]);

  return (
    <PlayerContext.Provider
      value={{
        currentSong, queue, isPlaying, progress, duration, volume,
        youtubeVideoId, isLoadingYT, showQueue, likedSongs,
        autoPlay, isLoadingNext, usingItunesFallback, audioSource,
        playSong, togglePlay, next, prev, seek, setVolume,
        toggleQueue, reorderQueue, removeFromQueue, addToQueue,
        toggleLike, isLiked, toggleAutoPlay, resetPlayer,
      }}
    >
      {children}
      {youtubeVideoId && !usingItunesFallback && (
        <iframe
          ref={iframeRef}
          src={`https://www.youtube.com/embed/${youtubeVideoId}?autoplay=1&enablejsapi=1&origin=${typeof window !== "undefined" ? window.location.origin : ""}`}
          allow="autoplay"
          title="audio"
          onLoad={handleIframeLoad}
          style={{ position: "fixed", width: 1, height: 1, opacity: 0, pointerEvents: "none", bottom: 0, left: 0 }}
        />
      )}
      {itunesAudioSrc && (
        <audio
          ref={itunesAudioRef}
          src={itunesAudioSrc}
          autoPlay
          onEnded={() => handleSongEndedRef.current?.()}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onTimeUpdate={(e) => {
            const el = e.currentTarget;
            currentTimeRef.current = el.currentTime;
            if (el.duration && el.duration > 0) {
              durationRef.current = el.duration;
              setDuration(el.duration);
              setProgress((el.currentTime / el.duration) * 100);
            }
          }}
          style={{ display: "none" }}
        />
      )}
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const ctx = useContext(PlayerContext);
  if (!ctx) throw new Error("usePlayer must be used within PlayerProvider");
  return ctx;
}
