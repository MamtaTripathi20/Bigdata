"use client";
import { useEffect, useState } from "react";
import { X, ExternalLink, Loader2, Music } from "lucide-react";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface YouTubeModalProps {
  songId: number;
  title: string;
  artist: string;
  coverUrl?: string;
  previewUrl?: string;
  onClose: () => void;
}

export function YouTubeModal({
  songId,
  title,
  artist,
  coverUrl,
  previewUrl,
  onClose,
}: YouTubeModalProps) {
  const [videoId, setVideoId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(`${title} ${artist}`)}`;

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  useEffect(() => {
    setLoading(true);
    setError(false);

    fetch(`${API_BASE}/api/v1/youtube/${songId}`, { credentials: "include" })
      .then((r) => r.json())
      .then((data) => {
        if (data.video_id) {
          setVideoId(data.video_id);
        } else {
          setError(true);
        }
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [songId]);

  useEffect(() => {
    const closeBtn = document.querySelector<HTMLButtonElement>('[data-modal-close="youtube"]');
    closeBtn?.focus();

    const onTrap = (e: KeyboardEvent) => {
      if (e.key !== "Tab") return;
      const modal = document.getElementById("youtube-modal");
      if (!modal) return;
      const focusables = modal.querySelectorAll<HTMLElement>(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];

      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", onTrap);
    return () => document.removeEventListener("keydown", onTrap);
  }, []);

  return (
    <div
      id="youtube-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)" }}
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="youtube-modal-title"
    >
      <div
        className="w-full max-w-2xl rounded-2xl overflow-hidden"
        style={{ background: "#111", border: "1px solid rgba(255,255,255,0.1)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 p-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          {coverUrl && (
            <img src={coverUrl} alt={title} className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
              onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          )}
          <div className="flex-1 min-w-0">
            <p id="youtube-modal-title" className="font-semibold truncate text-white">{title}</p>
            <p className="text-sm truncate" style={{ color: "rgba(255,255,255,0.5)" }}>{artist}</p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <a href={searchUrl} target="_blank" rel="noopener noreferrer"
              className="p-2 rounded-lg" style={{ color: "rgba(255,255,255,0.4)" }} aria-label="Open YouTube search">
              <ExternalLink className="w-4 h-4" />
            </a>
            <button data-modal-close="youtube" onClick={onClose} className="p-2 rounded-lg" style={{ color: "rgba(255,255,255,0.4)" }} aria-label="Close">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div style={{ position: "relative", paddingBottom: "56.25%", height: 0, background: "#000" }}>
          {loading && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
              <Loader2 className="w-8 h-8 text-white/40 animate-spin" />
              <p className="text-sm text-white/40">Finding on YouTube...</p>
            </div>
          )}
          {!loading && error && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 p-6">
              <Music className="w-10 h-10 text-white/20" />
              <p className="text-sm text-white/40 text-center">Could not find this song on YouTube</p>
              <a href={searchUrl} target="_blank" rel="noopener noreferrer"
                className="text-sm text-red-500/70 hover:text-red-500 flex items-center gap-1">
                Search manually on YouTube <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}
          {!loading && videoId && (
            <iframe
              src={`https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`}
              title={`${title} - ${artist}`}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: "none" }}
            />
          )}
        </div>

        <div className="px-4 py-3 flex items-center justify-between" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
          <p className="text-xs" style={{ color: "rgba(255,255,255,0.25)" }}>
            {videoId ? "Playing via YouTube • Click outside to close" : "Click outside to close"}
          </p>
          <a href={searchUrl} target="_blank" rel="noopener noreferrer"
            className="text-xs flex items-center gap-1" style={{ color: "rgba(255,100,100,0.7)" }}>
            Open YouTube <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
}
