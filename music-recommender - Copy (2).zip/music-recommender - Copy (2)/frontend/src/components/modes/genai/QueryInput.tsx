"use client";

import { useState, useCallback } from "react";
import { Search, Sparkles, X } from "lucide-react";
import { RecommendationMode } from "@/types";

interface QueryInputProps {
  value:    string;
  onChange: (v: string) => void;
  onSearch: () => void;
  mode:     RecommendationMode;
}

const VIBE_SUGGESTIONS = [
  { label: "Late night drive 🌙",  query: "late night drive" },
  { label: "Morning energy ☀️",   query: "morning energy wake up" },
  { label: "Deep focus 🎯",        query: "deep focus study" },
  { label: "Sad & healing 💙",     query: "sad healing heartbreak" },
  { label: "Party mode 🎉",        query: "party dance turn up" },
  { label: "Chill Sunday 🛋️",     query: "chill relax Sunday" },
  { label: "Gym beast 💪",         query: "workout gym energy" },
  { label: "Heartbreak 💔",        query: "heartbreak sad love" },
  { label: "Confident 👑",         query: "confident powerful" },
  { label: "Rainy day ☔",         query: "rainy day melancholy" },
  { label: "Bollywood 🎬",         query: "bollywood hindi" },
  { label: "Classic rock 🎸",      query: "classic rock guitar" },
  { label: "Smooth jazz 🎷",       query: "smooth jazz chill" },
  { label: "Summer beach 🏖️",     query: "summer beach tropical" },
  { label: "Lo-fi study 📚",       query: "lo-fi study beats" },
];

const MODE_ACCENT: Record<RecommendationMode, { color: string; glow: string }> = {
  analytics: { color: "var(--analytics)", glow: "rgba(79,142,247,0.2)" },
  genai:     { color: "var(--genai)",     glow: "rgba(192,132,252,0.2)" },
  hybrid:    { color: "var(--hybrid)",    glow: "rgba(45,212,191,0.2)" },
};

export function QueryInput({ value, onChange, onSearch, mode }: QueryInputProps) {
  const [focused, setFocused] = useState(false);
  const accent = MODE_ACCENT[mode];

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") onSearch();
  };

  const applyVibe = useCallback(
    (query: string) => { onChange(query); },
    [onChange]
  );

  return (
    <div className="space-y-3">
      {/* Search box */}
      <div
        className="relative flex items-center rounded-xl overflow-hidden transition-all duration-200"
        style={{
          background:  "rgba(255,255,255,0.04)",
          border:      `1px solid ${focused ? accent.color + "55" : "rgba(255,255,255,0.08)"}`,
          boxShadow:   focused ? `0 0 0 3px ${accent.glow}` : "none",
        }}
      >
        <Search
          className="absolute left-3.5 w-4 h-4 flex-shrink-0 pointer-events-none"
          style={{ color: focused ? accent.color : "rgba(255,255,255,0.25)" }}
        />

        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKey}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder='Describe a mood… "late night sad drive" or "happy morning run"'
          className="flex-1 bg-transparent pl-10 pr-16 py-3.5 text-sm text-white outline-none"
          style={{ color: "var(--text)", caretColor: accent.color }}
        />
        <style jsx>{`input::placeholder { color: rgba(255,255,255,0.2); }`}</style>

        <div className="absolute right-2 flex items-center gap-1">
          {value && (
            <button
              onClick={() => onChange("")}
              className="p-1.5 rounded-lg transition-colors"
              style={{ color: "rgba(255,255,255,0.2)" }}
              title="Clear"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={onSearch}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
            style={{
              background: value
                ? `linear-gradient(135deg, ${accent.color}, ${accent.color}aa)`
                : "rgba(255,255,255,0.07)",
              color: value ? "white" : "rgba(255,255,255,0.35)",
              boxShadow: value ? `0 0 12px ${accent.glow}` : "none",
            }}
          >
            <Sparkles className="w-3 h-3" />
            Search
          </button>
        </div>
      </div>

      {/* Vibe chip grid */}
      <div className="flex flex-wrap gap-2">
        {VIBE_SUGGESTIONS.map((vibe) => {
          const isActive = value === vibe.query;
          return (
            <button
              key={vibe.query}
              onClick={() => applyVibe(vibe.query)}
              className="px-2.5 py-1 rounded-full text-xs transition-all duration-150"
              style={{
                background:  isActive ? `${accent.color}22` : "rgba(255,255,255,0.05)",
                border:      `1px solid ${isActive ? accent.color + "44" : "rgba(255,255,255,0.07)"}`,
                color:       isActive ? accent.color : "rgba(255,255,255,0.4)",
              }}
            >
              {vibe.label}
            </button>
          );
        })}
      </div>

      {/* Context hint */}
      {!value && (
        <p className="text-xs px-0.5" style={{ color: "rgba(255,255,255,0.22)" }}>
          {mode === "genai"
            ? "💡 Describe how you feel or what you're doing — the AI translates your vibe into music"
            : "💡 Hybrid blends your listening history with a vibe search for the best of both worlds"}
        </p>
      )}
    </div>
  );
}
