"use client";

import { RecommendationMode, MODE_META } from "@/types";
import { clsx } from "clsx";

interface ModeSelectorProps {
  current:  RecommendationMode;
  onChange: (mode: RecommendationMode) => void;
}

const MODES: RecommendationMode[] = ["analytics", "genai", "hybrid"];
const SHORTCUTS: Record<RecommendationMode, string> = {
  analytics: "1",
  genai:     "2",
  hybrid:    "3",
};

const MODE_COLORS: Record<RecommendationMode, { glow: string; text: string; bg: string; border: string }> = {
  analytics: {
    glow:   "0 0 20px rgba(79, 142, 247, 0.35)",
    text:   "var(--analytics)",
    bg:     "rgba(79, 142, 247, 0.12)",
    border: "rgba(79, 142, 247, 0.3)",
  },
  genai: {
    glow:   "0 0 20px rgba(192, 132, 252, 0.35)",
    text:   "var(--genai)",
    bg:     "rgba(192, 132, 252, 0.12)",
    border: "rgba(192, 132, 252, 0.3)",
  },
  hybrid: {
    glow:   "0 0 20px rgba(45, 212, 191, 0.35)",
    text:   "var(--hybrid)",
    bg:     "rgba(45, 212, 191, 0.12)",
    border: "rgba(45, 212, 191, 0.3)",
  },
};

export function ModeSelector({ current, onChange }: ModeSelectorProps) {
  return (
    <div
      className="p-1.5 rounded-2xl"
      style={{
        background: "rgba(255,255,255,0.03)",
        border:     "1px solid rgba(255,255,255,0.07)",
      }}
    >
      <div className="grid grid-cols-3 gap-1.5">
        {MODES.map((mode) => {
          const meta   = MODE_META[mode];
          const mc     = MODE_COLORS[mode];
          const active = current === mode;

          return (
            <button
              key={mode}
              onClick={() => onChange(mode)}
              aria-pressed={active}
              aria-label={`${meta.label} mode`}
              className="relative rounded-xl px-4 py-4 text-left transition-all duration-200 focus-ring"
              style={{
                background:  active ? mc.bg : "transparent",
                border:      `1px solid ${active ? mc.border : "transparent"}`,
                boxShadow:   active ? mc.glow : "none",
              }}
            >
              {/* Icon + label row */}
              <div className="flex items-center gap-2.5 mb-2">
                <span className="text-lg leading-none">{meta.icon}</span>
                <span
                  className="text-sm font-display font-bold leading-none transition-colors"
                  style={{ color: active ? mc.text : "rgba(255,255,255,0.5)" }}
                >
                  {meta.label}
                </span>
                <kbd
                  className="ml-auto text-xs hidden sm:flex items-center justify-center w-4 h-4 rounded"
                  style={{
                    background: "rgba(255,255,255,0.06)",
                    color:      active ? "rgba(255,255,255,0.4)" : "rgba(255,255,255,0.18)",
                    border:     "1px solid rgba(255,255,255,0.06)",
                    fontFamily: "monospace",
                  }}
                >
                  {SHORTCUTS[mode]}
                </kbd>
              </div>

              {/* Description */}
              <p
                className="text-xs leading-relaxed hidden sm:block"
                style={{ color: active ? "rgba(255,255,255,0.42)" : "rgba(255,255,255,0.22)" }}
              >
                {meta.description}
              </p>

              {/* Latency indicator */}
              <div className="mt-2.5 flex items-center gap-1.5">
                <div
                  className="w-1.5 h-1.5 rounded-full transition-all"
                  style={{ background: active ? mc.text : "rgba(255,255,255,0.15)" }}
                />
                <span
                  className="text-xs"
                  style={{
                    color:      active ? "rgba(255,255,255,0.4)" : "rgba(255,255,255,0.2)",
                    fontFamily: "monospace",
                  }}
                >
                  {meta.latency}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
