"use client";

import {
  RecommendedSong,
  RecommendationMode,
  RecommendationResponse,
  MODE_META,
} from "@/types";
import { SongCard } from "./SongCard";
import { Loader2, Music2, AlertTriangle, RefreshCw } from "lucide-react";

interface RecommendationFeedProps {
  mode:             RecommendationMode;
  data?:            RecommendationResponse;
  isLoading:        boolean;
  error?:           unknown;
  onPlay:           (song: RecommendedSong) => void;
  onInfoClick?:     (song: RecommendedSong) => void;
  onAddToPlaylist?: (song: RecommendedSong) => void;
}

const LOADING_MESSAGES: Record<RecommendationMode, string> = {
  analytics: "Running Fuzzy C-Means & collaborative filtering…",
  genai:     "Searching via sentence transformer embeddings…",
  hybrid:    "Fusing Analytics + GenAI pipelines in parallel…",
};

const MODE_ACCENT: Record<RecommendationMode, string> = {
  analytics: "var(--analytics)",
  genai:     "var(--genai)",
  hybrid:    "var(--hybrid)",
};

function SongSkeleton({ delay = 0 }: { delay?: number }) {
  return (
    <div
      className="flex items-center gap-3 px-3 py-2.5 rounded-xl"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="skeleton w-5 h-3 rounded" />
      <div className="skeleton w-10 h-10 rounded-lg flex-shrink-0" />
      <div className="flex-1 space-y-2 min-w-0">
        <div className="skeleton h-3 rounded w-3/5" />
        <div className="skeleton h-2.5 rounded w-2/5" />
      </div>
      <div className="hidden sm:block skeleton h-2.5 rounded w-10" />
    </div>
  );
}

export function RecommendationFeed({
  mode,
  data,
  isLoading,
  error,
  onPlay,
  onInfoClick,
  onAddToPlaylist,
}: RecommendationFeedProps) {
  const meta   = MODE_META[mode];
  const accent = MODE_ACCENT[mode];

  if (isLoading) {
    return (
      <div
        className="rounded-2xl overflow-hidden"
        style={{
          background: "rgba(255,255,255,0.02)",
          border:     "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <div
          className="flex items-center gap-3 px-4 py-3.5"
          style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}
        >
          <Loader2
            className="w-4 h-4 animate-spin"
            style={{ color: accent }}
          />
          <span className="text-sm" style={{ color: "rgba(255,255,255,0.4)" }}>
            {LOADING_MESSAGES[mode]}
          </span>
          <span
            className="ml-auto text-xs font-display font-bold"
            style={{ color: accent }}
          >
            {meta.icon} {meta.label}
          </span>
        </div>
        <div className="py-2 px-1.5 space-y-0.5">
          {Array.from({ length: 8 }).map((_, i) => (
            <SongSkeleton key={i} delay={i * 50} />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div
        className="rounded-2xl p-6"
        style={{
          background:  "rgba(239,68,68,0.05)",
          border:      "1px solid rgba(239,68,68,0.15)",
        }}
      >
        <div className="flex items-start gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: "rgba(239,68,68,0.12)" }}
          >
            <AlertTriangle className="w-4 h-4 text-red-400" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-display font-bold text-red-400">Failed to load recommendations</p>
            <p className="text-xs mt-1 leading-relaxed" style={{ color: "rgba(255,255,255,0.4)" }}>
              {mode === "genai" || mode === "hybrid"
                ? "Ensure the backend is running and the sentence transformer model has loaded."
                : "Check that the FastAPI backend is accessible."}
            </p>
            <div className="flex items-center gap-1.5 mt-3 text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>
              <RefreshCw className="w-3 h-3" />
              Try switching modes or refreshing the page
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!data?.recommendations?.length) {
    return (
      <div
        className="rounded-2xl p-12 text-center"
        style={{
          background: "rgba(255,255,255,0.02)",
          border:     "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <div
          className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4"
          style={{ background: "rgba(255,255,255,0.04)" }}
        >
          <Music2 className="w-7 h-7" style={{ color: "rgba(255,255,255,0.15)" }} />
        </div>
        <p className="font-display font-bold text-sm" style={{ color: "rgba(255,255,255,0.45)" }}>
          No recommendations yet
        </p>
        <p className="text-xs mt-2 max-w-xs mx-auto leading-relaxed" style={{ color: "rgba(255,255,255,0.25)" }}>
          {mode === "analytics"
            ? "Play some tracks so the ML model can learn your taste."
            : mode === "genai"
            ? "Type a mood or vibe in the search box above."
            : "Use a vibe search — Hybrid works best with some listening history."}
        </p>
      </div>
    );
  }

  const { recommendations } = data;

  return (
    <div
      className="rounded-2xl overflow-hidden"
      style={{
        background: "rgba(255,255,255,0.02)",
        border:     "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-4 py-3.5"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}
      >
        <div className="flex items-center gap-2.5">
          <span className="font-display font-bold text-sm" style={{ color: accent }}>
            {meta.icon} {meta.label}
          </span>
          <span
            className="text-xs px-2 py-0.5 rounded-full"
            style={{ background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.35)" }}
          >
            {data.count}
          </span>
        </div>

        <div className="flex items-center gap-3 text-xs">
          {data.fallback_used && (
            <span
              className="flex items-center gap-1 px-2 py-0.5 rounded-full"
              style={{ background: "rgba(234,179,8,0.1)", color: "rgba(234,179,8,0.7)" }}
            >
              ⚠ {data.fallback_used}
            </span>
          )}
          <span
            style={{ color: "rgba(255,255,255,0.22)", fontFamily: "monospace" }}
          >
            {data.latency_ms}ms
          </span>
        </div>
      </div>

      {/* Song list */}
      <div className="py-2 px-1.5 space-y-0.5">
        {recommendations.map((song, idx) => (
          <div
            key={song.song_id}
            className="fade-in-up"
            style={{ animationDelay: `${idx * 30}ms` }}
          >
            <SongCard
              song={song}
              rank={idx + 1}
              mode={mode}
              allSongs={recommendations}
              onPlay={() => onPlay(song)}
              onInfoClick={onInfoClick}
              onAddToPlaylist={onAddToPlaylist}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
