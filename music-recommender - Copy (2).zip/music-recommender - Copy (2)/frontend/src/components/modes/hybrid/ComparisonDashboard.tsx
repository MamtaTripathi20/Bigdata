"use client";

// ✅ FIX: Hybrid mode now clearly explains what it does with a visual breakdown.
//         Each song shows both its Analytics score and GenAI score as dual progress bars
//         so users understand exactly HOW hybrid picks songs differently.
// ✅ FIX: Added a plain-language "Why Hybrid?" explanation section.
// ✅ FIX: Latency bars show "–" while loading.

import { useAllModes } from "@/lib/hooks/useRecommendations";
import { MODE_META, RecommendationMode } from "@/types";
import { clsx } from "clsx";
import { Loader2, Zap, Brain, BarChart3, Info } from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, Cell,
} from "recharts";

interface ComparisonDashboardProps {
  queryText?: string;
}

const MODES: RecommendationMode[] = ["analytics", "genai", "hybrid"];
const MODE_COLORS: Record<RecommendationMode, string> = {
  analytics: "#3b82f6",
  genai:     "#a855f7",
  hybrid:    "#10b981",
};

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="text-xs px-2.5 py-2 rounded-lg" style={{ background: "#1c1c28", border: "1px solid rgba(255,255,255,0.1)" }}>
      <p className="font-medium text-white">{label}</p>
      <p style={{ color: "rgba(255,255,255,0.5)" }}>{payload[0].value}ms</p>
    </div>
  );
}

export function ComparisonDashboard({ queryText }: ComparisonDashboardProps) {
  const { analytics, genai, hybrid } = useAllModes(queryText);

  const latencyData = [
    { name: "Analytics", ms: analytics.data?.latency_ms ?? 0, mode: "analytics" as const },
    { name: "GenAI",     ms: genai.data?.latency_ms ?? 0,     mode: "genai"     as const },
    { name: "Hybrid",    ms: hybrid.data?.latency_ms ?? 0,    mode: "hybrid"    as const },
  ];

  const modes = { analytics, genai, hybrid };

  return (
    <div className="space-y-4 fade-in-up">
      <div className="flex items-center justify-between px-1">
        <h2 className="text-sm font-semibold text-white/60">Mode Comparison</h2>
        <span className="text-xs text-white/25">All 3 pipelines running in parallel</span>
      </div>

      {/* ✅ FIX: "Why Hybrid?" explainer — plain language */}
      <div
        className="glass-card p-4 space-y-3"
        style={{ borderColor: "rgba(16,185,129,0.2)" }}
      >
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-hybrid-400 flex-shrink-0" />
          <p className="text-xs font-semibold text-hybrid-400">Why use Hybrid mode?</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs text-white/50">
          <div className="flex items-start gap-2">
            <BarChart3 className="w-3.5 h-3.5 text-analytics-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="text-analytics-400 font-medium">Analytics</span> learns your taste
              from play history — great once you've listened to a few songs.
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Brain className="w-3.5 h-3.5 text-genai-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="text-genai-400 font-medium">GenAI</span> understands language + context —
              finds songs matching the mood you type, great for new users.
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Zap className="w-3.5 h-3.5 text-hybrid-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="text-hybrid-400 font-medium">Hybrid</span> blends both scores:
              <code className="mx-1 text-white/30 text-[10px]">α·Analytics + β·GenAI</code>
              — best of both worlds, always.
            </div>
          </div>
        </div>
      </div>

      {/* Latency chart */}
      <div className="glass-card p-4">
        <p className="text-xs font-semibold text-white/28 mb-3 tracking-wide">RESPONSE LATENCY (ms)</p>
        <ResponsiveContainer width="100%" height={90}>
          <BarChart data={latencyData} barSize={28} margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: "rgba(255,255,255,0.4)", fontFamily: "DM Sans" }} axisLine={false} tickLine={false} />
            <YAxis hide />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
            <Bar dataKey="ms" radius={[4, 4, 0, 0]}>
              {latencyData.map((entry) => (
                <Cell key={entry.mode} fill={MODE_COLORS[entry.mode]} fillOpacity={0.85} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Side-by-side top results */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {MODES.map((mode) => {
          const q    = modes[mode];
          const meta = MODE_META[mode];

          return (
            <div key={mode} className="glass-card p-3">
              <div className="flex items-center gap-1.5 mb-2.5 pb-2" style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                <span className={clsx("text-xs font-semibold", meta.color)}>
                  {meta.icon} {meta.label}
                </span>
                {q.data ? (
                  <span className="ml-auto text-xs font-mono text-white/28">{q.data.latency_ms}ms</span>
                ) : (
                  <span className="ml-auto text-xs font-mono text-white/15">–ms</span>
                )}
              </div>

              {q.isLoading && (
                <div className="flex flex-col gap-2 py-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="flex gap-2 items-center">
                      <div className="skeleton flex-1 h-2.5 rounded" />
                      <div className="skeleton w-8 h-1.5 rounded-full" />
                    </div>
                  ))}
                </div>
              )}

              {q.error && !q.isLoading && (
                <p className="text-xs text-red-400/60 py-2">Failed to load</p>
              )}

              {q.data?.recommendations.slice(0, 5).map((song) => (
                <div key={song.song_id} className="py-1.5" style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                  <p className="text-xs font-medium truncate text-white/80">{song.title}</p>
                  <p className="text-xs text-white/30 truncate">{song.artist}</p>

                  {/* ✅ FIX: Hybrid shows BOTH analytics + genai scores as dual bars */}
                  {mode === "hybrid" && song.analytics_score !== undefined && song.genai_score !== undefined ? (
                    <div className="mt-1 space-y-0.5">
                      <div className="flex items-center gap-1">
                        <span className="text-[9px] text-analytics-400 w-12 flex-shrink-0">Analytics</span>
                        <div className="flex-1 h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
                          <div className="h-full rounded-full" style={{ width: `${song.analytics_score * 100}%`, background: MODE_COLORS.analytics, opacity: 0.7 }} />
                        </div>
                        <span className="text-[9px] font-mono text-white/20 w-6 text-right">{(song.analytics_score * 100).toFixed(0)}%</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-[9px] text-genai-400 w-12 flex-shrink-0">GenAI</span>
                        <div className="flex-1 h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
                          <div className="h-full rounded-full" style={{ width: `${song.genai_score * 100}%`, background: MODE_COLORS.genai, opacity: 0.7 }} />
                        </div>
                        <span className="text-[9px] font-mono text-white/20 w-6 text-right">{(song.genai_score * 100).toFixed(0)}%</span>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 mt-1">
                      <div className="flex-1 h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
                        <div className="h-full rounded-full" style={{ width: `${song.score * 100}%`, background: MODE_COLORS[mode], opacity: 0.75 }} />
                      </div>
                      <span className="text-xs font-mono text-white/22 flex-shrink-0">{(song.score * 100).toFixed(0)}%</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}
