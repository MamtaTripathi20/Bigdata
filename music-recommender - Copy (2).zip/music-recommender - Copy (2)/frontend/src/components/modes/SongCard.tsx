"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Play, Heart, Music, Youtube, Plus, MoreHorizontal, ListPlus, Info, Pause } from "lucide-react";
import { clsx } from "clsx";
import type { RecommendedSong, RecommendationMode } from "@/types";
import { usePlayer } from "@/components/ui/PlayerContext";

interface SongCardProps {
  song:             RecommendedSong;
  rank:             number;
  mode:             RecommendationMode;
  allSongs?:        RecommendedSong[];
  onPlay?:          () => void;
  onInfoClick?:     (song: RecommendedSong) => void;
  onAddToPlaylist?: (song: RecommendedSong) => void;
}

const COVER_GRADIENTS = [
  ["#4f8ef7", "#c084fc"],
  ["#c084fc", "#2dd4bf"],
  ["#2dd4bf", "#4f8ef7"],
  ["#f59e0b", "#ef4444"],
  ["#ec4899", "#8b5cf6"],
  ["#06b6d4", "#3b82f6"],
];

const MODE_ACCENT: Record<RecommendationMode, string> = {
  analytics: "var(--analytics)",
  genai:     "var(--genai)",
  hybrid:    "var(--hybrid)",
};

export function SongCard({
  song,
  rank,
  mode,
  allSongs,
  onPlay,
  onInfoClick,
  onAddToPlaylist,
}: SongCardProps) {
  const router = useRouter();
  const { playSong, addToQueue, toggleLike, isLiked, currentSong, isPlaying } = usePlayer();
  const [showMenu,     setShowMenu]     = useState(false);
  const [addedToQueue, setAddedToQueue] = useState(false);
  const [imgError,     setImgError]     = useState(false);

  const isCurrentSong = currentSong?.song_id === song.song_id;
  const liked         = isLiked(song.song_id);
  const showTagline   = (mode === "genai" || mode === "hybrid") && song.explanation;
  const gradColors    = COVER_GRADIENTS[song.song_id % COVER_GRADIENTS.length];
  const accent        = MODE_ACCENT[mode];

  const handlePlay = () => {
    playSong(song, mode, allSongs);
    onPlay?.();
  };

  const handleAddToQueue = () => {
    addToQueue(song, mode);
    setAddedToQueue(true);
    setTimeout(() => setAddedToQueue(false), 2000);
    setShowMenu(false);
  };

  const handleArtistClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (song.artist_id) router.push(`/artists/${song.artist_id}`);
  };

  return (
    <div
      className={clsx(
        "group relative flex flex-col px-3 py-2 rounded-xl transition-all duration-150"
      )}
      style={{
        background:  isCurrentSong ? "rgba(255,255,255,0.06)" : "transparent",
        border:      `1px solid ${isCurrentSong ? "rgba(255,255,255,0.09)" : "transparent"}`,
      }}
      onMouseEnter={(e) => {
        if (!isCurrentSong) {
          e.currentTarget.style.background = "rgba(255,255,255,0.04)";
          e.currentTarget.style.border = "1px solid rgba(255,255,255,0.06)";
        }
      }}
      onMouseLeave={(e) => {
        if (!isCurrentSong) {
          e.currentTarget.style.background = "transparent";
          e.currentTarget.style.border = "1px solid transparent";
        }
      }}
    >
      <div className="flex items-center gap-3">

        {/* Rank / Playing indicator */}
        <div className="w-6 flex-shrink-0 flex items-center justify-center">
          {isCurrentSong && isPlaying ? (
            <div className="flex gap-px items-end h-3.5 justify-center">
              <div className="w-0.5 rounded-full eq-bar-1" style={{ background: accent }} />
              <div className="w-0.5 rounded-full eq-bar-2" style={{ background: accent }} />
              <div className="w-0.5 rounded-full eq-bar-3" style={{ background: accent }} />
            </div>
          ) : (
            <span
              className="text-xs font-mono opacity-0 group-hover:opacity-100 transition-opacity"
              style={{ color: "rgba(255,255,255,0.25)" }}
            >
              {rank}
            </span>
          )}
        </div>

        {/* Cover art */}
        <div
          className="w-10 h-10 rounded-lg flex-shrink-0 overflow-hidden relative cursor-pointer"
          onClick={handlePlay}
          style={{
            boxShadow: isCurrentSong ? `0 0 12px ${accent}55` : "none",
          }}
        >
          {song.cover_url && !imgError ? (
            <img
              src={song.cover_url}
              alt={song.title}
              className="w-full h-full object-cover"
              loading="lazy"
              decoding="async"
              onError={() => setImgError(true)}
            />
          ) : (
            <div
              className="w-full h-full flex items-center justify-center"
              style={{ background: `linear-gradient(135deg, ${gradColors[0]}, ${gradColors[1]})` }}
            >
              <Music className="w-4 h-4 text-white/50" />
            </div>
          )}
          {/* Play/Pause overlay */}
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            {isCurrentSong && isPlaying
              ? <Pause className="w-4 h-4 text-white fill-white" />
              : <Play  className="w-4 h-4 text-white fill-white" />
            }
          </div>
          {/* Active ring */}
          {isCurrentSong && (
            <div
              className="absolute inset-0 rounded-lg ring-1 ring-inset"
              style={{ "--tw-ring-color": accent } as React.CSSProperties}
            />
          )}
        </div>

        {/* Song info */}
        <div className="flex-1 min-w-0 cursor-pointer" onClick={handlePlay}>
          <p
            className="text-sm font-medium truncate leading-tight"
            style={{ color: isCurrentSong ? accent : "var(--text)" }}
          >
            {song.title}
          </p>
          <p
            className="text-xs truncate mt-0.5"
            style={{ color: "var(--text-dim)" }}
            onClick={song.artist_id ? handleArtistClick : undefined}
          >
            {song.artist}
            {song.album && (
              <span style={{ color: "rgba(255,255,255,0.15)" }}> · {song.album}</span>
            )}
          </p>
        </div>

        {/* Genre tag */}
        {song.genre && (
          <span
            className="hidden md:block text-xs px-2 py-0.5 rounded-full flex-shrink-0"
            style={{
              background: "rgba(255,255,255,0.05)",
              color:      "rgba(255,255,255,0.25)",
            }}
          >
            {song.genre}
          </span>
        )}

        {/* Score */}
        <div className="hidden sm:block w-12 text-right flex-shrink-0">
          <span
            className="text-xs font-mono"
            style={{ color: "rgba(255,255,255,0.2)" }}
          >
            {(song.score * 100).toFixed(0)}%
          </span>
        </div>

        {/* Action buttons — appear on hover */}
        <div
          className={clsx(
            "flex items-center gap-0.5 flex-shrink-0 transition-all duration-150",
            isCurrentSong ? "opacity-100" : "opacity-0 group-hover:opacity-100"
          )}
        >
          {onInfoClick && (
            <ActionBtn
              onClick={(e) => { e.stopPropagation(); onInfoClick(song); }}
              title="Song info"
            >
              <Info className="w-3.5 h-3.5" />
            </ActionBtn>
          )}

          <ActionBtn
            onClick={(e) => { e.stopPropagation(); toggleLike(song.song_id); }}
            title={liked ? "Unlike" : "Like"}
            active={liked}
            activeColor="rgb(248,113,113)"
          >
            <Heart className="w-3.5 h-3.5" fill={liked ? "currentColor" : "none"} />
          </ActionBtn>

          <ActionBtn
            onClick={(e) => { e.stopPropagation(); handleAddToQueue(); }}
            title="Add to queue"
            active={addedToQueue}
            activeColor="rgb(52,211,153)"
          >
            <ListPlus className="w-3.5 h-3.5" />
          </ActionBtn>

          {/* More menu */}
          <div className="relative">
            <ActionBtn
              onClick={(e) => { e.stopPropagation(); setShowMenu((m) => !m); }}
              title="More options"
            >
              <MoreHorizontal className="w-3.5 h-3.5" />
            </ActionBtn>

            {showMenu && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setShowMenu(false)} />
                <div
                  className="absolute right-0 bottom-9 z-50 w-48 rounded-xl overflow-hidden py-1.5 scale-in"
                  style={{
                    background: "#13131f",
                    border:     "1px solid rgba(255,255,255,0.1)",
                    boxShadow:  "0 16px 48px rgba(0,0,0,0.7)",
                  }}
                >
                  <MenuRow icon={<Play className="w-3.5 h-3.5" />} onClick={handlePlay}>Play now</MenuRow>
                  <MenuRow icon={<Plus className="w-3.5 h-3.5" />} onClick={handleAddToQueue}>Add to queue</MenuRow>
                  {onAddToPlaylist && (
                    <MenuRow icon={<ListPlus className="w-3.5 h-3.5" />} onClick={() => { onAddToPlaylist(song); setShowMenu(false); }}>
                      Add to playlist
                    </MenuRow>
                  )}
                  {onInfoClick && (
                    <MenuRow icon={<Info className="w-3.5 h-3.5" />} onClick={() => { onInfoClick(song); setShowMenu(false); }}>
                      Song info
                    </MenuRow>
                  )}
                  <div style={{ borderTop: "1px solid rgba(255,255,255,0.06)", margin: "4px 0" }} />
                  <MenuRow
                    icon={<Youtube className="w-3.5 h-3.5" style={{ color: "rgb(255,80,80)" }} />}
                    onClick={() => {
                      window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(`${song.title} ${song.artist}`)}`, "_blank");
                      setShowMenu(false);
                    }}
                  >
                    Open on YouTube
                  </MenuRow>
                  <div style={{ borderTop: "1px solid rgba(255,255,255,0.06)", margin: "4px 0" }} />
                  <MenuRow
                    icon={<Heart className="w-3.5 h-3.5" fill={liked ? "currentColor" : "none"} />}
                    onClick={() => { toggleLike(song.song_id); setShowMenu(false); }}
                    style={{ color: liked ? "rgb(248,113,113)" : undefined }}
                  >
                    {liked ? "Unlike" : "Like"}
                  </MenuRow>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* AI Explanation */}
      {showTagline && (
        <div className="ml-9 mt-1.5 flex items-start gap-2">
          <span
            className="text-xs px-1.5 py-0.5 rounded flex-shrink-0 font-semibold"
            style={{
              background: mode === "genai" ? "rgba(192,132,252,0.15)" : "rgba(45,212,191,0.12)",
              color:      mode === "genai" ? "var(--genai)"            : "var(--hybrid)",
            }}
          >
            {mode === "genai" ? "AI" : "Hybrid"}
          </span>
          <p className="text-xs leading-relaxed" style={{ color: "rgba(255,255,255,0.32)" }}>
            {song.explanation}
          </p>
        </div>
      )}
    </div>
  );
}

function ActionBtn({
  children, onClick, title, active, activeColor,
}: {
  children:    React.ReactNode;
  onClick:     React.MouseEventHandler;
  title?:      string;
  active?:     boolean;
  activeColor?: string;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      className="p-1.5 rounded-lg transition-all"
      style={{ color: active ? activeColor : "rgba(255,255,255,0.25)" }}
      onMouseEnter={(e) => { if (!active) e.currentTarget.style.color = "rgba(255,255,255,0.65)"; }}
      onMouseLeave={(e) => { if (!active) e.currentTarget.style.color = "rgba(255,255,255,0.25)"; }}
    >
      {children}
    </button>
  );
}

function MenuRow({
  icon, onClick, children, style,
}: {
  icon: React.ReactNode; onClick: () => void; children: React.ReactNode; style?: React.CSSProperties;
}) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-white/75 text-left transition-colors"
      style={style}
      onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(255,255,255,0.05)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}
    >
      {icon}
      {children}
    </button>
  );
}
