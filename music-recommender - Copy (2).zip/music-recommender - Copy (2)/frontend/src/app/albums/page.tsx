"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Disc3 } from "lucide-react";
import Link from "next/link";
import { libraryApi } from "@/lib/api";

interface AlbumListItem {
  album_id: number;
  title: string;
  artist: string;
  artist_id: number;
  release_year?: number;
  song_count: number;
  total_plays: number;
}

export default function AlbumsPage() {
  const router = useRouter();
  const [albums, setAlbums] = useState<AlbumListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAlbums = async () => {
      try {
        setLoading(true);
        const response = await libraryApi.getAlbums();
        const payload = response.data;
        const items = Array.isArray(payload) ? payload : (payload?.items || []);
        setAlbums(items);
      } catch (err) {
        setError("Failed to load albums");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchAlbums();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0d0d12" }}>
        <div className="text-sm animate-pulse" style={{ color: "rgba(255,255,255,0.3)" }}>Loading albums...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "#0d0d12" }}>
      {/* Header */}
      <div className="relative overflow-hidden" style={{ background: "linear-gradient(160deg, #a084fc28 0%, #a084fc08 60%, #0d0d12 100%)" }}>
        <div className="relative px-6 pt-10 pb-8">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-1.5 text-xs mb-10 transition-colors hover:opacity-100"
            style={{ color: "rgba(255,255,255,0.4)" }}
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back
          </button>

          <h1 className="text-4xl font-bold text-white">Albums</h1>
          <p className="text-sm mt-2" style={{ color: "rgba(255,255,255,0.5)" }}>
            {albums.length} album{albums.length !== 1 ? "s" : ""}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-8">
        {error && (
          <div className="text-red-400 text-sm mb-6">{error}</div>
        )}

        {albums.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Disc3 className="w-12 h-12 mb-4" style={{ color: "rgba(255,255,255,0.2)" }} />
            <p className="text-sm" style={{ color: "rgba(255,255,255,0.4)" }}>No albums found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {albums.map((album) => (
              <Link
                key={album.album_id}
                href={`/albums/${album.album_id}`}
                className="group p-4 rounded-xl transition-all duration-200 hover:opacity-100"
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <div className="flex items-start gap-3">
                  <div
                    className="w-12 h-12 rounded-lg flex-shrink-0 flex items-center justify-center text-lg font-bold flex-shrink-0"
                    style={{
                      background: "rgba(192,132,252,0.2)",
                      color: "#a084fc",
                    }}
                  >
                    {album.title.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-semibold text-white truncate group-hover:text-purple-300 transition-colors">
                      {album.title}
                    </h3>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        router.push(`/artists/${album.artist_id}`);
                      }}
                      className="text-xs mt-1 text-analytics-300 hover:text-analytics-200 transition-colors truncate block text-left"
                    >
                      {album.artist}
                    </button>
                    <div className="flex items-center gap-2 mt-1 text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>
                      {album.release_year && <span>{album.release_year}</span>}
                      <span>{album.song_count} songs</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
