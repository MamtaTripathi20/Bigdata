"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { Play, ArrowLeft, Music, Clock, Heart, SkipForward, Zap, User } from "lucide-react";
import { usePlayer } from "@/components/ui/PlayerContext";
import type { RecommendedSong } from "@/types";
import Link from "next/link";
import api from "@/lib/api";

// ── Types ─────────────────────────────────────────────────────────
interface AlbumSong {
  song_id: number; title: string; genre?: string;
  duration_s?: number; play_count: number; total_plays: number;
  likes: number; tempo?: number; energy?: number;
  valence?: number; key?: string; mode?: string; loudness?: number;
}
interface Album {
  album_id: number; title: string; artist: string; artist_id: number;
  release_year?: number; song_count: number; total_duration_s: number; total_plays: number;
  stats: {
    avg_tempo?: number; avg_energy?: number; avg_danceability?: number;
    avg_valence?: number; avg_loudness?: number;
    tempo_range: { min?: number; max?: number; avg?: number };
    dominant_key?: string; key_distribution: Record<string, number>;
    major_songs: number; minor_songs: number;
    genre_breakdown: Record<string, number>;
    like_rate: number; skip_rate: number;
  };
  mood: { label: string; color: string; energy: number; valence: number };
  achievements: { icon: string; title: string; desc: string }[];
  songs: AlbumSong[];
}

// ── Helpers ───────────────────────────────────────────────────────
function fmt(s?: number) {
  if (!s) return "—";
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
function fmtTotal(s: number) {
  if (!s) return "";
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m} min`;
}
function fmtNum(n: number) {
  return n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n);
}

const MOOD_GRADIENTS: Record<string, string> = {
  Euphoric:   "linear-gradient(135deg, #E8A84C20, #E84CA020)",
  Intense:    "linear-gradient(135deg, #E84C4C20, #A84CE820)",
  Chill:      "linear-gradient(135deg, #4CE8A820, #4C9BE820)",
  Melancholic:"linear-gradient(135deg, #4C9BE820, #7F77DD20)",
};

// ── Energy bar for track list ─────────────────────────────────────
function EnergyDot({ value, color }: { value?: number; color: string }) {
  if (!value) return <span className="w-12" />;
  const h = Math.max(4, value * 20);
  return (
    <div className="w-12 flex items-end justify-center gap-px h-5">
      {[0.4, 0.7, 1].map((mul, i) => (
        <div key={i} className="w-1 rounded-full" style={{ height: `${h * mul}px`, background: `${color}${i === 2 ? "cc" : i === 1 ? "80" : "40"}` }} />
      ))}
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────
export default function AlbumPage() {
  const params = useParams();
  const router = useRouter();
  const { playSong } = usePlayer();
  const [album,   setAlbum]   = useState<Album | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"tracks" | "stats">("tracks");
  const [playingId, setPlayingId] = useState<number | null>(null);

  useEffect(() => {
    const id = Number(params.id);
    if (!id) return;
    api.get(`/api/v1/library/albums/${id}/full`)
      .then((r) => setAlbum(r.data))
      .catch(() => setAlbum(null))
      .finally(() => setLoading(false));
  }, [params.id]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#0d0d12" }}>
      <div className="text-sm animate-pulse" style={{ color: "rgba(255,255,255,0.3)" }}>Loading album...</div>
    </div>
  );
  if (!album) return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-4" style={{ background: "#0d0d12" }}>
      <p className="text-red-400 text-sm">Album not found</p>
      <button onClick={() => router.back()} className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>← Back</button>
    </div>
  );

  const mc = album.mood.color;
  const heroGradient = MOOD_GRADIENTS[album.mood.label] || MOOD_GRADIENTS.Chill;

  const playFrom = (idx: number) => {
    const songs = album.songs.map((s) => ({
      song_id: s.song_id, title: s.title, artist: album.artist,
      genre: s.genre, score: 1, explanation: `From ${album.title}`,
    } as RecommendedSong));
    setPlayingId(album.songs[idx].song_id);
    playSong(songs[idx], "analytics", songs);
  };

  const maxPlays = Math.max(...album.songs.map((s) => s.total_plays), 1);

  return (
    <div className="min-h-screen pb-40" style={{ background: "#0d0d12" }}>

      {/* ── Hero ─────────────────────────────────────────────────── */}
      <div className="relative overflow-hidden" style={{ background: heroGradient }}>
        <div className="relative px-6 pt-10 pb-8">
          <button onClick={() => router.back()}
                  className="flex items-center gap-1.5 text-xs mb-10 hover:opacity-100 transition-opacity"
                  style={{ color: "rgba(255,255,255,0.4)" }}>
            <ArrowLeft className="w-3.5 h-3.5" /> Back
          </button>

          <div className="flex flex-col sm:flex-row items-start sm:items-end gap-6">
            {/* Album cover */}
            <div className="w-40 h-40 rounded-3xl flex-shrink-0 flex items-center justify-center relative overflow-hidden"
                 style={{ background: `linear-gradient(135deg, ${mc}30, ${mc}10)`, border: `1.5px solid ${mc}30` }}>
              <Music className="w-16 h-16" style={{ color: `${mc}70` }} />
              {/* Mood badge */}
              <div className="absolute top-2 right-2 px-2 py-1 rounded-lg text-xs font-semibold"
                   style={{ background: `${mc}40`, color: mc, backdropFilter: "blur(8px)" }}>
                {album.mood.label}
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium uppercase tracking-widest mb-1" style={{ color: mc }}>Album</p>
              <h1 className="text-3xl font-bold text-white mb-2 leading-tight">{album.title}</h1>

              <Link href={`/artists/${album.artist_id}`}
                    className="flex items-center gap-1.5 text-sm font-medium mb-3 w-fit hover:underline"
                    style={{ color: "rgba(255,255,255,0.7)" }}>
                <User className="w-3.5 h-3.5" /> {album.artist}
              </Link>

              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
                {album.release_year && <span>{album.release_year}</span>}
                <span>{album.song_count} songs</span>
                {album.total_duration_s > 0 && <span>{fmtTotal(album.total_duration_s)}</span>}
                {album.total_plays > 0 && <span>{fmtNum(album.total_plays)} plays</span>}
              </div>
            </div>
          </div>

          {/* Play all */}
          <div className="flex items-center gap-3 mt-6">
            <button onClick={() => playFrom(0)}
                    className="flex items-center gap-2.5 px-6 py-3 rounded-2xl text-sm font-semibold transition-all hover:scale-105"
                    style={{ background: mc, color: "#fff" }}>
              <Play className="w-4 h-4 fill-white" /> Play album
            </button>
            <div className="flex items-center gap-3 text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
              <span>♥ {album.stats.like_rate}% liked</span>
              <span>⏭ {album.stats.skip_rate}% skipped</span>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 max-w-4xl mx-auto space-y-6">

        {/* ── Achievements ────────────────────────────────────────── */}
        {album.achievements.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {album.achievements.map((a, i) => (
              <div key={i} className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs"
                   style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}>
                <span>{a.icon}</span>
                <span className="font-medium text-white">{a.title}</span>
                <span style={{ color: "rgba(255,255,255,0.4)" }}>— {a.desc}</span>
              </div>
            ))}
          </div>
        )}

        {/* ── Mood meter ──────────────────────────────────────────── */}
        <div className="rounded-2xl p-4" style={{ background: `${mc}12`, border: `1px solid ${mc}25` }}>
          <p className="text-xs font-medium mb-3" style={{ color: mc }}>Album mood — {album.mood.label}</p>
          <div className="relative h-24 rounded-xl overflow-hidden" style={{ background: "rgba(0,0,0,0.2)" }}>
            {/* Quadrant labels */}
            <span className="absolute top-1.5 left-2 text-xs" style={{ color: "rgba(255,255,255,0.2)" }}>Chill</span>
            <span className="absolute top-1.5 right-2 text-xs" style={{ color: "rgba(255,255,255,0.2)" }}>Euphoric</span>
            <span className="absolute bottom-1.5 left-2 text-xs" style={{ color: "rgba(255,255,255,0.2)" }}>Melancholic</span>
            <span className="absolute bottom-1.5 right-2 text-xs" style={{ color: "rgba(255,255,255,0.2)" }}>Intense</span>
            {/* Axes */}
            <div className="absolute inset-y-0 left-1/2 w-px" style={{ background: "rgba(255,255,255,0.08)" }} />
            <div className="absolute inset-x-0 top-1/2 h-px" style={{ background: "rgba(255,255,255,0.08)" }} />
            {/* Dot */}
            <div className="absolute w-4 h-4 rounded-full -translate-x-1/2 -translate-y-1/2 transition-all duration-700"
                 style={{
                   left: `${album.mood.valence * 100}%`,
                   top:  `${(1 - album.mood.energy) * 100}%`,
                   background: mc,
                   boxShadow: `0 0 16px ${mc}`,
                 }} />
            {/* Axis labels */}
            <span className="absolute bottom-1/2 left-0 translate-y-1/2 px-1 text-xs rotate-0" style={{ color: "rgba(255,255,255,0.25)", fontSize: "9px" }}>low energy</span>
            <span className="absolute top-1 left-1/2 -translate-x-1/2 text-xs" style={{ color: "rgba(255,255,255,0.25)", fontSize: "9px" }}>high energy</span>
            <span className="absolute right-1 top-1/2 -translate-y-1/2 text-xs" style={{ color: "rgba(255,255,255,0.25)", fontSize: "9px", writingMode: "vertical-rl" }}>positive</span>
          </div>
          <div className="flex justify-between text-xs mt-2" style={{ color: "rgba(255,255,255,0.35)" }}>
            <span>Energy: {(album.mood.energy * 100).toFixed(0)}%</span>
            <span>Positivity: {(album.mood.valence * 100).toFixed(0)}%</span>
          </div>
        </div>

        {/* ── Tabs ───────────────────────────────────────────────── */}
        <div className="flex gap-1 p-1 rounded-xl" style={{ background: "rgba(255,255,255,0.04)" }}>
          {(["tracks", "stats"] as const).map((t) => (
            <button key={t} onClick={() => setActiveTab(t)}
                    className="flex-1 py-2 rounded-lg text-sm font-medium capitalize transition-all"
                    style={{
                      background: activeTab === t ? "rgba(255,255,255,0.1)" : "transparent",
                      color: activeTab === t ? "white" : "rgba(255,255,255,0.4)",
                    }}>
              {t === "tracks" ? `Tracks (${album.song_count})` : "Audio stats"}
            </button>
          ))}
        </div>

        {/* ── Tracklist ────────────────────────────────────────────── */}
        {activeTab === "tracks" && (
          <div className="space-y-1">
            {/* Column header */}
            <div className="grid gap-3 px-3 pb-1" style={{ gridTemplateColumns: "2rem 1fr 3rem 3rem 3rem 4rem", color: "rgba(255,255,255,0.2)", fontSize: "11px" }}>
              <span>#</span><span>Title</span><span className="text-center">Energy</span>
              <span className="text-center">Key</span><span className="text-right">Plays</span><span className="text-right">Time</span>
            </div>

            {album.songs.map((song, i) => {
              const isPlaying = playingId === song.song_id;
              return (
                <div key={song.song_id}
                     className="group grid gap-3 items-center px-3 py-2.5 rounded-xl transition-colors cursor-pointer"
                     style={{
                       gridTemplateColumns: "2rem 1fr 3rem 3rem 3rem 4rem",
                       background: isPlaying ? "rgba(255,255,255,0.07)" : undefined,
                     }}
                     onMouseEnter={(e) => { if (!isPlaying) (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; }}
                     onMouseLeave={(e) => { if (!isPlaying) (e.currentTarget as HTMLElement).style.background = ""; }}
                     onClick={() => playFrom(i)}>

                  {/* Track # / play icon */}
                  <div className="text-center">
                    <span className={`text-xs group-hover:hidden ${isPlaying ? "hidden" : ""}`}
                          style={{ color: "rgba(255,255,255,0.2)" }}>{i + 1}</span>
                    <Play className={`w-3.5 h-3.5 mx-auto text-white/50 ${isPlaying ? "block" : "hidden group-hover:block"}`} />
                  </div>

                  {/* Title */}
                  <div className="min-w-0">
                    <p className={`text-sm truncate font-medium ${isPlaying ? "text-green-400" : "text-white"}`}>
                      {song.title}
                    </p>
                    {/* Play bar */}
                    <div className="mt-1 h-0.5 rounded-full" style={{ background: "rgba(255,255,255,0.04)" }}>
                      <div className="h-0.5 rounded-full transition-all"
                           style={{ width: `${(song.total_plays / maxPlays) * 100}%`, background: `${mc}70` }} />
                    </div>
                  </div>

                  {/* Energy bars */}
                  <EnergyDot value={song.energy} color={mc} />

                  {/* Key */}
                  <span className="text-xs text-center font-medium"
                        style={{ color: song.key ? "rgba(255,255,255,0.5)" : "rgba(255,255,255,0.15)" }}>
                    {song.key || "—"}
                  </span>

                  {/* Plays */}
                  <span className="text-xs text-right" style={{ color: "rgba(255,255,255,0.4)" }}>
                    {fmtNum(song.total_plays)}
                  </span>

                  {/* Duration */}
                  <span className="text-xs text-right" style={{ color: "rgba(255,255,255,0.3)" }}>
                    {fmt(song.duration_s)}
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {/* ── Stats tab ──────────────────────────────────────────── */}
        {activeTab === "stats" && (
          <div className="space-y-5">

            {/* Quick stats grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: "Avg tempo",    value: album.stats.avg_tempo ? `${Math.round(album.stats.avg_tempo)} BPM` : "—" },
                { label: "Avg energy",   value: album.stats.avg_energy ? `${(album.stats.avg_energy * 100).toFixed(0)}%` : "—" },
                { label: "Avg valence",  value: album.stats.avg_valence ? `${(album.stats.avg_valence * 100).toFixed(0)}%` : "—" },
                { label: "Avg loudness", value: album.stats.avg_loudness ? `${album.stats.avg_loudness.toFixed(1)} dB` : "—" },
                { label: "Dominant key", value: album.stats.dominant_key || "—" },
                { label: "Major songs",  value: `${album.stats.major_songs} of ${album.song_count}` },
                { label: "Like rate",    value: `${album.stats.like_rate}%` },
                { label: "Tempo range",  value: album.stats.tempo_range.min ? `${Math.round(album.stats.tempo_range.min)}–${Math.round(album.stats.tempo_range.max!)}` : "—" },
              ].map((item) => (
                <div key={item.label} className="px-4 py-3 rounded-xl" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}>
                  <p className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>{item.label}</p>
                  <p className="text-base font-semibold text-white mt-1">{item.value}</p>
                </div>
              ))}
            </div>

            {/* Audio features */}
            <div className="rounded-2xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
              <h3 className="text-sm font-semibold text-white mb-4">Average audio features</h3>
              {[
                { label: "Energy",        val: album.stats.avg_energy,       color: "#E84C4C" },
                { label: "Danceability",  val: album.stats.avg_danceability,  color: "#4CE8A8" },
                { label: "Valence / mood",val: album.stats.avg_valence,       color: "#E8C44C" },
              ].map(({ label, val, color }) => val != null ? (
                <div key={label} className="flex items-center gap-3 mb-3">
                  <span className="text-xs w-28 flex-shrink-0" style={{ color: "rgba(255,255,255,0.4)" }}>{label}</span>
                  <div className="flex-1 h-2 rounded-full" style={{ background: "rgba(255,255,255,0.06)" }}>
                    <div className="h-2 rounded-full" style={{ width: `${val * 100}%`, background: color }} />
                  </div>
                  <span className="text-xs w-10 text-right" style={{ color: "rgba(255,255,255,0.4)" }}>
                    {(val * 100).toFixed(0)}%
                  </span>
                </div>
              ) : null)}
            </div>

            {/* Key distribution */}
            {Object.keys(album.stats.key_distribution).length > 0 && (
              <div className="rounded-2xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                <h3 className="text-sm font-semibold text-white mb-4">Key distribution</h3>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(album.stats.key_distribution)
                    .sort(([, a], [, b]) => b - a)
                    .map(([key, count]) => (
                      <div key={key} className="flex flex-col items-center px-3 py-2 rounded-xl"
                           style={{ background: key === album.stats.dominant_key ? `${mc}25` : "rgba(255,255,255,0.05)", border: key === album.stats.dominant_key ? `1px solid ${mc}50` : "none" }}>
                        <span className="text-sm font-bold" style={{ color: key === album.stats.dominant_key ? mc : "white" }}>{key}</span>
                        <span className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.35)" }}>{count} songs</span>
                      </div>
                    ))}
                </div>
                <p className="text-xs mt-3" style={{ color: "rgba(255,255,255,0.3)" }}>
                  {album.stats.major_songs} major · {album.stats.minor_songs} minor
                </p>
              </div>
            )}

            {/* Per-track energy timeline */}
            <div className="rounded-2xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
              <h3 className="text-sm font-semibold text-white mb-4">Energy through the album</h3>
              <div className="flex items-end gap-1 h-16">
                {album.songs.map((song, i) => {
                  const h = song.energy ? Math.max(8, song.energy * 64) : 8;
                  return (
                    <div key={i} className="flex-1 rounded-t-sm cursor-pointer transition-all hover:opacity-80"
                         style={{ height: `${h}px`, background: song.energy ? `${mc}${Math.round(40 + song.energy * 100).toString(16)}` : "rgba(255,255,255,0.08)" }}
                         title={`${song.title}${song.energy ? ` — ${(song.energy * 100).toFixed(0)}% energy` : ""}`}
                         onClick={() => playFrom(i)} />
                  );
                })}
              </div>
              <div className="flex justify-between text-xs mt-2" style={{ color: "rgba(255,255,255,0.25)" }}>
                <span>Track 1</span>
                <span>Track {album.song_count}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
