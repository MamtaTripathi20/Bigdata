"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft, Play, Globe, Lock, Trash2, Music,
  Loader2, ListMusic, Pencil, Check, X,
} from "lucide-react";
import Link from "next/link";
import { usePlayer } from "@/components/ui/PlayerContext";
import { authApi, libraryApi } from "@/lib/api";
import type { RecommendedSong } from "@/types";

interface PlaylistSong {
  song_id:  number;
  title:    string;
  artist:   string;
  artist_id: number;
  genre?:   string;
  position: number;
  added_at: string;
}

interface PlaylistDetail {
  id:         number;
  name:       string;
  is_public:  boolean;
  owner:      string;
  created_at: string;
  songs:      PlaylistSong[];
}

export default function PlaylistDetailPage() {
  const params    = useParams();
  const router    = useRouter();
  const playlistId = Number(params.id);
  const queryClient = useQueryClient();
  const { playSong } = usePlayer();

  const [editingName, setEditingName] = useState(false);
  const [nameInput,   setNameInput]   = useState("");

  const { data: playlist, isLoading, error } = useQuery<PlaylistDetail>({
    queryKey: ["playlist", playlistId],
    queryFn:  async () => (await libraryApi.getPlaylist(playlistId)).data,
    enabled:  !isNaN(playlistId),
  });

  const { data: me } = useQuery<{ id: number; username: string }>({
    queryKey: ["auth", "me"],
    queryFn: async () => (await authApi.me()).data,
    staleTime: 60_000,
    retry: 0,
  });

  const removeSongMutation = useMutation({
    mutationFn: (songId: number) =>
      libraryApi.removeSongFromPlaylist(playlistId, songId),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ["playlist", playlistId] }),
  });

  const updateMutation = useMutation({
    mutationFn: (data: { name?: string; is_public?: boolean }) =>
      libraryApi.updatePlaylist(playlistId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["playlist", playlistId] });
      queryClient.invalidateQueries({ queryKey: ["library", "playlists"] });
    },
  });

  const handleRename = () => {
    const trimmed = nameInput.trim();
    if (!trimmed || trimmed === playlist?.name) {
      setEditingName(false);
      return;
    }
    updateMutation.mutate({ name: trimmed }, {
      onSuccess: () => setEditingName(false),
    });
  };

  const handleToggleVisibility = () => {
    if (!playlist) return;
    updateMutation.mutate({ is_public: !playlist.is_public });
  };

  const handlePlayAll = () => {
    if (!playlist || playlist.songs.length === 0) return;
    const [first, ...rest] = playlist.songs;
    const asSong = (s: PlaylistSong): RecommendedSong => ({
      song_id:     s.song_id,
      title:       s.title,
      artist:      s.artist,
      artist_id:   s.artist_id,
      genre:       s.genre,
      score:       1,
      explanation: `From playlist: ${playlist.name}`,
    });
    playSong(asSong(first), "analytics", rest.map(asSong));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0a0f" }}>
        <Loader2 className="w-6 h-6 text-white/30 animate-spin" />
      </div>
    );
  }

  if (error || !playlist) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4" style={{ background: "#0a0a0f" }}>
        <ListMusic className="w-12 h-12 text-white/10" />
        <p className="text-sm text-white/40">Playlist not found or access denied</p>
        <Link href="/library" className="text-xs text-white/30 hover:text-white/60 underline">
          ← Back to Library
        </Link>
      </div>
    );
  }

  const isOwner = Boolean(
    me?.username && playlist.owner && me.username.toLowerCase() === playlist.owner.toLowerCase()
  );

  return (
    <div className="min-h-screen pb-32" style={{ background: "#0a0a0f" }}>
      <header
        className="sticky top-0 z-10 px-4 sm:px-6 py-4 flex items-center gap-3"
        style={{
          background:     "rgba(10,10,15,0.92)",
          backdropFilter: "blur(16px)",
          borderBottom:   "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <Link
          href="/library"
          className="p-1.5 rounded-lg text-white/35 hover:text-white/80 transition-colors"
          aria-label="Back to Library"
        >
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <h1 className="text-base font-semibold text-white truncate flex-1">
          {playlist.name}
        </h1>
      </header>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 pt-6">
        <div
          className="rounded-2xl p-5 mb-6 flex flex-col sm:flex-row items-start sm:items-center gap-5"
          style={{
            background: "rgba(255,255,255,0.04)",
            border:     "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <div
            className="w-20 h-20 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: "rgba(255,255,255,0.07)" }}
          >
            <ListMusic className="w-8 h-8 text-white/20" />
          </div>

          <div className="flex-1 min-w-0">
            {editingName ? (
              <div className="flex items-center gap-2 mb-1">
                <input
                  autoFocus
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleRename();
                    if (e.key === "Escape") setEditingName(false);
                  }}
                  className="flex-1 text-lg font-bold text-white bg-transparent border-b border-white/30 outline-none py-0.5"
                  style={{ maxWidth: 280 }}
                />
                <button onClick={handleRename} className="p-1 text-green-400 hover:text-green-300" aria-label="Save name">
                  <Check className="w-4 h-4" />
                </button>
                <button onClick={() => setEditingName(false)} className="p-1 text-white/30 hover:text-white/60" aria-label="Cancel">
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 mb-1">
                <h2 className="text-lg font-bold text-white truncate">{playlist.name}</h2>
                {isOwner && (
                  <button
                    onClick={() => { setNameInput(playlist.name); setEditingName(true); }}
                    className="p-1 text-white/20 hover:text-white/60 transition-colors flex-shrink-0"
                    aria-label="Rename playlist"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            )}

            <p className="text-xs text-white/35 mb-3">
              by {playlist.owner} · {playlist.songs.length} song{playlist.songs.length !== 1 ? "s" : ""}
            </p>

            <div className="flex items-center gap-2 flex-wrap">
              {playlist.songs.length > 0 && (
                <button
                  onClick={handlePlayAll}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium text-black transition-all hover:scale-105"
                  style={{ background: "white" }}
                >
                  <Play className="w-3.5 h-3.5" fill="currentColor" />
                  Play all
                </button>
              )}
              {isOwner && (
                <button
                  onClick={handleToggleVisibility}
                  disabled={updateMutation.isPending}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all"
                  style={{
                    background: playlist.is_public ? "rgba(74,222,128,0.1)" : "rgba(255,255,255,0.07)",
                    color: playlist.is_public ? "rgba(74,222,128,0.9)" : "rgba(255,255,255,0.4)",
                    border: "1px solid",
                    borderColor: playlist.is_public ? "rgba(74,222,128,0.2)" : "rgba(255,255,255,0.08)",
                  }}
                >
                  {updateMutation.isPending ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : playlist.is_public ? (
                    <Globe className="w-3.5 h-3.5" />
                  ) : (
                    <Lock className="w-3.5 h-3.5" />
                  )}
                  {playlist.is_public ? "Public" : "Private"}
                </button>
              )}
            </div>
          </div>
        </div>

        {playlist.songs.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-14 h-14 rounded-2xl bg-white/[4%] flex items-center justify-center mx-auto mb-4">
              <Music className="w-6 h-6 text-white/15" />
            </div>
            <p className="text-sm font-medium text-white/40">No songs yet</p>
            <p className="text-xs text-white/22 mt-1.5 max-w-xs mx-auto leading-relaxed">
              Add songs using the ⊕ menu on any recommendation card
            </p>
          </div>
        ) : (
          <div
            className="rounded-2xl overflow-hidden"
            style={{
              background: "rgba(255,255,255,0.03)",
              border:     "1px solid rgba(255,255,255,0.06)",
            }}
          >
            <div className="py-1.5">
              {playlist.songs.map((song, i) => (
                <div
                  key={song.song_id}
                  className="flex items-center gap-3 px-4 py-2.5 hover:bg-white/[4%] transition-colors group cursor-pointer"
                  onClick={() => {
                    const rest = [...playlist.songs];
                    rest.splice(i, 1);
                    const asSong = (s: PlaylistSong): RecommendedSong => ({
                      song_id:     s.song_id,
                      title:       s.title,
                      artist:      s.artist,
                      artist_id:   s.artist_id,
                      genre:       s.genre,
                      score:       1,
                      explanation: `From playlist: ${playlist.name}`,
                    });
                    playSong(asSong(song), "analytics", rest.map(asSong));
                  }}
                >
                  <span className="w-5 text-xs text-center flex-shrink-0 text-white/20 font-mono group-hover:hidden">
                    {i + 1}
                  </span>
                  <Play className="w-4 h-4 text-white/50 hidden group-hover:block flex-shrink-0" fill="currentColor" />
                  <div
                    className="w-9 h-9 rounded-lg flex-shrink-0 flex items-center justify-center"
                    style={{ background: "rgba(255,255,255,0.06)" }}
                  >
                    <Music className="w-4 h-4 text-white/20" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{song.title}</p>
                    <p className="text-xs truncate text-white/38">{song.artist}</p>
                  </div>
                  {song.genre && (
                    <span
                      className="hidden sm:block text-xs px-2 py-0.5 rounded-full flex-shrink-0"
                      style={{ background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.28)" }}
                    >
                      {song.genre}
                    </span>
                  )}
                  {isOwner && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Remove "${song.title}" from this playlist?`)) {
                          removeSongMutation.mutate(song.song_id);
                        }
                      }}
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg text-white/20 hover:text-red-400"
                      aria-label={`Remove ${song.title}`}
                    >
                      {removeSongMutation.isPending
                        ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        : <Trash2 className="w-3.5 h-3.5" />}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
