"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ListMusic, Plus, Loader2, ChevronRight, Lock, Globe } from "lucide-react";
import Link from "next/link";
import { libraryApi } from "@/lib/api";

interface Playlist {
  id:         number;
  name:       string;
  is_public:  boolean;
  song_count: number;
  created_at: string;
}

export default function PlaylistsPage() {
  const queryClient = useQueryClient();
  const [creating, setCreating] = useState(false);
  const [newName,  setNewName]  = useState("");

  const { data: playlists = [], isLoading } = useQuery<Playlist[]>({
    queryKey: ["library", "playlists"],
    queryFn:  async () => {
      const res = await libraryApi.getPlaylists();
      const d = res.data;
      // handle both raw array and wrapped { playlists: [...] }
      return Array.isArray(d) ? d : (d.playlists ?? d.items ?? []);
    },
  });

  const createMutation = useMutation({
    // api.ts signature: createPlaylist(name: string, isPublic?: boolean)
    mutationFn: (name: string) => libraryApi.createPlaylist(name, false),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["library", "playlists"] });
      setCreating(false);
      setNewName("");
    },
  });

  const handleCreate = () => {
    const trimmed = newName.trim();
    if (!trimmed) return;
    createMutation.mutate(trimmed);
  };

  return (
    <div className="min-h-screen pb-32" style={{ background: "#0a0a0f" }}>
      <header
        className="sticky top-0 z-10 px-4 sm:px-6 py-4 flex items-center justify-between"
        style={{
          background:     "rgba(10,10,15,0.92)",
          backdropFilter: "blur(16px)",
          borderBottom:   "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <h1 className="text-base font-semibold text-white">Playlists</h1>
        <button
          onClick={() => setCreating(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-white/70 hover:text-white transition-colors"
          style={{ background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.08)" }}
        >
          <Plus className="w-3.5 h-3.5" />
          New playlist
        </button>
      </header>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 pt-6">
        {creating && (
          <div
            className="rounded-2xl p-4 mb-4 flex items-center gap-3"
            style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
          >
            <input
              autoFocus
              placeholder="Playlist name"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleCreate();
                if (e.key === "Escape") { setCreating(false); setNewName(""); }
              }}
              className="flex-1 bg-transparent text-sm text-white outline-none placeholder:text-white/25"
            />
            <button
              onClick={handleCreate}
              disabled={!newName.trim() || createMutation.isPending}
              className="px-4 py-1.5 rounded-xl text-xs font-medium text-black"
              style={{ background: newName.trim() ? "white" : "rgba(255,255,255,0.2)" }}
            >
              {createMutation.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "Create"}
            </button>
            <button
              onClick={() => { setCreating(false); setNewName(""); }}
              className="text-xs text-white/30 hover:text-white/60"
            >
              Cancel
            </button>
          </div>
        )}

        {isLoading ? (
          <div className="flex justify-center py-16">
            <Loader2 className="w-5 h-5 text-white/20 animate-spin" />
          </div>
        ) : playlists.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-14 h-14 rounded-2xl bg-white/[4%] flex items-center justify-center mx-auto mb-4">
              <ListMusic className="w-6 h-6 text-white/15" />
            </div>
            <p className="text-sm font-medium text-white/40">No playlists yet</p>
            <p className="text-xs text-white/22 mt-1.5">Create one to start saving songs</p>
          </div>
        ) : (
          <div
            className="rounded-2xl overflow-hidden"
            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
          >
            {playlists.map((pl, i) => (
              <Link
                key={pl.id}
                href={`/library/playlists/${pl.id}`}
                className="flex items-center gap-3 px-4 py-3 hover:bg-white/[4%] transition-colors"
                style={{ borderTop: i > 0 ? "1px solid rgba(255,255,255,0.04)" : "none" }}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ background: "rgba(255,255,255,0.07)" }}
                >
                  <ListMusic className="w-4 h-4 text-white/25" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">{pl.name}</p>
                  <p className="text-xs text-white/35 mt-0.5">
                    {pl.song_count ?? 0} song{(pl.song_count ?? 0) !== 1 ? "s" : ""}
                  </p>
                </div>
                {pl.is_public
                  ? <Globe className="w-3.5 h-3.5 text-white/20 flex-shrink-0" />
                  : <Lock  className="w-3.5 h-3.5 text-white/20 flex-shrink-0" />}
                <ChevronRight className="w-4 h-4 text-white/15 flex-shrink-0" />
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}