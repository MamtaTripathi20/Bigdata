"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Music2, Disc3, Mic2, ListMusic, Heart, Clock, TrendingUp, Plus } from "lucide-react";

const QUICK_LINKS = [
  {
    href:    "/library/playlists",
    icon:    <ListMusic className="w-5 h-5" />,
    label:   "Playlists",
    desc:    "Your curated collections",
    color:   "var(--analytics)",
    bg:      "rgba(79,142,247,0.12)",
    border:  "rgba(79,142,247,0.2)",
  },
  {
    href:    "/artists",
    icon:    <Mic2 className="w-5 h-5" />,
    label:   "Artists",
    desc:    "Browse by artist",
    color:   "var(--genai)",
    bg:      "rgba(192,132,252,0.12)",
    border:  "rgba(192,132,252,0.2)",
  },
  {
    href:    "/albums",
    icon:    <Disc3 className="w-5 h-5" />,
    label:   "Albums",
    desc:    "Browse by album",
    color:   "var(--hybrid)",
    bg:      "rgba(45,212,191,0.12)",
    border:  "rgba(45,212,191,0.2)",
  },
];

const STAT_CARDS = [
  { icon: <Heart className="w-4 h-4" />,    label: "Liked Tracks",    value: "—", color: "rgb(248,113,113)" },
  { icon: <Clock className="w-4 h-4" />,    label: "Hours Listened",  value: "—", color: "var(--analytics)" },
  { icon: <TrendingUp className="w-4 h-4" />,label: "Recommendations", value: "—", color: "var(--genai)" },
];

export default function LibraryPage() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);

  return (
    <div style={{ opacity: mounted ? 1 : 0, transition: "opacity 0.4s ease" }}>

      {/* Header */}
      <div
        className="sticky top-0 z-10 px-5 py-4"
        style={{
          background:     "rgba(7,7,15,0.85)",
          backdropFilter: "blur(20px)",
          borderBottom:   "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <h1 className="font-display font-bold text-xl text-white">Your Library</h1>
        <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.35)" }}>
          Everything you've saved and listened to
        </p>
      </div>

      <div className="p-5 space-y-6 max-w-4xl">

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-3 fade-in-up">
          {STAT_CARDS.map((s, i) => (
            <div
              key={s.label}
              className="p-4 rounded-2xl"
              style={{
                background:    "rgba(255,255,255,0.02)",
                border:        "1px solid rgba(255,255,255,0.06)",
                animationDelay: `${i * 0.05}s`,
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <span style={{ color: s.color }}>{s.icon}</span>
                <span className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>{s.label}</span>
              </div>
              <p className="font-display font-bold text-2xl text-white">{s.value}</p>
            </div>
          ))}
        </div>

        {/* Quick links */}
        <section className="fade-in-up" style={{ animationDelay: "0.1s" }}>
          <h2 className="font-display font-bold text-sm mb-3" style={{ color: "rgba(255,255,255,0.6)" }}>
            Browse
          </h2>
          <div className="space-y-2">
            {QUICK_LINKS.map((link, i) => (
              <Link
                key={link.href}
                href={link.href}
                className="flex items-center gap-4 p-4 rounded-2xl transition-all duration-150 group fade-in-up"
                style={{
                  background:    "rgba(255,255,255,0.02)",
                  border:        "1px solid rgba(255,255,255,0.06)",
                  animationDelay: `${0.12 + i * 0.05}s`,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = `${link.bg}`;
                  e.currentTarget.style.border = `1px solid ${link.border}`;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "rgba(255,255,255,0.02)";
                  e.currentTarget.style.border = "1px solid rgba(255,255,255,0.06)";
                }}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all"
                  style={{ background: link.bg, color: link.color }}
                >
                  {link.icon}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-display font-bold text-white">{link.label}</p>
                  <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.35)" }}>{link.desc}</p>
                </div>
                <span className="text-white/20 group-hover:text-white/60 transition-colors text-lg">→</span>
              </Link>
            ))}
          </div>
        </section>

        {/* Create playlist CTA */}
        <section className="fade-in-up" style={{ animationDelay: "0.25s" }}>
          <Link
            href="/library/playlists"
            className="flex items-center gap-3 p-4 rounded-2xl transition-all duration-150"
            style={{
              background: "rgba(79,142,247,0.06)",
              border:     "1px dashed rgba(79,142,247,0.25)",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(79,142,247,0.1)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = "rgba(79,142,247,0.06)"; }}
          >
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(79,142,247,0.15)", color: "var(--analytics)" }}
            >
              <Plus className="w-4 h-4" />
            </div>
            <div>
              <p className="text-sm font-display font-bold" style={{ color: "var(--analytics)" }}>Create a playlist</p>
              <p className="text-xs mt-0.5" style={{ color: "rgba(79,142,247,0.6)" }}>Organise your favourites</p>
            </div>
          </Link>
        </section>
      </div>
    </div>
  );
}
