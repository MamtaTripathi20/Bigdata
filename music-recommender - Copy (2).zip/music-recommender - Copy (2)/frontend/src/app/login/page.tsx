"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Music4, ArrowRight, Loader2 } from "lucide-react";
import { authApi } from "@/lib/api";

const FEATURES = [
  { icon: "📊", title: "Analytics Mode",  desc: "Fuzzy C-Means + Collaborative Filtering ML" },
  { icon: "🤖", title: "GenAI Mode",      desc: "Sentence Transformer vibe embeddings" },
  { icon: "⚡", title: "Hybrid Fusion",   desc: "Best-of-both α·ML + β·AI pipeline" },
];

export default function LoginPage() {
  const router = useRouter();
  const [tab,       setTab]       = useState<"login" | "register">("login");
  const [showPass,  setShowPass]  = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error,     setError]     = useState("");

  const [form, setForm] = useState({ username: "", email: "", password: "" });

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async () => {
    setError("");
    if (!form.username || !form.password) return;
    if (tab === "register" && !form.email) { setError("Email is required"); return; }
    setIsLoading(true);
    try {
      if (tab === "login") {
        // authApi.login uses application/x-www-form-urlencoded (OAuth2 form)
        await authApi.login(form.username, form.password);
      } else {
        // authApi.register sends JSON
        await authApi.register({
          username: form.username,
          email:    form.email,
          password: form.password,
        });
        // After register, auto-login so we get a token
        await authApi.login(form.username, form.password);
      }

      window.dispatchEvent(new Event("auth-changed"));
      router.push("/");
    } catch (err: any) {
      // Axios error: prefer backend detail message
      const detail = err?.response?.data?.detail;
      setError(
        typeof detail === "string"
          ? detail
          : Array.isArray(detail)
          ? detail.map((d: any) => d.msg).join(", ")
          : err.message ?? "Request failed"
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleSubmit();
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden"
      style={{ background: "var(--bg)" }}
    >
      {/* Aurora background blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute w-96 h-96 rounded-full animate-glow-pulse"
          style={{
            top:       "-10%",
            left:      "-5%",
            background: "radial-gradient(circle, rgba(79,142,247,0.15) 0%, transparent 70%)",
            filter:    "blur(40px)",
          }}
        />
        <div
          className="absolute w-80 h-80 rounded-full animate-glow-pulse"
          style={{
            bottom:    "-5%",
            right:     "10%",
            background: "radial-gradient(circle, rgba(192,132,252,0.12) 0%, transparent 70%)",
            filter:    "blur(40px)",
            animationDelay: "1.5s",
          }}
        />
        <div
          className="absolute w-64 h-64 rounded-full animate-glow-pulse"
          style={{
            top:       "40%",
            right:     "-5%",
            background: "radial-gradient(circle, rgba(45,212,191,0.1) 0%, transparent 70%)",
            filter:    "blur(40px)",
            animationDelay: "3s",
          }}
        />
      </div>

      <div className="w-full max-w-4xl grid md:grid-cols-2 gap-8 items-center relative z-10">

        {/* ── Left: branding ──────────────────────────────────────── */}
        <div className="hidden md:flex flex-col gap-8 fade-in-up">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center"
              style={{
                background: "linear-gradient(135deg, #4f8ef7 0%, #c084fc 50%, #2dd4bf 100%)",
                boxShadow:  "0 0 32px rgba(79,142,247,0.4)",
              }}
            >
              <Music4 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-display font-bold text-2xl text-white leading-none">Resonance</h1>
              <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.35)" }}>Multi-Mode Music AI</p>
            </div>
          </div>

          <div>
            <h2 className="font-display font-bold text-3xl text-white leading-tight">
              Music that knows<br />
              <span
                style={{
                  background: "linear-gradient(90deg, var(--analytics), var(--genai), var(--hybrid))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                your vibe.
              </span>
            </h2>
            <p className="mt-3 text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.45)" }}>
              Three AI pipelines working together to surface music you'll actually love —
              not just what's trending.
            </p>
          </div>

          <div className="space-y-3">
            {FEATURES.map((f, i) => (
              <div
                key={f.title}
                className="flex items-start gap-3 p-3 rounded-xl fade-in-up"
                style={{
                  background:   "rgba(255,255,255,0.03)",
                  border:       "1px solid rgba(255,255,255,0.06)",
                  animationDelay: `${0.1 + i * 0.1}s`,
                }}
              >
                <span className="text-xl leading-none mt-0.5">{f.icon}</span>
                <div>
                  <p className="text-sm font-display font-bold text-white">{f.title}</p>
                  <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.38)" }}>{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Right: auth card ─────────────────────────────────────── */}
        <div
          className="rounded-2xl p-8 scale-in"
          style={{
            background:     "rgba(14, 14, 26, 0.85)",
            backdropFilter: "blur(24px)",
            border:         "1px solid rgba(255,255,255,0.08)",
            boxShadow:      "0 32px 80px rgba(0,0,0,0.6)",
          }}
        >
          {/* Mobile logo */}
          <div className="flex md:hidden items-center gap-3 mb-6">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{
                background: "linear-gradient(135deg, #4f8ef7, #c084fc, #2dd4bf)",
                boxShadow:  "0 0 20px rgba(79,142,247,0.35)",
              }}
            >
              <Music4 className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold text-lg text-white">Resonance</span>
          </div>

          {/* Tab switcher */}
          <div
            className="flex gap-1 p-1 rounded-xl mb-6"
            style={{ background: "rgba(255,255,255,0.04)" }}
          >
            {(["login", "register"] as const).map((t) => (
              <button
                key={t}
                onClick={() => { setTab(t); setError(""); }}
                className="flex-1 py-2 rounded-lg text-sm font-display font-semibold capitalize transition-all duration-200"
                style={{
                  background: tab === t ? "rgba(255,255,255,0.08)" : "transparent",
                  color:      tab === t ? "white" : "rgba(255,255,255,0.4)",
                  boxShadow:  tab === t ? "0 2px 8px rgba(0,0,0,0.3)" : "none",
                }}
              >
                {t}
              </button>
            ))}
          </div>

          {/* Fields */}
          <div className="space-y-3">
            <Field
              label="Username"
              type="text"
              value={form.username}
              onChange={set("username")}
              placeholder="your_username"
              onKeyDown={handleKey}
            />
            {tab === "register" && (
              <Field
                label="Email"
                type="email"
                value={form.email}
                onChange={set("email")}
                placeholder="you@example.com"
                onKeyDown={handleKey}
              />
            )}
            <div className="space-y-1">
              <label className="block text-xs font-semibold" style={{ color: "rgba(255,255,255,0.4)" }}>
                Password
              </label>
              <div
                className="flex items-center rounded-xl overflow-hidden transition-all duration-200"
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border:     "1px solid rgba(255,255,255,0.08)",
                }}
                onFocus={() => {}}
              >
                <input
                  type={showPass ? "text" : "password"}
                  value={form.password}
                  onChange={set("password")}
                  onKeyDown={handleKey}
                  placeholder="••••••••"
                  className="flex-1 bg-transparent px-4 py-3 text-sm text-white outline-none"
                  style={{ caretColor: "var(--analytics)" }}
                />
                <button
                  onClick={() => setShowPass((v) => !v)}
                  className="px-3 py-3 transition-colors"
                  style={{ color: "rgba(255,255,255,0.3)" }}
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          {/* Error */}
          {error && (
            <div
              className="mt-3 px-4 py-2.5 rounded-xl text-xs text-red-400"
              style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.18)" }}
            >
              {error}
            </div>
          )}

          {/* Submit */}
          <button
            onClick={handleSubmit}
            disabled={isLoading || !form.username || !form.password}
            className="mt-5 w-full py-3 rounded-xl flex items-center justify-center gap-2 text-sm font-display font-bold text-white transition-all duration-200 disabled:opacity-50"
            style={{
              background: "linear-gradient(135deg, #4f8ef7, #c084fc)",
              boxShadow:  "0 0 24px rgba(79,142,247,0.35)",
            }}
            onMouseEnter={(e) => { if (!isLoading) (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 0 32px rgba(79,142,247,0.55)"; }}
            onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 0 24px rgba(79,142,247,0.35)"; }}
          >
            {isLoading
              ? <Loader2 className="w-4 h-4 animate-spin" />
              : (
                <>
                  {tab === "login" ? "Sign in" : "Create account"}
                  <ArrowRight className="w-4 h-4" />
                </>
              )
            }
          </button>

          <p className="mt-4 text-center text-xs" style={{ color: "rgba(255,255,255,0.25)" }}>
            {tab === "login"
              ? "New here? "
              : "Already have an account? "
            }
            <button
              onClick={() => { setTab(tab === "login" ? "register" : "login"); setError(""); }}
              className="underline transition-colors"
              style={{ color: "rgba(255,255,255,0.5)" }}
              onMouseEnter={(e) => { e.currentTarget.style.color = "white"; }}
              onMouseLeave={(e) => { e.currentTarget.style.color = "rgba(255,255,255,0.5)"; }}
            >
              {tab === "login" ? "Create an account" : "Sign in instead"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

function Field({
  label, type, value, onChange, placeholder, onKeyDown,
}: {
  label: string; type: string; value: string;
  onChange: React.ChangeEventHandler<HTMLInputElement>;
  placeholder: string; onKeyDown: React.KeyboardEventHandler;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div className="space-y-1">
      <label className="block text-xs font-semibold" style={{ color: "rgba(255,255,255,0.4)" }}>
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={onChange}
        onKeyDown={onKeyDown}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder={placeholder}
        className="w-full bg-transparent px-4 py-3 rounded-xl text-sm text-white outline-none transition-all duration-200"
        style={{
          background:  "rgba(255,255,255,0.04)",
          border:      `1px solid ${focused ? "rgba(79,142,247,0.5)" : "rgba(255,255,255,0.08)"}`,
          boxShadow:   focused ? "0 0 0 3px rgba(79,142,247,0.12)" : "none",
          caretColor:  "var(--analytics)",
        }}
      />
    </div>
  );
}
