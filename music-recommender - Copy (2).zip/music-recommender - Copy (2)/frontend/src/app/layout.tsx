import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Providers }      from "@/components/ui/Providers";
import { PlayerProvider } from "@/components/ui/PlayerContext";
import { PlayerBar }      from "@/components/ui/PlayerBar";
import { QueuePanel }     from "@/components/ui/QueuePanel";
import { Sidebar }        from "@/components/ui/Sidebar";

export const metadata: Metadata = {
  title: "Resonance — Multi-Mode Music AI",
  description: "Analytics + GenAI + Hybrid AI-powered music recommendations",
  icons: {
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🎵</text></svg>",
  },
};

export const viewport: Viewport = {
  themeColor: "#07070f",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="grain">
        <Providers>
          <PlayerProvider>
            {/* App shell: sidebar + content, above the fixed PlayerBar */}
            <div
              className="flex"
              style={{ minHeight: "100vh", paddingBottom: "88px" }}
            >
              <Sidebar />

              {/* Main scrollable area */}
              <main className="flex-1 min-w-0 overflow-y-auto" style={{ minHeight: "calc(100vh - 88px)" }}>
                {children}
              </main>

              <QueuePanel />
            </div>

            {/* Fixed player at the bottom */}
            <PlayerBar />
          </PlayerProvider>
        </Providers>
      </body>
    </html>
  );
}
