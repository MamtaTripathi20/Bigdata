"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Music } from "lucide-react";
import Link from "next/link";
import { libraryApi } from "@/lib/api";

interface ArtistListItem {
  artist_id: number;
  name: string;
  song_count: number;
  total_plays: number;
}

export default function ArtistsPage() {
  const router = useRouter();
  const [artists, setArtists] = useState<ArtistListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchArtists = async () => {
      try {
        setLoading(true);
        const response = await libraryApi.getArtists();
        const payload = response.data;
        const items = Array.isArray(payload) ? payload : (payload?.items || []);
        setArtists(items);
      } catch (err) {
        setError("Failed to load artists");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchArtists();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0d0d12" }}>
        <div className="text-sm animate-pulse" style={{ color: "rgba(255,255,255,0.3)" }}>Loading artists...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "#0d0d12" }}>
      {/* Header */}
      <div className="relative overflow-hidden" style={{ background: "linear-gradient(160deg, #4f8ef728 0%, #4f8ef708 60%, #0d0d12 100%)" }}>
        <div className="relative px-6 pt-10 pb-8">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-1.5 text-xs mb-10 transition-colors hover:opacity-100"
            style={{ color: "rgba(255,255,255,0.4)" }}
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back
          </button>

          <h1 className="text-4xl font-bold text-white">Artists</h1>
          <p className="text-sm mt-2" style={{ color: "rgba(255,255,255,0.5)" }}>
            {artists.length} artist{artists.length !== 1 ? "s" : ""}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-8">
        {error && (
          <div className="text-red-400 text-sm mb-6">{error}</div>
        )}

        {artists.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Music className="w-12 h-12 mb-4" style={{ color: "rgba(255,255,255,0.2)" }} />
            <p className="text-sm" style={{ color: "rgba(255,255,255,0.4)" }}>No artists found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {artists.map((artist) => (
              <Link
                key={artist.artist_id}
                href={`/artists/${artist.artist_id}`}
                className="group p-4 rounded-xl transition-all duration-200 hover:opacity-100"
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <div className="flex items-start gap-3">
                  <div
                    className="w-12 h-12 rounded-lg flex-shrink-0 flex items-center justify-center text-lg font-bold"
                    style={{
                      background: "rgba(79,142,247,0.2)",
                      color: "#4f8ef7",
                    }}
                  >
                    {artist.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-semibold text-white truncate group-hover:text-analytics-300 transition-colors">
                      {artist.name}
                    </h3>
                    <p className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.4)" }}>
                      {artist.song_count} song{artist.song_count !== 1 ? "s" : ""}
                    </p>
                    <p className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>
                      {artist.total_plays.toLocaleString()} plays
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
