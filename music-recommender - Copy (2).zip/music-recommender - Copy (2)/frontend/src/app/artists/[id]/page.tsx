"use client";

import { useEffect, useState, useRef } from "react";
import { useParams, useRouter } from "next/navigation";
import { Play, ArrowLeft, Music, Disc, Users, Heart, SkipForward, Zap, Clock } from "lucide-react";
import { usePlayer } from "@/components/ui/PlayerContext";
import type { RecommendedSong } from "@/types";
import Link from "next/link";
import api from "@/lib/api";

// ── Types ─────────────────────────────────────────────────────────
interface Song {
  song_id: number; title: string; album?: string; album_id?: number;
  genre?: string; duration_s?: number; play_count: number;
  total_plays: number; likes: number; skips: number;
  tempo?: number; energy?: number; key?: string;
}
interface Album {
  album_id: number; title: string; release_year?: number; song_count: number;
}
interface Artist {
  artist_id: number; name: string; mb_id?: string;
  song_count: number; total_plays: number; unique_listeners: number;
  like_rate: number; skip_rate: number;
  genres: string[]; genre_breakdown: { genre: string; count: number; pct: number }[];
  audio_fingerprint: { tempo?: number; energy?: number; danceability?: number; valence?: number; loudness?: number };
  key_distribution: Record<string, number>;
  achievements: { icon: string; title: string; desc: string }[];
  top_songs: Song[]; albums: Album[];
  career: { debut_year?: number; latest_year?: number; active_years?: number; album_count: number };
}

// ── Helpers ───────────────────────────────────────────────────────
const GENRE_COLORS: Record<string, string> = {
  Rock:"#E84C4C", Electronic:"#4C9BE8", Jazz:"#E8A84C", Pop:"#E84CA0",
  "Hip-Hop":"#9BE84C", Classical:"#4CE8D8", "R&B":"#E84C9B",
  Country:"#E8C44C", Metal:"#888", Indie:"#A84CE8", Default:"#7F77DD",
};

function fmt(s?: number) {
  if (!s) return "—";
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
function fmtNum(n: number) {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return String(n);
}
function initials(name: string) {
  return name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
}

// ── Stat card ─────────────────────────────────────────────────────
function StatCard({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub?: string }) {
  return (
    <div className="flex flex-col gap-1 px-4 py-3 rounded-xl" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}>
      <div className="flex items-center gap-1.5" style={{ color: "rgba(255,255,255,0.35)" }}>
        <span className="w-3.5 h-3.5">{icon}</span>
        <span className="text-xs">{label}</span>
      </div>
      <span className="text-xl font-semibold text-white">{value}</span>
      {sub && <span className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>{sub}</span>}
    </div>
  );
}

// ── Audio feature bar ─────────────────────────────────────────────
function FeatureBar({ label, value, color }: { label: string; value?: number; color: string }) {
  if (value == null) return null;
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs w-24 flex-shrink-0" style={{ color: "rgba(255,255,255,0.35)" }}>{label}</span>
      <div className="flex-1 h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.06)" }}>
        <div className="h-1.5 rounded-full transition-all duration-700"
             style={{ width: `${Math.min(100, value * 100)}%`, background: color }} />
      </div>
      <span className="text-xs w-10 text-right font-medium" style={{ color: "rgba(255,255,255,0.5)" }}>
        {(value * 100).toFixed(0)}%
      </span>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────
export default function ArtistPage() {
  const params = useParams();
  const router = useRouter();
  const { playSong } = usePlayer();
  const [artist,  setArtist]  = useState<Artist | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"songs" | "albums" | "stats">("songs");

  useEffect(() => {
    const id = Number(params.id);
    if (!id) return;
    api.get(`/api/v1/library/artists/${id}/full`)
      .then((r) => setArtist(r.data))
      .catch(() => setArtist(null))
      .finally(() => setLoading(false));
  }, [params.id]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#0d0d12" }}>
      <div className="text-sm animate-pulse" style={{ color: "rgba(255,255,255,0.3)" }}>Loading artist profile...</div>
    </div>
  );
  if (!artist) return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-4" style={{ background: "#0d0d12" }}>
      <p className="text-red-400 text-sm">Artist not found</p>
      <button onClick={() => router.back()} className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>← Back</button>
    </div>
  );

  const accent = GENRE_COLORS[artist.genres[0]] || GENRE_COLORS.Default;
  const fp = artist.audio_fingerprint;

  const playAll = () => {
    if (!artist.top_songs.length) return;
    const songs = artist.top_songs.map((s) => ({
      song_id: s.song_id, title: s.title, artist: artist.name,
      album: s.album, genre: s.genre, score: 1, explanation: `By ${artist.name}`,
    } as RecommendedSong));
    playSong(songs[0], "analytics", songs);
  };

  return (
    <div className="min-h-screen pb-40" style={{ background: "#0d0d12" }}>

      {/* ── Hero ─────────────────────────────────────────────────── */}
      <div className="relative overflow-hidden"
           style={{ background: `linear-gradient(160deg, ${accent}28 0%, ${accent}08 60%, #0d0d12 100%)` }}>
        {/* Background glow */}
        <div className="absolute top-0 left-0 w-64 h-64 rounded-full blur-3xl pointer-events-none"
             style={{ background: `${accent}15`, transform: "translate(-30%, -30%)" }} />

        <div className="relative px-6 pt-10 pb-8">
          <button onClick={() => router.back()}
                  className="flex items-center gap-1.5 text-xs mb-10 transition-colors hover:opacity-100"
                  style={{ color: "rgba(255,255,255,0.4)" }}>
            <ArrowLeft className="w-3.5 h-3.5" /> Back
          </button>

          <div className="flex flex-col sm:flex-row items-start sm:items-end gap-6">
            {/* Avatar */}
            <div className="w-32 h-32 rounded-3xl flex-shrink-0 flex items-center justify-center text-4xl font-bold relative"
                 style={{ background: `${accent}25`, color: accent, border: `1.5px solid ${accent}40` }}>
              {initials(artist.name)}
              <div className="absolute -bottom-1.5 -right-1.5 w-5 h-5 rounded-full flex items-center justify-center"
                   style={{ background: accent }}>
                <Music className="w-2.5 h-2.5 text-white" />
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium mb-1 uppercase tracking-widest" style={{ color: accent }}>Artist</p>
              <h1 className="text-4xl font-bold text-white mb-2 leading-tight">{artist.name}</h1>

              {/* Genre pills */}
              <div className="flex flex-wrap gap-2 mb-3">
                {artist.genres.map((g) => (
                  <span key={g} className="text-xs px-3 py-1 rounded-full font-medium"
                        style={{ background: `${GENRE_COLORS[g] || accent}20`, color: GENRE_COLORS[g] || accent }}>
                    {g}
                  </span>
                ))}
              </div>

              {/* Career span */}
              {artist.career.debut_year && (
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>
                  {artist.career.debut_year}
                  {artist.career.latest_year && artist.career.latest_year !== artist.career.debut_year
                    ? ` — ${artist.career.latest_year}` : ""}
                  {artist.career.active_years ? ` · ${artist.career.active_years} years active` : ""}
                </p>
              )}
            </div>
          </div>

          {/* Play all */}
          <button onClick={playAll}
                  className="mt-6 flex items-center gap-2.5 px-6 py-3 rounded-2xl text-sm font-semibold transition-all hover:scale-105"
                  style={{ background: accent, color: "#fff" }}>
            <Play className="w-4 h-4 fill-white" /> Play all songs
          </button>
        </div>
      </div>

      <div className="px-6 max-w-4xl mx-auto space-y-6">

        {/* ── Stats row ──────────────────────────────────────────── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <StatCard icon={<Music className="w-3.5 h-3.5" />}      label="Songs"           value={String(artist.song_count)} />
          <StatCard icon={<Play className="w-3.5 h-3.5" />}       label="Total plays"     value={fmtNum(artist.total_plays)} />
          <StatCard icon={<Users className="w-3.5 h-3.5" />}      label="Listeners"       value={String(artist.unique_listeners)} />
          <StatCard icon={<Heart className="w-3.5 h-3.5" />}      label="Like rate"       value={`${artist.like_rate}%`} sub={`Skip: ${artist.skip_rate}%`} />
        </div>

        {/* ── Achievements ────────────────────────────────────────── */}
        {artist.achievements.length > 0 && (
          <div>
            <h2 className="text-sm font-semibold text-white mb-3">Achievements</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {artist.achievements.map((a, i) => (
                <div key={i} className="flex items-start gap-3 px-4 py-3 rounded-xl"
                     style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                  <span className="text-xl flex-shrink-0">{a.icon}</span>
                  <div>
                    <p className="text-sm font-medium text-white">{a.title}</p>
                    <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>{a.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Tabs ───────────────────────────────────────────────── */}
        <div className="flex gap-1 p-1 rounded-xl" style={{ background: "rgba(255,255,255,0.04)" }}>
          {(["songs", "albums", "stats"] as const).map((t) => (
            <button key={t} onClick={() => setActiveTab(t)}
                    className="flex-1 py-2 rounded-lg text-sm font-medium capitalize transition-all"
                    style={{
                      background: activeTab === t ? "rgba(255,255,255,0.1)" : "transparent",
                      color: activeTab === t ? "white" : "rgba(255,255,255,0.4)",
                    }}>
              {t === "songs" ? `Songs (${artist.song_count})` : t === "albums" ? `Albums (${artist.career.album_count})` : "Analytics"}
            </button>
          ))}
        </div>

        {/* ── Top Songs tab ───────────────────────────────────────── */}
        {activeTab === "songs" && (
          <div className="space-y-1">
            {/* Header */}
            <div className="grid gap-3 px-3 pb-2" style={{ gridTemplateColumns: "2rem 1fr 3rem 3rem 5rem", color: "rgba(255,255,255,0.25)", fontSize: "11px" }}>
              <span>#</span><span>Title</span><span className="text-right">Plays</span><span className="text-right">Likes</span><span className="text-right">Duration</span>
            </div>

            {artist.top_songs.map((song, i) => {
              const maxPlays = artist.top_songs[0]?.total_plays || 1;
              const barWidth = Math.max(3, (song.total_plays / maxPlays) * 100);
              return (
                <div key={song.song_id}
                     className="group relative grid gap-3 items-center px-3 py-2.5 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
                     style={{ gridTemplateColumns: "2rem 1fr 3rem 3rem 5rem" }}
                     onClick={() => playSong({ song_id: song.song_id, title: song.title, artist: artist.name, album: song.album, genre: song.genre, score: 1, explanation: "" } as RecommendedSong, "analytics",
                       artist.top_songs.map((s) => ({ song_id: s.song_id, title: s.title, artist: artist.name, genre: s.genre, score: 1, explanation: "" } as RecommendedSong)))}>

                  {/* Rank */}
                  <span className="text-xs text-center group-hover:hidden" style={{ color: "rgba(255,255,255,0.2)" }}>{i + 1}</span>
                  <Play className="w-3.5 h-3.5 hidden group-hover:block text-white/50 ml-0.5" />

                  {/* Title + play bar */}
                  <div className="min-w-0">
                    <p className="text-sm text-white truncate font-medium">{song.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      {song.album && <p className="text-xs truncate" style={{ color: "rgba(255,255,255,0.3)" }}>{song.album}</p>}
                      {song.key && (
                        <span className="text-xs px-1.5 py-0.5 rounded flex-shrink-0"
                              style={{ background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.3)" }}>
                          {song.key}
                        </span>
                      )}
                      {song.tempo && (
                        <span className="text-xs flex-shrink-0" style={{ color: "rgba(255,255,255,0.2)" }}>
                          {Math.round(song.tempo)} BPM
                        </span>
                      )}
                    </div>
                    {/* Play count bar */}
                    <div className="mt-1.5 h-0.5 rounded-full" style={{ background: "rgba(255,255,255,0.05)", width: "100%" }}>
                      <div className="h-0.5 rounded-full transition-all duration-500"
                           style={{ width: `${barWidth}%`, background: `${accent}80` }} />
                    </div>
                  </div>

                  {/* Plays */}
                  <span className="text-xs text-right font-medium" style={{ color: "rgba(255,255,255,0.5)" }}>
                    {fmtNum(song.total_plays)}
                  </span>

                  {/* Likes */}
                  <span className="text-xs text-right" style={{ color: song.likes > 0 ? "rgba(248,113,113,0.7)" : "rgba(255,255,255,0.2)" }}>
                    {song.likes > 0 ? `♥ ${song.likes}` : "—"}
                  </span>

                  {/* Duration */}
                  <span className="text-xs text-right" style={{ color: "rgba(255,255,255,0.25)" }}>
                    {fmt(song.duration_s)}
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {/* ── Albums tab ─────────────────────────────────────────── */}
        {activeTab === "albums" && (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {artist.albums.map((album) => (
              <Link key={album.album_id} href={`/albums/${album.album_id}`}
                    className="group rounded-2xl p-4 transition-all hover:scale-[1.02]"
                    style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}>
                {/* Album art placeholder with gradient */}
                <div className="w-full aspect-square rounded-xl mb-3 flex items-center justify-center relative overflow-hidden"
                     style={{ background: `linear-gradient(135deg, ${accent}20, ${accent}08)` }}>
                  <Disc className="w-10 h-10 transition-transform group-hover:rotate-12 duration-300"
                        style={{ color: `${accent}80` }} />
                  <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center"
                         style={{ background: accent }}>
                      <Play className="w-3.5 h-3.5 fill-white text-white" />
                    </div>
                  </div>
                </div>
                <p className="text-sm font-semibold text-white truncate">{album.title}</p>
                <p className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.35)" }}>
                  {album.release_year || "Year unknown"} · {album.song_count} songs
                </p>
              </Link>
            ))}
          </div>
        )}

        {/* ── Stats tab ──────────────────────────────────────────── */}
        {activeTab === "stats" && (
          <div className="space-y-6">
            {/* Audio fingerprint */}
            <div className="rounded-2xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
              <h3 className="text-sm font-semibold text-white mb-4">Audio fingerprint</h3>
              <div className="space-y-3">
                <FeatureBar label="Energy"        value={fp.energy}        color={accent} />
                <FeatureBar label="Danceability"  value={fp.danceability}  color="#4CE8A8" />
                <FeatureBar label="Valence / mood" value={fp.valence}      color="#E8C44C" />
              </div>
              <div className="grid grid-cols-2 gap-3 mt-4">
                {fp.tempo && (
                  <div className="px-3 py-2 rounded-xl" style={{ background: "rgba(255,255,255,0.04)" }}>
                    <p className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>Avg tempo</p>
                    <p className="text-lg font-semibold text-white">{Math.round(fp.tempo)} <span className="text-xs font-normal" style={{ color: "rgba(255,255,255,0.4)" }}>BPM</span></p>
                  </div>
                )}
                {fp.loudness && (
                  <div className="px-3 py-2 rounded-xl" style={{ background: "rgba(255,255,255,0.04)" }}>
                    <p className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>Avg loudness</p>
                    <p className="text-lg font-semibold text-white">{fp.loudness.toFixed(1)} <span className="text-xs font-normal" style={{ color: "rgba(255,255,255,0.4)" }}>dB</span></p>
                  </div>
                )}
              </div>
            </div>

            {/* Genre breakdown */}
            <div className="rounded-2xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
              <h3 className="text-sm font-semibold text-white mb-4">Genre breakdown</h3>
              <div className="space-y-2.5">
                {artist.genre_breakdown.slice(0, 6).map((g) => (
                  <div key={g.genre} className="flex items-center gap-3">
                    <span className="text-xs w-24 flex-shrink-0 truncate" style={{ color: "rgba(255,255,255,0.5)" }}>{g.genre}</span>
                    <div className="flex-1 h-2 rounded-full" style={{ background: "rgba(255,255,255,0.06)" }}>
                      <div className="h-2 rounded-full" style={{ width: `${g.pct}%`, background: GENRE_COLORS[g.genre] || accent }} />
                    </div>
                    <span className="text-xs w-12 text-right" style={{ color: "rgba(255,255,255,0.3)" }}>{g.count} songs</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Key distribution */}
            {Object.keys(artist.key_distribution).length > 0 && (
              <div className="rounded-2xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                <h3 className="text-sm font-semibold text-white mb-4">Key distribution</h3>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(artist.key_distribution)
                    .sort(([, a], [, b]) => b - a)
                    .map(([key, count]) => (
                      <div key={key} className="flex flex-col items-center px-3 py-2 rounded-xl"
                           style={{ background: "rgba(255,255,255,0.05)", minWidth: "3rem" }}>
                        <span className="text-sm font-bold text-white">{key}</span>
                        <span className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.35)" }}>{count}</span>
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
