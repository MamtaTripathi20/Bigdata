"use client";

// ✅ FIX: Cold start step 3 now shows DYNAMIC songs from the backend based on the
//         genres + energy the user selected in steps 1 and 2.
//         Previously every user saw the same 8 hardcoded songs.
//         Now the song list is fetched via POST /api/v1/onboarding/suggestions
//         and reflects the user's actual selections.
// ✅ FIX: Progress indicator uses index-based comparison (was broken).

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSubmitVibeCheck } from "@/lib/hooks/useOnboarding";
import { Music, Heart, Volume2, Check, Loader2, RefreshCw } from "lucide-react";
import { clsx } from "clsx";
import axios from "axios";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

// Fallback songs used only if the dynamic fetch fails
const FALLBACK_SONGS = [
  { id: "s1", title: "Blinding Lights",      artist: "The Weeknd",       emoji: "⚡" },
  { id: "s2", title: "HUMBLE.",              artist: "Kendrick Lamar",   emoji: "🎤" },
  { id: "s3", title: "Bohemian Rhapsody",    artist: "Queen",            emoji: "👑" },
  { id: "s4", title: "Levels",               artist: "Avicii",           emoji: "🎛️" },
  { id: "s5", title: "Fleurette Africaine",  artist: "Hugh Masekela",    emoji: "🎺" },
  { id: "s6", title: "Kesariya",             artist: "Arijit Singh",     emoji: "🎶" },
  { id: "s7", title: "bad guy",              artist: "Billie Eilish",    emoji: "😈" },
  { id: "s8", title: "Redbone",              artist: "Childish Gambino", emoji: "🍷" },
];

const GENRE_EMOJIS: Record<string, string> = {
  pop: "✨", hiphop: "🎤", rock: "🎸", electronic: "🎛️",
  jazz: "🎷", classical: "🎻", rnb: "💫", indie: "🎨", bollywood: "🎬",
};

const GENRES = [
  { id: "pop",         label: "Pop",        emoji: "✨" },
  { id: "hiphop",      label: "Hip-Hop",    emoji: "🎤" },
  { id: "rock",        label: "Rock",       emoji: "🎸" },
  { id: "electronic",  label: "Electronic", emoji: "🎛️" },
  { id: "jazz",        label: "Jazz",       emoji: "🎷" },
  { id: "classical",   label: "Classical",  emoji: "🎻" },
  { id: "rnb",         label: "R&B",        emoji: "💫" },
  { id: "indie",       label: "Indie",      emoji: "🎨" },
  { id: "bollywood",   label: "Bollywood",  emoji: "🎬" },
];

const ENERGY_LEVELS = [
  { id: "high",  label: "High Energy 🔥", desc: "Fast-paced, intense, uplifting" },
  { id: "mid",   label: "Medium Energy ⚡", desc: "Balanced, rhythmic, engaging" },
  { id: "low",   label: "Low Energy 🌙", desc: "Calm, chill, relaxing" },
  { id: "mixed", label: "Mixed 🎲", desc: "I like it all!" },
];

type Step = "genres" | "energy" | "songs" | "result";
const STEP_ORDER: Step[] = ["genres", "energy", "songs", "result"];

// Dynamic song suggestion shape from backend
interface SuggestedSong {
  id: string;        // could be db id or quiz id
  title: string;
  artist: string;
  emoji: string;
  db_song_id?: number;
}

export default function OnboardingPage() {
  const router  = useRouter();
  const submit  = useSubmitVibeCheck();

  const [step,           setStep]           = useState<Step>("genres");
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [selectedEnergy, setSelectedEnergy] = useState<string>("");
  const [likedSongs,     setLikedSongs]     = useState<string[]>([]);

  // ✅ FIX: Dynamic song suggestions state
  const [suggestedSongs,    setSuggestedSongs]    = useState<SuggestedSong[]>(FALLBACK_SONGS);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [suggestionsError,   setSuggestionsError]   = useState(false);

  const currentStepIdx = STEP_ORDER.indexOf(step);

  const toggleGenre = (id: string) =>
    setSelectedGenres((p) => p.includes(id) ? p.filter((g) => g !== id) : [...p, id]);

  const toggleSong = (id: string) =>
    setLikedSongs((p) => p.includes(id) ? p.filter((s) => s !== id) : [...p, id]);

  // ✅ FIX: Fetch dynamic song suggestions when entering the songs step
  useEffect(() => {
    if (step !== "songs") return;
    if (!selectedGenres.length) return;

    const fetchSuggestions = async () => {
      setLoadingSuggestions(true);
      setSuggestionsError(false);
      try {
        const res = await axios.post(
          `${API_BASE}/api/v1/onboarding/suggestions`,
          { genres: selectedGenres, energy: selectedEnergy, count: 8 },
          { withCredentials: true, timeout: 8000 }
        );
        const songs: SuggestedSong[] = res.data.songs ?? [];
        if (songs.length >= 4) {
          setSuggestedSongs(songs);
        } else {
          // Not enough from DB, pad with fallbacks
          const extra = FALLBACK_SONGS.filter(f => !songs.some(s => s.title === f.title));
          setSuggestedSongs([...songs, ...extra].slice(0, 8));
        }
      } catch {
        setSuggestionsError(true);
        setSuggestedSongs(FALLBACK_SONGS); // graceful fallback
      } finally {
        setLoadingSuggestions(false);
      }
    };

    fetchSuggestions();
    // Reset liked songs when suggestions refresh
    setLikedSongs([]);
  }, [step, selectedGenres, selectedEnergy]);

  const handleNext = () => {
    if (step === "genres" && selectedGenres.length > 0) setStep("energy");
    else if (step === "energy" && selectedEnergy)       setStep("songs");
    else if (step === "songs")                          submitQuiz();
  };

  const submitQuiz = async () => {
    setStep("result");
    try {
      // Pass song ids — backend will handle both db ids and quiz placeholder ids
      const liked_song_ids = likedSongs;
      await submit.mutateAsync({
        genres:         selectedGenres,
        energy:         selectedEnergy,
        liked_song_ids,
      });
      // Save vibe selections to localStorage so the home page can
      // immediately switch to GenAI mode with matching queries,
      // giving new users relevant recommendations right away.
      if (typeof window !== 'undefined') {
        localStorage.setItem('vibeGenres',  JSON.stringify(selectedGenres));
        localStorage.setItem('vibeEnergy',  selectedEnergy);
      }
      setTimeout(() => router.push("/"), 2000);
    } catch (err) {
      console.error("Vibe check failed:", err);
      setStep("songs");
    }
  };

  const canProceed =
    (step === "genres" && selectedGenres.length > 0) ||
    (step === "energy" && !!selectedEnergy) ||
    step === "songs";

  return (
    <div className="min-h-screen bg-surface flex flex-col items-center justify-center p-4 pb-20">
      <div className="fixed inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse 80% 50% at 50% -20%, rgba(168,85,247,0.07), transparent)" }} />

      <div className="w-full max-w-2xl relative">
        {/* Header */}
        <div className="text-center mb-8 fade-in-up">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-analytics-500 via-genai-500 to-hybrid-500 flex items-center justify-center text-3xl mx-auto shadow-glow-genai mb-4">
            🎵
          </div>
          <h1 className="text-3xl font-bold text-white">Vibe Check</h1>
          <p className="text-white/50 mt-2">Let's find your perfect sound</p>

          {/* Progress dots */}
          <div className="flex gap-2 mt-6 justify-center">
            {(["genres", "energy", "songs"] as const).map((s) => {
              const sIdx    = STEP_ORDER.indexOf(s);
              const isActive = step === s;
              const isPast   = currentStepIdx > sIdx;
              return (
                <div
                  key={s}
                  className="h-2 rounded-full transition-all duration-500"
                  style={{
                    width: isActive ? 32 : 8,
                    background: isActive
                      ? "linear-gradient(to right, var(--analytics), var(--genai))"
                      : isPast
                      ? "var(--hybrid)"
                      : "rgba(255,255,255,0.15)",
                  }}
                />
              );
            })}
          </div>
        </div>

        <div className="space-y-5">
          {step !== "result" && (
            <>
              {/* Step 1: Genres */}
              {step === "genres" && (
                <div className="glass-card p-6 space-y-4 fade-in-up">
                  <h2 className="text-xl font-semibold flex items-center gap-2">
                    <Music className="w-5 h-5 text-analytics-400" /> What genres do you love?
                  </h2>
                  <p className="text-white/45 text-sm">Select at least one</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5">
                    {GENRES.map((genre) => {
                      const active = selectedGenres.includes(genre.id);
                      return (
                        <button
                          key={genre.id}
                          onClick={() => toggleGenre(genre.id)}
                          aria-pressed={active}
                          className="p-3 rounded-xl text-sm font-medium transition-all focus-ring"
                          style={{
                            border:     `1px solid ${active ? "rgba(59,130,246,0.6)" : "rgba(255,255,255,0.1)"}`,
                            background: active ? "rgba(59,130,246,0.12)" : "rgba(255,255,255,0.04)",
                            color:      active ? "white" : "rgba(255,255,255,0.6)",
                            boxShadow:  active ? "0 0 16px rgba(59,130,246,0.15)" : "none",
                          }}
                        >
                          <span className="mr-1.5">{genre.emoji}</span>
                          {genre.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Step 2: Energy */}
              {step === "energy" && (
                <div className="glass-card p-6 space-y-4 fade-in-up">
                  <h2 className="text-xl font-semibold flex items-center gap-2">
                    <Volume2 className="w-5 h-5 text-genai-400" /> What's your vibe today?
                  </h2>
                  <p className="text-white/45 text-sm">How energetic do you like your music?</p>
                  <div className="space-y-2">
                    {ENERGY_LEVELS.map((level) => {
                      const active = selectedEnergy === level.id;
                      return (
                        <button
                          key={level.id}
                          onClick={() => setSelectedEnergy(level.id)}
                          aria-pressed={active}
                          className="w-full p-4 rounded-xl transition-all text-left focus-ring"
                          style={{
                            border:     `1px solid ${active ? "rgba(168,85,247,0.5)" : "rgba(255,255,255,0.1)"}`,
                            background: active ? "rgba(168,85,247,0.1)" : "rgba(255,255,255,0.04)",
                            boxShadow:  active ? "0 0 20px rgba(168,85,247,0.12)" : "none",
                          }}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="font-semibold text-sm">{level.label}</div>
                              <div className="text-xs text-white/45 mt-1">{level.desc}</div>
                            </div>
                            {active && (
                              <div className="w-5 h-5 rounded-full bg-genai-500 flex items-center justify-center flex-shrink-0">
                                <Check className="w-3 h-3 text-white" />
                              </div>
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* ✅ FIX: Step 3 — Dynamic Song Picks */}
              {step === "songs" && (
                <div className="glass-card p-6 space-y-4 fade-in-up">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                      <Heart className="w-5 h-5 text-hybrid-400" /> Which songs speak to you?
                    </h2>
                    {/* Refresh button */}
                    {!loadingSuggestions && (
                      <button
                        onClick={() => setStep((s) => { const x = s; setStep("energy"); setTimeout(() => setStep(x), 10); return "energy"; })}
                        className="text-xs text-white/30 hover:text-white/60 flex items-center gap-1 transition-colors"
                        title="Refresh suggestions"
                      >
                        <RefreshCw className="w-3 h-3" />
                      </button>
                    )}
                  </div>

                  {/* ✅ FIX: Show personalisation context */}
                  <p className="text-white/45 text-sm">
                    {loadingSuggestions
                      ? "Finding songs that match your taste…"
                      : suggestionsError
                        ? "Showing popular songs (couldn't load personalised picks)"
                        : `Songs matched to ${selectedGenres.slice(0, 2).map(g => GENRES.find(x => x.id === g)?.label).filter(Boolean).join(" & ")} · ${selectedEnergy} energy`
                    }
                  </p>

                  {loadingSuggestions ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {Array.from({ length: 8 }).map((_, i) => (
                        <div key={i} className="p-4 rounded-xl" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
                          <div className="flex items-center gap-3">
                            <div className="skeleton w-8 h-8 rounded-lg flex-shrink-0" />
                            <div className="flex-1 space-y-1.5">
                              <div className="skeleton h-3 rounded w-3/5" />
                              <div className="skeleton h-2.5 rounded w-2/5" />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {suggestedSongs.map((song) => {
                        const active = likedSongs.includes(song.id);
                        return (
                          <button
                            key={song.id}
                            onClick={() => toggleSong(song.id)}
                            aria-pressed={active}
                            className="p-4 rounded-xl transition-all text-left focus-ring"
                            style={{
                              border:     `1px solid ${active ? "rgba(16,185,129,0.5)" : "rgba(255,255,255,0.1)"}`,
                              background: active ? "rgba(16,185,129,0.08)" : "rgba(255,255,255,0.04)",
                              boxShadow:  active ? "0 0 16px rgba(16,185,129,0.1)" : "none",
                            }}
                          >
                            <div className="flex items-center gap-3">
                              <span className="text-2xl">{song.emoji}</span>
                              <div className="flex-1 min-w-0">
                                <div className="font-semibold text-sm truncate">{song.title}</div>
                                <div className="text-xs text-white/45 truncate">{song.artist}</div>
                              </div>
                              {active && (
                                <Heart className="w-4 h-4 flex-shrink-0 text-hybrid-400 fill-current" />
                              )}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* Navigation */}
              <div className="flex gap-3 fade-in-up">
                {step !== "genres" && (
                  <button
                    onClick={() => {
                      if (step === "energy") setStep("genres");
                      else if (step === "songs") setStep("energy");
                    }}
                    className="flex-1 px-4 py-2.5 rounded-xl text-sm font-medium transition-all focus-ring"
                    style={{ border: "1px solid rgba(255,255,255,0.12)", color: "rgba(255,255,255,0.6)" }}
                  >
                    Back
                  </button>
                )}
                <button
                  onClick={handleNext}
                  disabled={!canProceed || submit.isPending || loadingSuggestions}
                  className={clsx(
                    "flex-1 px-4 py-3 rounded-xl text-sm font-semibold transition-all focus-ring flex items-center justify-center gap-2",
                    canProceed && !submit.isPending && !loadingSuggestions
                      ? "text-white"
                      : "text-white/40 cursor-not-allowed"
                  )}
                  style={{
                    background: canProceed && !submit.isPending && !loadingSuggestions
                      ? "linear-gradient(135deg, var(--analytics), var(--genai))"
                      : "rgba(255,255,255,0.08)",
                    boxShadow: canProceed && !submit.isPending && !loadingSuggestions
                      ? "0 4px 20px rgba(59,130,246,0.2)"
                      : "none",
                  }}
                >
                  {(submit.isPending || loadingSuggestions) && <Loader2 className="w-4 h-4 animate-spin" />}
                  {submit.isPending ? "Analyzing…" : loadingSuggestions ? "Loading songs…" : step === "songs" ? "Complete" : "Next →"}
                </button>
              </div>
            </>
          )}

          {/* Result */}
          {step === "result" && (
            <div className="glass-card p-10 text-center space-y-4 fade-in-up">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-analytics-500 to-hybrid-500 flex items-center justify-center mx-auto shadow-glow-hybrid">
                <Check className="w-10 h-10 text-white" strokeWidth={2.5} />
              </div>
              <h2 className="text-2xl font-bold">You're all set!</h2>
              <p className="text-white/50 leading-relaxed max-w-xs mx-auto">
                Your vibe has been recorded. Time to discover your music!
              </p>
              <div className="pt-2">
                <div className="inline-flex items-center gap-2 px-6 py-2 rounded-full text-sm" style={{ background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.5)" }}>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Redirecting…
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
