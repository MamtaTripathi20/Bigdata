"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import { useQueryClient } from "@tanstack/react-query";
import { LogOut, Sparkles, TrendingUp, RefreshCw } from "lucide-react";
import { ModeSelector }        from "@/components/modes/ModeSelector";
import { RecommendationFeed }  from "@/components/modes/RecommendationFeed";
import { QueryInput }          from "@/components/modes/genai/QueryInput";
import { ComparisonDashboard } from "@/components/modes/hybrid/ComparisonDashboard";
import { SongInfoModal }       from "@/components/ui/SongInfoModal";
import { PlaylistModal }       from "@/components/ui/PlaylistModal";
import { useRecommendations }  from "@/lib/hooks/useRecommendations";
import { useOnboardingStatus } from "@/lib/hooks/useOnboarding";
import { usePlayer }           from "@/components/ui/PlayerContext";
import { authApi }             from "@/lib/api";
import type { RecommendationMode, RecommendedSong } from "@/types";

// Hero mood tags for quick discovery
const MOOD_TAGS = [
  { emoji: "🌙", label: "Late Night",   query: "late night drive melancholy" },
  { emoji: "⚡", label: "High Energy",  query: "high energy workout pump" },
  { emoji: "☀️", label: "Morning",      query: "morning coffee fresh start" },
  { emoji: "🎭", label: "Dramatic",     query: "cinematic epic orchestral" },
  { emoji: "💆", label: "Deep Focus",   query: "deep focus concentration study" },
  { emoji: "🌊", label: "Chill",        query: "chill laid back smooth" },
  { emoji: "💔", label: "Heartbreak",   query: "heartbreak sad emotional" },
  { emoji: "🎉", label: "Party",        query: "party dance club upbeat" },
];

export default function HomePage() {
  const router       = useRouter();
  const queryClient  = useQueryClient();

  const [mode,        setMode]        = useState<RecommendationMode>("analytics");
  const [queryText,   setQueryText]   = useState("");
  const [showCompare, setShowCompare] = useState(false);
  const [infoSong,    setInfoSong]    = useState<RecommendedSong | null>(null);
  const [plSong,      setPlSong]      = useState<RecommendedSong | null>(null);
  const [mounted,     setMounted]     = useState(false);
  const [activeMood,  setActiveMood]  = useState<string | null>(null);
  const [logoutError, setLogoutError] = useState<string>("");

  const { data: onboardingStatus, isLoading: onboardingLoading } = useOnboardingStatus();
  const { data, isLoading, error, refetch } = useRecommendations(mode, queryText);
  const { playSong, resetPlayer } = usePlayer();

    useEffect(() => { setMounted(true); }, []);

  // Fix: New users land in GenAI mode with their vibe-check genres as the
  // initial query, so they immediately see personalised recommendations
  // instead of the Analytics cold-start popular-songs fallback.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const raw = localStorage.getItem('vibeGenres');
    const energy = localStorage.getItem('vibeEnergy') || 'mid';
    if (!raw) return;
    try {
      const genres = JSON.parse(raw) as string[];
      if (!genres.length) return;
      const energyLabel =
        energy === 'high' ? 'upbeat energetic' :
        energy === 'low'  ? 'chill relaxing'   :
        energy === 'mixed'? 'varied'            : '';
      const query = [genres.slice(0, 3).join(' '), energyLabel, 'music']
        .filter(Boolean).join(' ');
      setMode('genai');
      setQueryText(query);
    } catch { /* ignore */ }
    localStorage.removeItem('vibeGenres');
    localStorage.removeItem('vibeEnergy');
  }, []);

  useEffect(() => {
    if (onboardingStatus?.needs_onboarding) router.push("/onboarding");
  }, [onboardingStatus?.needs_onboarding, router]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
    if (e.key === "1") { setMode("analytics"); setQueryText(""); setActiveMood(null); }
    if (e.key === "2") { setMode("genai");     setQueryText(""); setActiveMood(null); }
    if (e.key === "3") { setMode("hybrid");    setQueryText(""); setActiveMood(null); }
  }, []);

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  const handlePlay = (song: RecommendedSong) => {
    playSong(song, mode, data?.recommendations);
  };

  const handleMoodTag = (mood: typeof MOOD_TAGS[0]) => {
    setMode("genai");
    setQueryText(mood.query);
    setActiveMood(mood.label);
  };

  const handleLogout = async () => {
    setLogoutError("");
    resetPlayer();
    queryClient.clear();
    try {
      await authApi.logout();
    } catch (err) {
      // ignore logout transport errors and continue client-side reset
      console.error(err);
      setLogoutError("Could not contact server to confirm logout. You have been signed out locally.");
    }
    window.dispatchEvent(new Event("auth-changed"));
    router.push("/login");
  };

  if (onboardingLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--bg)" }}>
        <div className="text-center space-y-6">
          <div className="relative w-20 h-20 mx-auto">
            <div
              className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl"
              style={{
                background: "linear-gradient(135deg, #4f8ef7 0%, #c084fc 50%, #2dd4bf 100%)",
                boxShadow:  "0 0 40px rgba(79,142,247,0.4)",
              }}
            >
              🎵
            </div>
            <div
              className="absolute inset-0 rounded-2xl animate-ping"
              style={{
                background: "linear-gradient(135deg, #4f8ef7, #c084fc, #2dd4bf)",
                opacity:    0.2,
              }}
            />
          </div>
          <div>
            <p className="font-display font-bold text-white text-lg">Resonance</p>
            <div className="flex gap-1.5 justify-center mt-3">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="w-1.5 h-1.5 rounded-full bg-white/20 animate-pulse"
                  style={{ animationDelay: `${i * 0.15}s` }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ opacity: mounted ? 1 : 0, transition: "opacity 0.4s ease" }}>

      {/* ── Top header bar ──────────────────────────────────────────── */}
      <header
        className="sticky top-0 z-20 px-5 py-3 flex items-center justify-between"
        style={{
          background:     "rgba(7, 7, 15, 0.85)",
          backdropFilter: "blur(20px)",
          borderBottom:   "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <div className="flex items-center gap-3">
          <div>
            <h1 className="font-display font-bold text-base text-white leading-none">
              Good {getGreeting()} 👋
            </h1>
            <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.3)" }}>
              Discover your next favourite track
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowCompare(!showCompare)}
            className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-all"
            style={{
              background: showCompare ? "rgba(79,142,247,0.15)" : "rgba(255,255,255,0.05)",
              border:     showCompare ? "1px solid rgba(79,142,247,0.3)" : "1px solid rgba(255,255,255,0.08)",
              color:      showCompare ? "var(--analytics)" : "rgba(255,255,255,0.5)",
            }}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{showCompare ? "Hide" : "Compare"}</span>
          </button>

          <button
            onClick={handleLogout}
            className="p-2 rounded-lg transition-colors"
            style={{ color: "rgba(255,255,255,0.3)" }}
            title="Log out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      <div className="px-5 py-6 space-y-6 max-w-4xl">
        {logoutError && (
          <div
            className="rounded-xl px-3 py-2 text-xs"
            style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.18)", color: "rgba(248,113,113,0.95)" }}
          >
            {logoutError}
          </div>
        )}

        {/* ── Hero mood section ────────────────────────────────────── */}
        <section className="fade-in-up" style={{ animationDelay: "0.05s" }}>
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4" style={{ color: "var(--genai)" }} />
            <span className="text-sm font-display font-semibold" style={{ color: "rgba(255,255,255,0.6)" }}>
              Mood Discovery
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {MOOD_TAGS.map((mood) => (
              <button
                key={mood.label}
                onClick={() => handleMoodTag(mood)}
                className="tag-chip"
                style={
                  activeMood === mood.label
                    ? {
                        background:   "rgba(192,132,252,0.15)",
                        borderColor:  "rgba(192,132,252,0.35)",
                        color:        "var(--genai)",
                      }
                    : {}
                }
              >
                <span>{mood.emoji}</span>
                {mood.label}
              </button>
            ))}
          </div>
        </section>

        {/* ── Mode selector ────────────────────────────────────────── */}
        <section className="fade-in-up" style={{ animationDelay: "0.1s" }}>
          <ModeSelector
            current={mode}
            onChange={(m) => { setMode(m); setQueryText(""); setActiveMood(null); }}
          />
        </section>

        {/* ── Query input (GenAI / Hybrid) ─────────────────────────── */}
        {(mode === "genai" || mode === "hybrid") && (
          <section className="fade-in-up" style={{ animationDelay: "0.12s" }}>
            <QueryInput
              value={queryText}
              onChange={setQueryText}
              onSearch={refetch}
              mode={mode}
            />
          </section>
        )}

        {/* ── Comparison dashboard ─────────────────────────────────── */}
        {showCompare && (
          <section className="fade-in-up" style={{ animationDelay: "0.12s" }}>
            <ComparisonDashboard queryText={queryText} />
          </section>
        )}

        {/* ── Recommendation feed ──────────────────────────────────── */}
        {!showCompare && (
          <section className="fade-in-up" style={{ animationDelay: "0.15s" }}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <h2 className="font-display font-bold text-sm text-white">
                  {mode === "analytics" ? "For You" : mode === "genai" ? "Vibe Match" : "Hybrid Mix"}
                </h2>
                {data?.count && (
                  <span
                    className="text-xs px-2 py-0.5 rounded-full font-medium"
                    style={{ background: "rgba(255,255,255,0.07)", color: "rgba(255,255,255,0.4)" }}
                  >
                    {data.count} tracks
                  </span>
                )}
              </div>
              <button
                onClick={() => refetch()}
                className="flex items-center gap-1.5 text-xs transition-colors"
                style={{ color: "rgba(255,255,255,0.3)" }}
                title="Refresh recommendations"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Refresh</span>
              </button>
            </div>

            <RecommendationFeed
              mode={mode}
              data={data}
              isLoading={isLoading}
              error={error}
              onPlay={handlePlay}
              onInfoClick={setInfoSong}
              onAddToPlaylist={setPlSong}
            />
          </section>
        )}
      </div>

      <SongInfoModal song={infoSong} onClose={() => setInfoSong(null)} />
      <PlaylistModal song={plSong}   onClose={() => setPlSong(null)} />
    </div>
  );
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  return "evening";
}
