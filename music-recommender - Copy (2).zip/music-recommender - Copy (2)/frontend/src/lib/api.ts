import axios from "axios";
import type { RecommendationMode, RecommendationResponse, PlayEvent } from "@/types";

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000",
  timeout: 180000,
  withCredentials: true,
});

let refreshPromise: Promise<any> | null = null;

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config || {};
    const url = original.url || "";
    const isAuthRoute = url.includes("/api/v1/auth/login") || url.includes("/api/v1/auth/refresh");

    if (error?.response?.status === 401 && !original._retry && !isAuthRoute) {
      original._retry = true;
      try {
        if (!refreshPromise) {
          refreshPromise = api.post("/api/v1/auth/refresh").finally(() => {
            refreshPromise = null;
          });
        }
        await refreshPromise;
        return api(original);
      } catch {
        return Promise.reject(error);
      }
    }

    return Promise.reject(error);
  }
);

// ── Auth ─────────────────────────────────────────────────────────
export const authApi = {
  register: (data: { username: string; email: string; password: string }) =>
    api.post("/api/v1/auth/register", data),
  login: (username: string, password: string) => {
    const form = new URLSearchParams();
    form.append("username", username);
    form.append("password", password);
    return api.post("/api/v1/auth/login", form, {
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });
  },
  refresh: () => api.post("/api/v1/auth/refresh"),
  logout: () => api.post("/api/v1/auth/logout"),
  me: () => api.get("/api/v1/auth/me"),
};

// ── Recommendations ──────────────────────────────────────────────
export const recommendApi = {
  get: (mode: RecommendationMode, count = 10, queryText?: string): Promise<{ data: RecommendationResponse }> => {
    const params: Record<string, any> = { mode, count };
    if (queryText) params.query_text = queryText;
    return api.get("/api/v1/recommendations", { params });
  },

  logPlay: (event: PlayEvent) =>
    api.post("/api/v1/recommendations/play", event),

  toggleLike: (songId: number, liked: boolean) =>
    api.post(`/api/v1/recommendations/liked`, null, {
      params: { song_id: songId, liked },
    }),

  getModes: () => api.get("/api/v1/recommendations/modes"),
};

// ── Library ───────────────────────────────────────────────────────
export const libraryApi = {
  // Liked songs
  getLikedSongs: () =>
    api.get("/api/v1/library/liked"),

  // Song detail
  getSongDetail: (songId: number) =>
    api.get(`/api/v1/library/songs/${songId}`),

  // Artists list
  getArtists: () =>
    api.get(`/api/v1/library/artists`),

  // Artist profile
  getArtistProfile: (artistId: number) =>
    api.get(`/api/v1/library/artists/${artistId}/full`),

  // Albums list
  getAlbums: () =>
    api.get(`/api/v1/library/albums`),

  // Album info
  getAlbumInfo: (albumId: number) =>
    api.get(`/api/v1/library/albums/${albumId}/full`),

  // Playlists
  getPlaylists: () =>
    api.get("/api/v1/library/playlists"),

  createPlaylist: (name: string, isPublic = false) =>
    api.post("/api/v1/library/playlists", { name, is_public: isPublic }),

  getPlaylist: (playlistId: number) =>
    api.get(`/api/v1/library/playlists/${playlistId}`),

  // FIX: New PATCH endpoint for renaming / toggling public-private
  // Previously there was no way to change a playlist after creation.
  updatePlaylist: (playlistId: number, data: { name?: string; is_public?: boolean }) =>
    api.patch(`/api/v1/library/playlists/${playlistId}`, data),

  addSongToPlaylist: (playlistId: number, songId: number) =>
    api.post(`/api/v1/library/playlists/${playlistId}/songs`, { song_id: songId }),

  removeSongFromPlaylist: (playlistId: number, songId: number) =>
    api.delete(`/api/v1/library/playlists/${playlistId}/songs/${songId}`),

  deletePlaylist: (playlistId: number) =>
    api.delete(`/api/v1/library/playlists/${playlistId}`),

  // Public playlist discovery
  searchPublicPlaylists: (q: string) =>
    api.get("/api/v1/library/playlists/search/public", { params: { q } }),
};

// ── Onboarding ───────────────────────────────────────────────────
export const onboardingApi = {
  getStatus: () => api.get("/api/v1/onboarding/status"),
  submitVibeCheck: (data: { genres: string[]; energy: string; liked_song_ids: string[] }) =>
    api.post("/api/v1/onboarding/vibe-check", data),
};

// ── Health ───────────────────────────────────────────────────────
export const healthApi = {
  check: () => api.get("/api/v1/health"),
};

export default api;
