import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { onboardingApi } from "@/lib/api";

export function useOnboardingStatus() {
  return useQuery({
    queryKey: ["onboarding", "status"],
    queryFn: async () => {
      const res = await onboardingApi.getStatus();
      return res.data;
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 1,
  });
}

export function useSubmitVibeCheck() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: { genres: string[]; energy: string; liked_song_ids: string[] }) => {
      const res = await onboardingApi.submitVibeCheck(data);
      return res.data;
    },
    onSuccess: () => {
      // Invalidate onboarding status so it refetches
      queryClient.invalidateQueries({ queryKey: ["onboarding", "status"] });
    },
  });
}
