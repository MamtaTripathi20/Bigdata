import { useEffect, useRef } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { authApi } from "@/lib/api";
import { recommendApi } from "@/lib/api";
import type { RecommendationMode, RecommendationResponse } from "@/types";

function useRecommendationScope() {
  const queryClient = useQueryClient();
  const prevScopeRef = useRef<string | null>(null);

  const { data: me } = useQuery<{ id: number }>({
    queryKey: ["auth", "me"],
    queryFn: async () => (await authApi.me()).data,
    staleTime: 60_000,
    retry: 0,
  });

  const scope = me?.id != null ? `user:${me.id}` : "user:anonymous";

  useEffect(() => {
    const onAuthChanged = () => {
      queryClient.invalidateQueries({ queryKey: ["auth", "me"] });
    };
    window.addEventListener("auth-changed", onAuthChanged);
    return () => window.removeEventListener("auth-changed", onAuthChanged);
  }, [queryClient]);

  useEffect(() => {
    if (prevScopeRef.current && prevScopeRef.current !== scope) {
      queryClient.removeQueries({ queryKey: ["recommendations"] });
    }
    prevScopeRef.current = scope;
  }, [scope, queryClient]);

  return scope;
}

export function useRecommendations(mode: RecommendationMode, queryText?: string) {
  const scope = useRecommendationScope();

  return useQuery<RecommendationResponse>({
    queryKey: ["recommendations", scope, mode, queryText],
    queryFn: async () => {
      const res = await recommendApi.get(mode, 10, queryText || undefined);
      return res.data;
    },
    staleTime: mode === "analytics" ? 30_000 : 60_000,
    retry: 1,
    enabled: true,
  });
}

export function useAllModes(queryText?: string) {
  const scope = useRecommendationScope();

  const analytics = useQuery<RecommendationResponse>({
    queryKey: ["recommendations", scope, "analytics"],
    queryFn: async () => (await recommendApi.get("analytics", 10)).data,
    staleTime: 30_000,
  });

  const genai = useQuery<RecommendationResponse>({
    queryKey: ["recommendations", scope, "genai", queryText],
    queryFn: async () => (await recommendApi.get("genai", 10, queryText)).data,
    staleTime: 60_000,
  });

  const hybrid = useQuery<RecommendationResponse>({
    queryKey: ["recommendations", scope, "hybrid", queryText],
    queryFn: async () => (await recommendApi.get("hybrid", 10, queryText)).data,
    staleTime: 60_000,
  });

  return { analytics, genai, hybrid };
}
