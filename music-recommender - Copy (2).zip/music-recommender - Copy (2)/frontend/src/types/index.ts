// ── Mode ────────────────────────────────────────────────────────
export type RecommendationMode = "analytics" | "genai" | "hybrid";

export const MODE_META: Record<RecommendationMode, {
  label: string;
  color: string;
  bgColor: string;
  borderColor: string;
  description: string;
  icon: string;
  latency: string;
}> = {
  analytics: {
    label:       "Analytics",
    color:       "text-analytics-500",
    bgColor:     "bg-analytics-500",
    borderColor: "border-analytics-500",
    description: "ML-based: Fuzzy C-Means + Collaborative Filtering",
    icon:        "📊",
    latency:     "~150ms",
  },
  genai: {
    label:       "Generative AI",
    color:       "text-genai-500",
    bgColor:     "bg-genai-500",
    borderColor: "border-genai-500",
    description: "Sentence Transformer embeddings + iTunes — searches by vibe, not just keywords",
    icon:        "🤖",
    latency:     "~500ms",
  },
  hybrid: {
    label:       "Hybrid Fusion",
    color:       "text-hybrid-500",
    bgColor:     "bg-hybrid-500",
    borderColor: "border-hybrid-500",
    description: "Blends Analytics + GenAI scores (α·ML + β·AI) — best of both worlds",
    icon:        "⚡",
    latency:     "~500ms",
  },
};

// ── API Response Types ───────────────────────────────────────────
export interface RecommendedSong {
  song_id:          number;
  title:            string;
  artist:           string;
  album?:           string;
  genre?:           string;
  score:            number;
  explanation:      string;
  preview_url?:     string;
  cover_url?:       string;
  analytics_score?: number;
  genai_score?:     number;
  artist_id?:       number;
}

export interface RecommendationResponse {
  mode:            RecommendationMode;
  recommendations: RecommendedSong[];
  latency_ms:      number;
  timestamp:       string;
  count:           number;
  query_text?:     string;
  fallback_used?:  string;
}

// ── Auth ─────────────────────────────────────────────────────────
export interface LoginForm {
  username: string;
  password: string;
}

export interface RegisterForm {
  username: string;
  email:    string;
  password: string;
}

export interface AuthToken {
  access_token: string;
  token_type:   string;
}

// ── Play Event ───────────────────────────────────────────────────
export interface PlayEvent {
  song_id:          number;
  skipped?:         boolean;
  liked?:           boolean;
  replayed?:        boolean;
  play_duration_s?: number;
}

// ── Health ───────────────────────────────────────────────────────
export interface HealthResponse {
  overall:  string;
  postgres: { status: string; latency_ms?: number; detail?: string };
  redis:    { status: string; latency_ms?: number; detail?: string };
  ollama:   { status: string; latency_ms?: number; detail?: string };
}
