/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['Syne', 'sans-serif'],
        body:    ['Plus Jakarta Sans', 'sans-serif'],
        mono:    ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      colors: {
        // Analytics Mode — Electric Blue
        analytics: {
          50:  "#eff6ff",
          100: "#dbeafe",
          200: "#bfdbfe",
          400: "#60a5fa",
          500: "#4f8ef7",
          600: "#3b82f6",
          700: "#2563eb",
          dim: "rgba(79, 142, 247, 0.15)",
        },
        // GenAI Mode — Lavender
        genai: {
          50:  "#fdf4ff",
          100: "#fae8ff",
          200: "#f5d0fe",
          400: "#d946ef",
          500: "#c084fc",
          600: "#a855f7",
          700: "#9333ea",
          dim: "rgba(192, 132, 252, 0.15)",
        },
        // Hybrid Mode — Teal/Mint
        hybrid: {
          50:  "#f0fdfa",
          100: "#ccfbf1",
          200: "#99f6e4",
          400: "#2dd4bf",
          500: "#2dd4bf",
          600: "#0d9488",
          700: "#0f766e",
          dim: "rgba(45, 212, 191, 0.15)",
        },
        // App chrome
        bg:      "#07070f",
        surface: "#0c0c1a",
        card:    "#10101e",
        border:  "rgba(255,255,255,0.07)",
      },
      boxShadow: {
        "glow-analytics": "0 0 24px rgba(79, 142, 247, 0.35)",
        "glow-genai":     "0 0 24px rgba(192, 132, 252, 0.35)",
        "glow-hybrid":    "0 0 24px rgba(45, 212, 191, 0.35)",
        "glow-sm":        "0 0 12px rgba(255,255,255,0.08)",
        "card":           "0 4px 24px rgba(0,0,0,0.4)",
        "modal":          "0 24px 80px rgba(0,0,0,0.7)",
        "player":         "0 -8px 40px rgba(0,0,0,0.6)",
      },
      animation: {
        "pulse-slow":    "pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "spin-slow":     "spin-slow 4s linear infinite",
        "float":         "float 4s ease-in-out infinite",
        "glow-pulse":    "glow-pulse 2s ease-in-out infinite",
      },
      keyframes: {
        "spin-slow": { to: { transform: "rotate(360deg)" } },
        "float": {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%":      { transform: "translateY(-6px)" },
        },
        "glow-pulse": {
          "0%, 100%": { opacity: "0.4" },
          "50%":      { opacity: "0.9" },
        },
      },
      backdropBlur: {
        xs: "4px",
      },
    },
  },
  plugins: [],
};
